# Security

Report a problem by opening a GitHub issue on this repository. If it involves a key or token, say so in the title and
do not paste the value; a maintainer will move the conversation somewhere private.

Rules this kit relies on:

- Never commit `auth.json`, `upstream.env`, `ledger.jsonl`, `state.json` or `proxy.log`. The `.gitignore` here lists
  them; keep it when you fork.
- `upstream.env` holds the only copy of the upstream keys and must be `chmod 600`. Hermes itself is given a dummy key
  and only ever talks to `127.0.0.1:8788`.
- The proxy reads the portal access token from `auth.json` read-only and never calls the token-refresh endpoint.
  Hermes's own auth code comments say Nous refresh tokens are single-use: a second client that refreshes them logs the
  first one out.
- `tests/acceptance.sh` copies your live policy, state, `upstream.env` and `auth.json` into a sandbox directory
  under `/tmp`. Delete that directory when the run is over.
- The proxy binds to loopback only. Do not expose it; it has no authentication of its own.
