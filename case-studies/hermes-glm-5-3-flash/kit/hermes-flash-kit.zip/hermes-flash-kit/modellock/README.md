# modellock: the fail-closed model-lock proxy

A single-file, stdlib-only HTTP proxy (`proxy.py`, v1.1) that sits between Hermes Agent and the model provider on
`127.0.0.1:8788`. Hermes is pointed at it as a custom OpenAI-compatible provider; the real upstream keys live only in
`upstream.env` next to the proxy.

What it enforces, per request, before the call goes upstream:

- an allow-list of models plus aliases; anything else is HTTP 403 and costs nothing
- USD caps: lifetime, daily, per-model daily, per-bucket (bucket = the bearer a pipeline sends), and a portal reserve;
  crossing one is HTTP 402, and Hermes surfaces it as `billing_blocked`
- cache-aware pricing from `rates_usd_per_mtok` (in / out / cache_read), because the upstream's `usage.cost` was a
  flat 0.00005 per call in our measurements; the ledger (`ledger.jsonl`) and running totals (`state.json`) are what the caps read
- per-model reasoning overrides, stall and wall-clock timeouts, degrade-to-other-lane when only a per-model cap binds
- `GET /v1/models/<id>` answers `context_length` so Hermes stops probing for it
- a `/healthz` endpoint used by the `budget_gate.py` hook

## Install (macOS, launchd)

```
mkdir -p ~/.hermes/modellock
cp proxy.py policy.example.json ~/.hermes/modellock/ && mv ~/.hermes/modellock/policy.example.json ~/.hermes/modellock/policy.json
cp upstream.env.example ~/.hermes/modellock/upstream.env && chmod 600 ~/.hermes/modellock/upstream.env   # fill in the keys
sed "s|__HOME__|$HOME|g" com.example.hermes-modellock.plist > ~/Library/LaunchAgents/com.example.hermes-modellock.plist
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.example.hermes-modellock.plist
curl -s http://127.0.0.1:8788/healthz
```

Then in Hermes: provider `custom:<name>` with base URL `http://127.0.0.1:8788/v1` and any non-empty API key
(the proxy uses the inbound bearer only as a bucket name). Edit `policy.json` any time; caps and allow-list are re-read
per request, the listen port needs a restart (`launchctl kickstart -k gui/$(id -u)/com.example.hermes-modellock`).

Environment overrides: `MODELLOCK_ROOT` (directory of policy/ledger/state), `MODELLOCK_PORT`, `MODELLOCK_AUTH_JSON`
(where the portal access token is read from, read-only; the proxy never refreshes it). The portal reserve polls
`/api/oauth/account`, the endpoint the Hermes client itself uses; it is undocumented and may change, in which case
set `portal.enabled` to false and rely on the ledger caps.

## Log rotation

`newsyslog.d-hermes-modellock.conf` rotates `proxy.log` (SIGHUP to `proxy.pid`, the proxy reopens the file and writes
a ledger anchor) and `ledger.jsonl` (no signal, never compressed, so a fail-closed rebuild can still read `.0`).
Replace `__HOME__` and `USER` before copying it to `/etc/newsyslog.d/` as root.

## Tests

`tests/acceptance.sh` starts a sandbox copy of the proxy on port 8799 against `tests/mock_upstream.py` on 8790 and
walks the acceptance checks (body drain on keep-alive, 403 on unknown model, 402 on cap, warning headers, degrade,
buckets, anchors). The upstream is mocked, but the test is not self-contained: it requires a working install with
`policy.json`, `state.json`, `upstream.env` and a non-empty `ledger.jsonl` under `$PROD` (default `~/.hermes/modellock`)
and a signed-in `~/.hermes/auth.json`, all of which it copies into the sandbox directory. Set `MOCK_MODE=1` to run
without a live install: the sandbox then gets a fresh policy from `policy.example.json`, an empty ledger and a dummy
`auth.json`, and the portal checks are skipped. It also runs `pkill -f mock_upstream.py`, so do not run it beside
another copy of itself. Run it only on a machine you own and delete the sandbox afterwards. `tests/patch_policy.py` adds any
missing v1.1 keys to an older policy file.
