#!/usr/bin/env python3
"""Model lock proxy for the Hermes harness.

Every LLM call the harness makes goes through here. The proxy holds the real
upstream API keys; Hermes does not. So a caller cannot reach a model this
policy does not allow, no matter which flag it passes or which script invokes
it.

Jobs:
  1. Allowlist. A model outside policy["allow"] gets HTTP 403 and costs zero.
  2. Spend ceiling. Every call is priced from the local rate table and written
     to a ledger. Once a ceiling is hit the proxy stops forwarding. Ceilings
     exist per lifetime, per day, per model per day, per pipeline bucket (keyed
     by the inbound bearer value) and against the Nous portal balance.
  3. Correctness. The reasoning override that V4 Flash needs is injected here
     so no caller can omit it and get a zero-content turn.
  4. Accounting integrity. state.json is rebuilt from the ledger's last anchor
     row when it is unreadable; with no anchor the proxy answers 503 rather
     than start counting from zero.

It fails closed everywhere. If the policy is unreadable, if the upstream key is
missing, if the cap is reached, if the state cannot be trusted, the answer is
an error, not a call.

Stdlib only. Run it with the launchd job, or directly for a smoke test:
    python3 ~/.hermes/modellock/proxy.py
CLI:
    proxy.py --anchor "<reason>"   append an anchor row to the ledger from state.json
    proxy.py --refresh-rates       re-read /v1/models pricing for allowed models
    proxy.py --portal-sync         one portal read, print state["portal"]
Env overrides (tests run a second instance against a scratch copy):
    MODELLOCK_ROOT, MODELLOCK_PORT, MODELLOCK_AUTH_JSON
"""

from __future__ import annotations

import io
import json
import os
import re
import shutil
import signal
import socketserver
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler

VERSION = "hermes-modellock/1.1"

HOME = os.path.expanduser("~")
ROOT = os.environ.get("MODELLOCK_ROOT") or os.path.join(HOME, ".hermes", "modellock")
POLICY_PATH = os.path.join(ROOT, "policy.json")
UPSTREAM_ENV = os.path.join(ROOT, "upstream.env")
LEDGER_PATH = os.path.join(ROOT, "ledger.jsonl")
STATE_PATH = os.path.join(ROOT, "state.json")
WARN_PATH = os.path.join(ROOT, "warn.log")
LOG_PATH = os.path.join(ROOT, "proxy.log")
PID_PATH = os.path.join(ROOT, "proxy.pid")
RATES_LOG = os.path.join(ROOT, "rates_refresh.log")
AUTH_JSON = os.environ.get("MODELLOCK_AUTH_JSON") or os.path.join(HOME, ".hermes", "auth.json")
PORTAL_URL = "https://portal.nousresearch.com"

# RLock: load_state() may rebuild and save under a lock the caller already holds.
_state_lock = threading.RLock()
_MAX_BODY = 64 * 1024 * 1024
_STATE_KEYS = ("total_usd", "days", "model_days", "calls", "blocked", "buckets", "bucket_days")
_BUCKET_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")


class StateUnavailable(RuntimeError):
    """state.json is unreadable and the ledger has no anchor to rebuild from."""


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def load_policy() -> dict:
    with open(POLICY_PATH) as fh:
        return json.load(fh)


def load_upstream_env() -> None:
    """Read the real keys from a 0600 file next to the policy.

    They live here rather than in ~/.hermes/.env so that removing them from
    the Hermes env does not also break the proxy.
    """
    if not os.path.exists(UPSTREAM_ENV):
        return
    with open(UPSTREAM_ENV) as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            os.environ.setdefault(key.strip(), val.strip())


# --- state and ledger ---------------------------------------------------------

def append_ledger(record: dict) -> None:
    with open(LEDGER_PATH, "a") as fh:
        fh.write(json.dumps(record, separators=(",", ":")) + "\n")


def save_state(state: dict) -> None:
    tmp = STATE_PATH + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(state, fh, indent=2)
    os.replace(tmp, STATE_PATH)


def _apply_cost(st: dict, model: str, bucket: str, cost: float, day: str) -> None:
    """The one accumulator shared by _record and the ledger rebuild."""
    st["total_usd"] = float(st.get("total_usd", 0.0)) + cost
    days = st.setdefault("days", {})
    days[day] = float(days.get(day, 0.0)) + cost
    md = st.setdefault("model_days", {}).setdefault(day, {})
    md[model] = float(md.get(model, 0.0)) + cost
    bd = st.setdefault("bucket_days", {}).setdefault(day, {})
    bd[bucket] = float(bd.get(bucket, 0.0)) + cost
    bl = st.setdefault("buckets", {})
    bl[bucket] = float(bl.get(bucket, 0.0)) + cost
    st["calls"] = int(st.get("calls", 0)) + 1


def _rebuild_from_ledger() -> dict:
    """Last anchor row + every call row after it. Raises if there is no anchor.

    Rows before the last anchor are deliberately ignored: the ledger holds rows
    priced under older (wrong) rate tables, and the 2026-09-17 07:30 UTC rebase
    to portal dollars lives only in the anchor snapshot.
    """
    anchor, after = None, []
    for path in (LEDGER_PATH + ".0", LEDGER_PATH):  # rotated file first
        if not os.path.exists(path):
            continue
        with open(path) as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                if r.get("event") == "anchor":
                    anchor, after = r, []
                elif r.get("event") == "call" and anchor is not None:
                    after.append(r)
    if anchor is None:
        raise StateUnavailable("state.json unreadable and ledger has no anchor row")
    st = {k: anchor.get(k) for k in _STATE_KEYS if k in anchor}
    st.setdefault("total_usd", 0.0)
    st.setdefault("days", {})
    st.setdefault("model_days", {})
    st.setdefault("bucket_days", {})
    st.setdefault("buckets", {})
    for r in after:
        _apply_cost(st, r.get("model") or "?", r.get("bucket") or "default",
                    float(r.get("cost_usd") or 0.0), (r.get("ts") or today())[:10])
    st["rebuilt_from_ledger_at"] = now_iso()
    st["rebuilt_from_anchor_ts"] = anchor.get("ts")
    return st


def load_state() -> dict:
    """Read state.json; rebuild from the ledger anchor when it is unreadable.

    Never returns zeros for a missing file: that would silently reset every cap.
    Raises StateUnavailable when neither source is usable; callers refuse.
    """
    try:
        with open(STATE_PATH) as fh:
            st = json.load(fh)
        if not isinstance(st, dict) or not isinstance(st.get("total_usd"), (int, float)):
            raise ValueError("state.json lacks total_usd")
        return st
    except (OSError, ValueError) as exc:
        sys.stderr.write(f"{now_iso()} model lock: state.json unreadable ({exc}); rebuilding from ledger\n")
        st = _rebuild_from_ledger()
        with _state_lock:
            save_state(st)
        sys.stderr.write(f"{now_iso()} model lock: state rebuilt from anchor {st.get('rebuilt_from_anchor_ts')} "
                         f"total={st.get('total_usd')}\n")
        return st


def write_anchor(state: dict, reason: str) -> None:
    row = {"ts": now_iso(), "event": "anchor", "reason": reason}
    row.update({k: state.get(k) for k in _STATE_KEYS if k in state})
    append_ledger(row)


# --- pricing and caps ---------------------------------------------------------

def price(policy: dict, model: str, prompt_tok: int, completion_tok: int, cached_tok: int = 0) -> float:
    """Price one call the way the Nous Portal bills it.

    2026-09-17: verified against /api/oauth/account member_spend_usd and the
    /v1/models catalog. Cached prompt tokens (usage.prompt_tokens_details.
    cached_tokens) bill at the model's input_cache_read rate, the rest of the
    prompt at "in", completions at "out". Ignoring the cache rate over-billed
    the ledger 12x to 17x (97 percent of prompt tokens are cache hits) and the
    caps fired on money that was never spent.
    """
    rate = policy.get("rates_usd_per_mtok", {}).get(model)
    if not isinstance(rate, dict):
        # Unknown model that somehow passed the allowlist: price it high
        # rather than free, so an accounting gap can never look like $0.
        return (prompt_tok + completion_tok) / 1e6 * 10.0
    cached_tok = max(0, min(int(cached_tok or 0), int(prompt_tok or 0)))
    uncached = int(prompt_tok or 0) - cached_tok
    cache_rate = rate.get("cache_read", rate.get("in", 0.0))
    return ((uncached / 1e6) * rate.get("in", 0.0)
            + (cached_tok / 1e6) * cache_rate
            + (int(completion_tok or 0) / 1e6) * rate.get("out", 0.0))


def _portal_reserve(policy: dict) -> float:
    caps = policy.get("caps") or {}
    pol = policy.get("portal") or {}
    v = caps.get("portal_reserve_usd", pol.get("reserve_usd", 1.0))
    try:
        return float(v)
    except (TypeError, ValueError):
        return 1.0


def portal_usable_now(policy: dict, state: dict):
    """(usable_usd, age_s) from a fresh portal snapshot, else (None, None).

    usable = total_usable_credits at read time minus what the ledger has
    recorded since. Stale or missing snapshot => None: the caller falls back
    to the local caps (fail to ledger, never open).
    """
    pol = policy.get("portal") or {}
    p = state.get("portal") or {}
    if not pol.get("enabled"):
        return None, None
    if not isinstance(p.get("total_usable_credits"), (int, float)) or not p.get("read_at"):
        return None, None
    try:
        age = time.time() - datetime.fromisoformat(p["read_at"]).timestamp()
    except Exception:
        return None, None
    if age > float(pol.get("max_stale_s", 3600)):
        return None, None
    spent_since = float(state.get("total_usd", 0.0)) - float(p.get("ledger_total_at_read", 0.0))
    return float(p["total_usable_credits"]) - max(0.0, spent_since), age


def cap_status(policy: dict, state: dict, model: str = "", bucket: str = "default") -> tuple[bool, str]:
    """Return (allowed, reason). Checked before every forwarded call.

    Ceilings, any of which fails the call closed: per-model daily (degradable
    to the other lane, see choose_lane), per-bucket daily and lifetime,
    lifetime, daily, and the portal balance minus a reserve when a fresh
    portal snapshot exists. The per-model cap exists because the cheap model
    and the expensive model share one budget; per-bucket caps exist so one
    runaway pipeline cannot starve the others.
    """
    caps = policy.get("caps", {})
    total_cap = caps.get("total_usd")
    daily_cap = caps.get("daily_usd")
    d = today()
    spent_total = float(state.get("total_usd", 0.0))
    spent_today = float(state.get("days", {}).get(d, 0.0))

    per_model = caps.get("per_model_daily_usd") or {}
    model_cap = per_model.get(model)
    if model_cap is not None:
        spent_model = float(state.get("model_days", {}).get(d, {}).get(model, 0.0))
        if spent_model >= float(model_cap):
            return False, (
                f"model lock: daily cap for {model} reached. "
                f"spent ${spent_model:.4f} of ${float(model_cap):.2f} today. "
                f"Other allowed models are unaffected. Resets at 00:00 UTC, or "
                f"raise caps.per_model_daily_usd['{model}'] in {POLICY_PATH}."
            )

    bconf = (policy.get("buckets") or {}).get(bucket) or {}
    bcap = bconf.get("daily_usd")
    if bcap is not None:
        spent_b = float(state.get("bucket_days", {}).get(d, {}).get(bucket, 0.0))
        if spent_b >= float(bcap):
            return False, (
                f"model lock: daily cap for pipeline '{bucket}' reached. "
                f"spent ${spent_b:.4f} of ${float(bcap):.2f} today. Other pipelines are unaffected. "
                f"Resets at 00:00 UTC, or raise buckets['{bucket}'].daily_usd in {POLICY_PATH}."
            )
    btot = bconf.get("total_usd")
    if btot is not None:
        spent_bl = float(state.get("buckets", {}).get(bucket, 0.0))
        if spent_bl >= float(btot):
            return False, (
                f"model lock: lifetime cap for pipeline '{bucket}' reached. "
                f"spent ${spent_bl:.4f} of ${float(btot):.2f}. Raise buckets['{bucket}'].total_usd in {POLICY_PATH}."
            )

    if total_cap is not None and spent_total >= float(total_cap):
        return False, (
            f"model lock: lifetime spend cap reached. "
            f"spent ${spent_total:.4f} of ${float(total_cap):.2f}. "
            f"Raise caps.total_usd in {POLICY_PATH} and restart to continue."
        )
    if daily_cap is not None and spent_today >= float(daily_cap):
        return False, (
            f"model lock: daily spend cap reached for {d}. "
            f"spent ${spent_today:.4f} of ${float(daily_cap):.2f}. "
            f"Resets at 00:00 UTC, or raise caps.daily_usd in {POLICY_PATH}."
        )

    usable, age = portal_usable_now(policy, state)
    if usable is not None:
        reserve = _portal_reserve(policy)
        if usable <= reserve:
            return False, (
                f"model lock: Nous portal credits at ${usable:.2f}, at or below the reserve of ${reserve:.2f}. "
                f"Portal read {int(age)}s ago. Top up the Nous account, or lower caps.portal_reserve_usd in {POLICY_PATH}."
            )
    return True, ""


def cap_headroom(policy: dict, state: dict, model: str, bucket: str = "default") -> dict:
    """{'remaining_usd': min over caps, 'worst': (name, spent, cap, frac)}."""
    caps = policy.get("caps", {})
    d = today()
    rows = []

    def add(name, spent, cap):
        try:
            if cap is not None and float(cap) > 0:
                rows.append((name, float(spent or 0.0), float(cap), float(spent or 0.0) / float(cap)))
        except (TypeError, ValueError):
            pass

    add("total", state.get("total_usd", 0.0), caps.get("total_usd"))
    add("daily", state.get("days", {}).get(d, 0.0), caps.get("daily_usd"))
    add(f"model:{model}", state.get("model_days", {}).get(d, {}).get(model, 0.0),
        (caps.get("per_model_daily_usd") or {}).get(model))
    bconf = (policy.get("buckets") or {}).get(bucket) or {}
    add(f"bucket:{bucket}", state.get("bucket_days", {}).get(d, {}).get(bucket, 0.0), bconf.get("daily_usd"))
    add(f"bucket-total:{bucket}", state.get("buckets", {}).get(bucket, 0.0), bconf.get("total_usd"))
    usable, _ = portal_usable_now(policy, state)
    if usable is not None:
        total_credits = float((state.get("portal") or {}).get("total_usable_credits") or 0.0)
        reserve = _portal_reserve(policy)
        budget = total_credits - reserve
        if budget > 0:
            add("portal", budget - (usable - reserve), budget)
    if not rows:
        return {"remaining_usd": None, "worst": None, "rows": []}
    worst = max(rows, key=lambda r: r[3])
    return {"remaining_usd": round(min(c - s for _, s, c, _ in rows), 4), "worst": worst, "rows": rows}


def maybe_warn(policy: dict, state: dict, head: dict, bucket: str):
    """Return 'name:pct' when a threshold is crossed; write ONE line per cap/threshold/day.

    Caller holds _state_lock and saves state afterwards.
    """
    if not head or not head.get("worst"):
        return None
    thr = (policy.get("caps") or {}).get("warn_at") or [0.8, 0.95]
    name, spent, cap, frac = head["worst"]
    hit = None
    for t in thr:
        try:
            if frac >= float(t) and (hit is None or float(t) > hit):
                hit = float(t)
        except (TypeError, ValueError):
            continue
    if hit is None:
        return None
    key = f"{today()}|{name}|{int(round(hit * 100))}"
    warned = state.setdefault("warned", {})
    if key not in warned:
        warned[key] = now_iso()
        line = f"{now_iso()} WARN {name} at {frac * 100:.0f}% (${spent:.4f} of ${cap:.2f}) bucket={bucket}\n"
        try:
            with open(WARN_PATH, "a") as fh:
                fh.write(line)
        except OSError:
            pass
        sys.stderr.write(line)
    return f"{name}:{int(round(hit * 100))}"


def choose_lane(policy: dict, state: dict, model: str, bucket: str) -> tuple:
    """(model_to_use, rewrite_reason, deny_reason).

    Global, bucket and portal caps deny. A per-model cap degrades to the other
    allowed lane when policy.degrade.enabled, because the other lane has its
    own per-model budget and the caller would rather finish than 402.
    """
    allowed, why = cap_status(policy, state, model, bucket)
    if allowed:
        return model, "", ""
    if not why.startswith("model lock: daily cap for ") or why.startswith("model lock: daily cap for pipeline"):
        return None, "", why
    deg = policy.get("degrade") or {}
    if not deg.get("enabled", False):
        return None, "", why
    allow = policy.get("allow", [])
    for alt in deg.get("order") or allow:
        if alt == model or alt not in allow:
            continue
        ok, _ = cap_status(policy, state, alt, bucket)
        if ok:
            return alt, f"degraded from {model}: per-model daily cap", ""
    return None, "", why


def resolve_model(policy: dict, requested: str) -> tuple:
    """Map a requested model to an allowed one. Returns (model, reason)."""
    allow = policy.get("allow", [])
    alias = {k: v for k, v in policy.get("alias", {}).items() if not k.startswith("_")}

    if requested in allow:
        return requested, ""
    if requested in alias and alias[requested] in allow:
        return alias[requested], f"aliased from {requested}"
    if policy.get("coerce_unknown_to_default"):
        default = policy.get("default_model")
        if default in allow:
            return default, f"coerced from {requested}"
    return None, (
        f"model lock: '{requested}' is not permitted. "
        f"This harness is locked to: {', '.join(allow)}. "
        f"Edit allow[] in {POLICY_PATH} and restart the proxy to change that."
    )


def bucket_from_headers(headers, policy: dict) -> str:
    """The inbound bearer is a pipeline LABEL, never a secret: the upstream key
    lives in upstream.env. Unknown or missing bearer -> default."""
    auth = headers.get("Authorization") or ""
    tok = auth[7:].strip() if auth.lower().startswith("bearer ") else ""
    buckets = policy.get("buckets") or {}
    if tok and tok in buckets and _BUCKET_RE.match(tok):
        return tok
    return "default"


# --- upstream transport -------------------------------------------------------
# MEASURED 2026-08-20: Cloudflare in front of Nous STALLS the Python urllib
# client rather than refusing it. Identical headers and body via curl return 200
# in ~2.5s; via urllib they hang past 100s. A refusal is visible in a log, a
# stall bills and returns nothing, so this was invisible until isolated by
# elimination. Setting a User-Agent cannot fix it because the fingerprint being
# matched sits below the header layer. Do not revert this to urllib.
#
# 2026-09-17: headers travel in a `curl -K -` config on stdin so the upstream
# key never appears in argv; the body goes through a 0600 temp file.

def _cfg_quote(v: str) -> str:
    return '"' + str(v).replace("\\", "\\\\").replace('"', '\\"') + '"'


def _wall_and_stall(policy: dict, model: str) -> tuple:
    caps = policy.get("caps") or {}
    wall = (caps.get("max_wall_s") or {}).get(model, caps.get("default_wall_s", 300))
    stall = caps.get("stall_s", 60)
    try:
        wall = int(wall)
    except (TypeError, ValueError):
        wall = 300
    try:
        stall = int(stall)
    except (TypeError, ValueError):
        stall = 60
    return max(5, wall), max(1, stall)


def _write_body_tmp(body: bytes) -> str:
    tmp = tempfile.NamedTemporaryFile(prefix="ml-body-", dir=ROOT, delete=False)
    try:
        tmp.write(body)
    finally:
        tmp.close()
    os.chmod(tmp.name, 0o600)
    return tmp.name


def _curl_config(url: str, headers: dict, body_path: str, wall_s: int, stall_s: int, include: bool) -> bytes:
    cfg = "".join(f"header = {_cfg_quote(k + ': ' + str(v))}\n" for k, v in headers.items())
    cfg += f"url = {_cfg_quote(url)}\nrequest = \"POST\"\ndata-binary = {_cfg_quote('@' + body_path)}\n"
    cfg += "silent\nshow-error\nno-buffer\n"
    if include:
        cfg += "include\n"
    cfg += f"connect-timeout = 15\nspeed-limit = 1\nspeed-time = {stall_s}\nmax-time = {wall_s}\n"
    return cfg.encode()


class _CurlResponse:
    def __init__(self, body: bytes, status: int):
        self._body, self.status, self.code = body, status, status
        self.headers = {"Content-Type": "application/json"}

    def read(self) -> bytes:
        return self._body


class CurlTimeout(Exception):
    def __init__(self, exit_code: int, partial: bytes, stderr: str):
        super().__init__(f"curl exit {exit_code}: {stderr[:200]}")
        self.exit_code, self.partial = exit_code, partial


def _curl_post(url: str, body: bytes, headers: dict, wall_s: int, stall_s: int):
    """Buffered POST for non-streaming calls. Raises HTTPError on >=400,
    CurlTimeout on exit 28 (max-time or stall), URLError otherwise."""
    tmp = _write_body_tmp(body)
    try:
        cfg = _curl_config(url, headers, tmp, wall_s, stall_s, include=False)
        cfg += b'write-out = "\\n%{http_code}"\n'
        proc = subprocess.run(["curl", "-K", "-"], input=cfg, capture_output=True, timeout=wall_s + 20)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass
    err = proc.stderr.decode("utf-8", "replace")
    if proc.returncode == 28:
        raise CurlTimeout(28, proc.stdout, err)
    if proc.returncode != 0:
        raise urllib.error.URLError(f"curl exit {proc.returncode}: {err[:300]}")
    raw = proc.stdout
    nl = raw.rfind(b"\n")
    payload, status = (raw[:nl], int(raw[nl + 1:] or 0)) if nl != -1 else (raw, 0)
    if status >= 400:
        raise urllib.error.HTTPError(url, status, "upstream error", None, io.BytesIO(payload))
    return _CurlResponse(payload, status)


def _curl_stream(url: str, body: bytes, headers: dict, wall_s: int, stall_s: int):
    """Live POST. Returns (proc, status, upstream_headers, body_tmp_path).

    The caller reads proc.stdout line by line as curl receives it and must
    unlink body_tmp_path when done. status == 0 means curl never got a
    response line (connect failure, DNS, TLS); the reason is on proc.stderr.
    """
    tmp = _write_body_tmp(body)
    cfg = _curl_config(url, headers, tmp, wall_s, stall_s, include=True)
    proc = subprocess.Popen(["curl", "-K", "-"], stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    proc.stdin.write(cfg)
    proc.stdin.close()
    status, hdrs = 0, {}
    while True:  # header block(s); 100-continue safe
        line = proc.stdout.readline()
        if not line:
            break
        if line.startswith(b"HTTP/"):
            parts = line.split()
            try:
                status = int(parts[1])
            except (IndexError, ValueError):
                status = 0
            hdrs = {}
            continue
        if line in (b"\r\n", b"\n"):
            if status >= 200:
                break
            continue
        k, _, v = line.decode("latin1").partition(":")
        hdrs[k.strip().lower()] = v.strip()
    return proc, status, hdrs, tmp


def _estimate_usage(body: bytes, content_bytes: int) -> dict:
    """Fail-high estimate for a call whose usage chunk never arrived.

    bytes // 3 over-counts tokens on purpose; cached_tokens 0 bills the whole
    prompt at the "in" rate. An unknown must never price below the truth.
    """
    return {"prompt_tokens": len(body) // 3, "completion_tokens": max(1, content_bytes // 3),
            "prompt_tokens_details": {"cached_tokens": 0}}


# --- portal guard -------------------------------------------------------------
# The proxy NEVER refreshes the Nous OAuth token. Refresh tokens are single-use
# and rotate (hermes_cli/auth.py:5700-5720); an external caller that does not
# persist the rotated token revokes the whole chain. Read-only from auth.json;
# expired token or portal 401 => local caps only, never open.

def _nous_access_token() -> tuple:
    try:
        with open(AUTH_JSON) as fh:
            a = json.load(fh)
    except (OSError, ValueError) as exc:
        return None, f"auth.json unreadable: {exc}"
    st = (a.get("providers") or {}).get("nous") or {}
    if not st.get("access_token"):
        pool = (a.get("credential_pool") or {}).get("nous") or []
        st = pool[0] if pool else {}
    tok, exp = st.get("access_token"), st.get("expires_at")
    if not tok:
        return None, "no nous access_token in auth.json"
    try:
        exp_ts = datetime.fromisoformat(str(exp)).timestamp()
    except Exception:
        exp_ts = 0
    if exp_ts and exp_ts - time.time() < 60:
        return None, f"access_token expires_at {exp} is past/expiring; waiting for Hermes to rotate it"
    return tok, ""


def _portal_fetch(tok: str) -> dict:
    """GET /api/oauth/account; token travels in a stdin config, never argv."""
    cfg = (f"url = {_cfg_quote(PORTAL_URL + '/api/oauth/account')}\n"
           f"header = {_cfg_quote('Authorization: Bearer ' + tok)}\n"
           'header = "Accept: application/json"\nmax-time = 15\nsilent\nshow-error\n'
           'write-out = "\\n%{http_code}"\n')
    proc = subprocess.run(["curl", "-K", "-"], input=cfg.encode(), capture_output=True, timeout=30)
    raw = proc.stdout
    nl = raw.rfind(b"\n")
    body = raw[:nl] if nl != -1 else raw
    try:
        status = int(raw[nl + 1:] or 0) if nl != -1 else 0
    except ValueError:
        status = 0
    if proc.returncode != 0 or status != 200:
        raise RuntimeError(f"portal http {status} curl exit {proc.returncode} {body[:200]!r}")
    return json.loads(body)


def _num(v):
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None


def _find_key(obj, key):
    """First value for `key` in a nested dict (portal payload shape is not ours)."""
    if isinstance(obj, dict):
        if key in obj:
            return obj[key]
        for v in obj.values():
            r = _find_key(v, key)
            if r is not None:
                return r
    return None


def portal_sync(reason: str) -> dict:
    """One portal read into state["portal"]. Returns the portal dict."""
    try:
        policy = load_policy()
    except Exception as exc:
        return {"last_error": f"policy unreadable: {exc}"}
    pol = policy.get("portal") or {}
    if not pol.get("enabled"):
        return {"enabled": False}
    tok, why = _nous_access_token()
    with _state_lock:
        try:
            st = load_state()
        except StateUnavailable as exc:
            return {"last_error": str(exc)}
        p = st.setdefault("portal", {})
        if tok is None:
            p["last_error"], p["last_error_at"] = why, now_iso()
            save_state(st)
            sys.stderr.write(f"{now_iso()} PORTAL skipped: {why}\n")
            return dict(p)
        try:
            acct = _portal_fetch(tok)
        except Exception as exc:  # 401/timeout/etc: stale, never open
            p["last_error"], p["last_error_at"] = str(exc)[:300], now_iso()
            save_state(st)
            sys.stderr.write(f"{now_iso()} PORTAL read failed: {str(exc)[:200]}\n")
            return dict(p)
        prev_spend, prev_ledger = p.get("member_spend_usd"), p.get("ledger_total_at_read")
        p.update({
            "read_at": now_iso(), "reason": reason, "last_error": None,
            "total_usable_credits": _num(_find_key(acct, "total_usable_credits")),
            "subscription_credits_remaining": _num(_find_key(acct, "subscription_credits_remaining")),
            "purchased_credits_remaining": _num(_find_key(acct, "purchased_credits_remaining")),
            "member_spend_usd": _num(_find_key(acct, "member_spend_usd")),
            "period_end": _find_key(acct, "current_period_end"),
            "ledger_total_at_read": float(st.get("total_usd", 0.0)),
            "reads": int(p.get("reads", 0)) + 1,
        })
        if p["total_usable_credits"] is None:
            p["last_error"] = "portal payload has no total_usable_credits; keys=" + ",".join(sorted(acct.keys()))[:200]
        if isinstance(prev_spend, (int, float)) and isinstance(prev_ledger, (int, float)) \
                and isinstance(p["member_spend_usd"], (int, float)):
            d_portal = float(p["member_spend_usd"]) - float(prev_spend)
            d_ledger = p["ledger_total_at_read"] - float(prev_ledger)
            p["drift_usd"] = round(d_ledger - d_portal, 6)
            p["drift_ratio"] = round(d_ledger / d_portal, 3) if d_portal > 0 else None
            line = (f"{now_iso()} PORTAL spend+{d_portal:.4f} ledger+{d_ledger:.4f} "
                    f"drift {p['drift_usd']:+.4f} usable {p['total_usable_credits']}\n")
            sys.stderr.write(line)
            if abs(p["drift_usd"]) > float(pol.get("drift_warn_usd", 0.25)):
                try:
                    with open(WARN_PATH, "a") as fh:
                        fh.write("WARN " + line)
                except OSError:
                    pass
        else:
            sys.stderr.write(f"{now_iso()} PORTAL read ok usable={p['total_usable_credits']} "
                             f"spend={p['member_spend_usd']} reason={reason}\n")
        save_state(st)
        return dict(p)


def _portal_timer() -> None:
    while True:
        try:
            pol = load_policy().get("portal") or {}
            every = float(pol.get("every_seconds", 300))
            if pol.get("enabled"):
                portal_sync("timer")
        except Exception as exc:
            sys.stderr.write(f"{now_iso()} PORTAL timer error: {exc}\n")
            every = 300.0
        time.sleep(max(30.0, every))


# --- catalog rate refresh -----------------------------------------------------

def refresh_rates(force: bool = True) -> int:
    """Re-read /v1/models pricing for allowed models; log a diff; write policy only when changed.

    Catalog prices are per token; policy is per Mtok. A model missing from the
    catalog keeps its old rate and is logged, never silently made free.
    """
    pol = load_policy()
    meta = pol.setdefault("rates_usd_per_mtok", {})
    last = meta.get("_read_at")
    every = float((pol.get("rates_refresh") or {}).get("every_s", 7 * 86400))
    if not force and last:
        try:
            if time.time() - datetime.fromisoformat(last).timestamp() < every:
                return 0
        except Exception:
            pass
    load_upstream_env()
    up = pol["upstreams"]["nous"]
    key = os.environ.get(up["key_env"], "")
    cfg = (f"url = {_cfg_quote(up['base_url'].rstrip('/') + '/models')}\n"
           f"header = {_cfg_quote('Authorization: Bearer ' + key)}\n"
           'header = "Accept: application/json"\nmax-time = 20\nsilent\nshow-error\n')
    proc = subprocess.run(["curl", "-K", "-"], input=cfg.encode(), capture_output=True, timeout=30)
    if proc.returncode != 0:
        line = f"{now_iso()} RATES fetch failed curl={proc.returncode} {proc.stderr.decode('utf-8', 'replace')[:200]}\n"
        sys.stderr.write(line)
        with open(RATES_LOG, "a") as fh:
            fh.write(line)
        return 1
    try:
        cat = {m.get("id"): m for m in (json.loads(proc.stdout).get("data") or []) if isinstance(m, dict)}
    except (ValueError, AttributeError) as exc:
        line = f"{now_iso()} RATES catalog unparsable: {exc}\n"
        sys.stderr.write(line)
        with open(RATES_LOG, "a") as fh:
            fh.write(line)
        return 1
    changes, notes = [], []
    for model in pol.get("allow", []):
        entry = cat.get(model)
        pr = (entry or {}).get("pricing") if isinstance(entry, dict) else None
        if not isinstance(pr, dict):
            changes.append(f"{model}: NOT IN CATALOG, kept")
            continue
        new = {}
        for src, dst in (("prompt", "in"), ("completion", "out"), ("input_cache_read", "cache_read")):
            try:
                v = float(pr.get(src))
            except (TypeError, ValueError):
                continue
            if v <= 0:
                continue
            # per-token values are < 1e-3 by construction (0.075/Mtok = 7.5e-8/tok)
            new[dst] = round(v * 1e6, 6) if v < 1e-3 else round(v, 6)
        if "in" not in new or "out" not in new:
            changes.append(f"{model}: incomplete pricing {pr}, kept")
            continue
        old = dict(meta.get(model) or {})
        old_cmp = {k: v for k, v in old.items() if not str(k).startswith("_")}
        if any(abs(float(old_cmp.get(k, 0)) - new[k]) > 1e-9 for k in new) or set(old_cmp) != set(new):
            changes.append(f"{model}: {old_cmp} -> {new}")
            meta[model] = new
        else:
            notes.append(f"{model}: unchanged {new}")
        ctx = None
        for ck in ("context_length", "max_model_len", "max_context_length", "max_tokens"):
            if isinstance(entry.get(ck), int):
                ctx = entry[ck]
                break
        notes.append(f"{model}: catalog context_length={ctx} policy={(pol.get('context_length') or {}).get(model)}")
    rate_changed = any(" -> " in c for c in changes)
    line = f"{now_iso()} RATES read {len(cat)} catalog rows | " + " | ".join(changes + notes)
    if rate_changed:
        bak = POLICY_PATH + f".bak-rates-{time.strftime('%Y%m%d-%H%M%S')}"
        shutil.copy2(POLICY_PATH, bak)
        meta["_read_at"] = now_iso()
        tmp = POLICY_PATH + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(pol, fh, indent=2)
        os.replace(tmp, POLICY_PATH)
        line += f" | policy UPDATED (backup {bak})"
    else:
        line += " | no rate change, policy untouched"
    with open(RATES_LOG, "a") as fh:
        fh.write(line + "\n")
    sys.stderr.write(line + "\n")
    return 0


# --- stats --------------------------------------------------------------------

def _rem(cap, spent):
    try:
        return None if cap is None else round(float(cap) - float(spent or 0.0), 6)
    except (TypeError, ValueError):
        return None


def stats(policy: dict, state: dict) -> dict:
    d = today()
    caps = policy.get("caps") or {}
    buckets = {b: v for b, v in (policy.get("buckets") or {}).items() if not b.startswith("_") and isinstance(v, dict)}
    usable, age = portal_usable_now(policy, state)
    warn_tail = []
    try:
        with open(WARN_PATH) as fh:
            warn_tail = [ln.rstrip("\n") for ln in fh.readlines()[-20:]]
    except OSError:
        pass
    return {
        "ts": now_iso(), "today": d, "version": VERSION,
        "today_usd": round(float(state.get("days", {}).get(d, 0.0)), 6),
        "lifetime_usd": round(float(state.get("total_usd", 0.0)), 6),
        "per_model_today": state.get("model_days", {}).get(d, {}),
        "per_bucket_today": state.get("bucket_days", {}).get(d, {}),
        "per_bucket_lifetime": state.get("buckets", {}),
        "remaining": {
            "total": _rem(caps.get("total_usd"), state.get("total_usd", 0.0)),
            "daily": _rem(caps.get("daily_usd"), state.get("days", {}).get(d, 0.0)),
            "per_model": {m: _rem(c, state.get("model_days", {}).get(d, {}).get(m, 0.0))
                          for m, c in (caps.get("per_model_daily_usd") or {}).items() if not m.startswith("_")},
            "per_bucket_daily": {b: _rem(v.get("daily_usd"), state.get("bucket_days", {}).get(d, {}).get(b, 0.0))
                                 for b, v in buckets.items()},
            "per_bucket_total": {b: _rem(v.get("total_usd"), state.get("buckets", {}).get(b, 0.0))
                                 for b, v in buckets.items()},
            "portal_above_reserve": None if usable is None else round(usable - _portal_reserve(policy), 6),
        },
        "caps": {k: v for k, v in caps.items() if not k.startswith("_")},
        "calls": state.get("calls", 0), "blocked": state.get("blocked", 0),
        "portal": state.get("portal"),
        "portal_snapshot_age_s": None if age is None else int(age),
        "rates_read_at": (policy.get("rates_usd_per_mtok") or {}).get("_read_at"),
        "warned": state.get("warned", {}),
        "warn_log_tail": warn_tail,
        "state_source": "rebuilt" if state.get("rebuilt_from_ledger_at") else "file",
        "pid": os.getpid(),
    }


# --- HTTP handler -------------------------------------------------------------

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = VERSION
    _bucket = "default"

    def log_message(self, fmt, *args):  # quieter than the default
        sys.stderr.write("%s %s\n" % (now_iso(), fmt % args))

    # -- helpers ---------------------------------------------------------

    def _send_json(self, code: int, payload: dict, extra_headers=None) -> None:
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra_headers or {}).items():
            if v is not None:
                self.send_header(k, str(v))
        self.end_headers()
        self.wfile.write(body)

    def _drain_body(self) -> None:
        """Consume an unrouted POST body so keep-alive framing stays sane.
        Without this the JSON body is parsed as the next request line (400
        'Bad request syntax {"name":...}', measured 115 times on 2026-09-17)."""
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if 0 < n <= _MAX_BODY:
            self.rfile.read(n)
        elif n > _MAX_BODY:
            self.close_connection = True

    def _deny(self, code: int, message: str, requested: str = "", extra_headers=None) -> None:
        append_ledger({
            "ts": now_iso(), "event": "deny", "requested_model": requested,
            "code": code, "message": message, "path": self.path, "bucket": self._bucket,
        })
        try:
            with _state_lock:
                state = load_state()
                state["blocked"] = int(state.get("blocked", 0)) + 1
                save_state(state)
        except StateUnavailable:
            pass
        self._send_json(code, {"error": {"message": message, "type": "model_lock", "code": code}}, extra_headers)

    # -- routes ----------------------------------------------------------

    def do_GET(self):
        path = self.path.split("?", 1)[0].rstrip("/")
        try:
            policy = load_policy()
        except Exception as exc:
            self._send_json(500, {"error": {"message": f"model lock: policy unreadable: {exc}"}})
            return

        if path in ("/healthz", "/v1/healthz"):
            try:
                state = load_state()
            except StateUnavailable as exc:
                self._send_json(503, {"ok": False, "state": "unavailable", "error": str(exc)})
                return
            self._send_json(200, {
                "ok": True, "allow": policy.get("allow", []), "version": VERSION,
                "spent_total_usd": round(float(state.get("total_usd", 0.0)), 6),
                "spent_today_usd": round(float(state.get("days", {}).get(today(), 0.0)), 6),
                "caps": {k: v for k, v in policy.get("caps", {}).items() if not k.startswith("_")},
                "calls": state.get("calls", 0), "blocked": state.get("blocked", 0),
            })
            return

        if path in ("/stats", "/v1/stats"):
            try:
                self._send_json(200, stats(policy, load_state()))
            except StateUnavailable as exc:
                self._send_json(503, {"error": {"message": str(exc), "type": "model_lock"}})
            return

        if path in ("/portal-sync", "/v1/portal-sync"):
            self._send_json(200, portal_sync("manual"))
            return

        if path in ("/policy", "/v1/policy"):
            self._send_json(200, policy)
            return

        if path in ("/v1/models", "/models"):
            # Advertise only what is permitted, so anything that enumerates
            # models cannot even see an expensive one to ask for.
            self._send_json(200, {
                "object": "list",
                "data": [self._model_card(policy, m) for m in policy.get("allow", [])],
            })
            return

        if path.startswith("/v1/models/") or path.startswith("/models/"):
            mid = path.split("/models/", 1)[1]
            m, _ = resolve_model(policy, mid)
            if m is None:
                self._send_json(404, {"error": {"message": f"model lock: '{mid}' is not permitted", "type": "model_lock"}})
                return
            self._send_json(200, self._model_card(policy, m))
            return

        # Hermes provider sweep (agent/model_metadata.py detect_local_server_type):
        # /api/v1/models 200 => lm-studio; /api/tags 200 with "models" => ollama
        # (triggers /api/show probes); /v1/props with default_generation_settings
        # => llama.cpp; /version with "version" => vllm, which nothing else acts
        # on. Terminate the sweep on /version; answer the earlier ones 200
        # WITHOUT the classifying keys; keep /api/v1/models a 404.
        if path == "/version":
            self._send_json(200, {"version": VERSION})
            return
        if path in ("/api/tags", "/v1/props", "/props"):
            self._send_json(200, {"object": "hermes-modellock", "note": "not ollama, not llama.cpp"})
            return

        self._send_json(404, {"error": {"message": f"model lock: no route {path}"}})

    @staticmethod
    def _model_card(policy: dict, m: str) -> dict:
        card = {"id": m, "object": "model", "owned_by": "model-lock"}
        ctx = (policy.get("context_length") or {}).get(m)
        if isinstance(ctx, int) and ctx > 0:
            card["max_model_len"] = ctx
            card["context_length"] = ctx
        return card

    def do_POST(self):
        path = self.path.split("?", 1)[0].rstrip("/")
        if path not in ("/v1/chat/completions", "/v1/completions", "/v1/responses",
                        "/chat/completions", "/completions"):
            self._drain_body()
            if path == "/api/show":  # Ollama capability probe; benign stub
                self._send_json(200, {"capabilities": [], "model_info": {}, "parameters": "", "details": {}})
                return
            self._send_json(404, {"error": {"message": f"model lock: no route {path}"}})
            return

        try:
            policy = load_policy()
            load_upstream_env()
        except Exception as exc:
            self._drain_body()
            self._send_json(500, {"error": {"message": f"model lock: policy unreadable: {exc}"}})
            return

        self._bucket = bucket = bucket_from_headers(self.headers, policy)

        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > _MAX_BODY:
            self.close_connection = True
            self._deny(400, "model lock: missing or oversized request body")
            return
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw)
            if not isinstance(payload, dict):
                raise ValueError("not an object")
        except ValueError:
            self._deny(400, "model lock: request body is not JSON")
            return

        requested = payload.get("model") or ""
        model, reason = resolve_model(policy, requested)
        if model is None:
            self._deny(403, reason, requested)
            return

        try:
            state = load_state()
        except StateUnavailable as exc:
            append_ledger({"ts": now_iso(), "event": "deny", "requested_model": requested, "code": 503,
                           "message": str(exc), "path": self.path, "bucket": bucket})
            self._send_json(503, {"error": {"message": f"model lock: {exc}. Refusing rather than count from zero. "
                                                       f"Run: python3 {os.path.abspath(__file__)} --anchor recover",
                                            "type": "model_lock", "code": 503}},
                            {"Retry-After": "30"})
            return

        use, degrade_reason, deny_reason = choose_lane(policy, state, model, bucket)
        head = cap_headroom(policy, state, model, bucket)
        if use is None:
            self._deny(402, deny_reason, requested, {"X-ModelLock-Remaining-USD": head.get("remaining_usd"),
                                                     "X-ModelLock-Bucket": bucket})
            return
        degraded_from = None
        if degrade_reason:
            degraded_from = model
            reason = (reason + "; " if reason else "") + degrade_reason
            model = use
            head = cap_headroom(policy, state, model, bucket)

        with _state_lock:
            try:
                st2 = load_state()
                warn = maybe_warn(policy, st2, head, bucket)
                if warn:
                    save_state(st2)
            except StateUnavailable:
                warn = None
        extra = {"X-ModelLock-Remaining-USD": head.get("remaining_usd"), "X-ModelLock-Bucket": bucket}
        if warn:
            extra["X-ModelLock-Warning"] = warn
        if degraded_from:
            extra["X-ModelLock-Degraded"] = f"{degraded_from} -> {model}"

        payload["model"] = model

        # Injected, not requested: V4 Flash returns an all-reasoning, zero
        # content turn without effort=none; glm REFUSES none (HTTP 400
        # "Reasoning is mandatory"). On a degrade the target's override MUST
        # overwrite whatever the caller sent for the original lane.
        override = policy.get("reasoning_overrides", {}).get(model)
        if override and (degraded_from or "reasoning" not in payload):
            payload["reasoning"] = {"effort": override}

        max_tok = policy.get("caps", {}).get("per_call_max_tokens")
        if max_tok:
            current = payload.get("max_tokens")
            if not isinstance(current, int) or current > int(max_tok):
                payload["max_tokens"] = int(max_tok)

        streaming = bool(payload.get("stream"))
        if streaming:
            # Ask for usage on the terminal chunk so streamed calls are priced
            # like every other call rather than silently counting as zero.
            opts = payload.get("stream_options")
            payload["stream_options"] = {**opts, "include_usage": True} if isinstance(opts, dict) else {"include_usage": True}

        up_name = policy.get("model_upstream", {}).get(model)
        upstream = policy.get("upstreams", {}).get(up_name or "")
        if not isinstance(upstream, dict):
            self._deny(500, f"model lock: no upstream configured for '{model}'", requested)
            return
        api_key = os.environ.get(upstream.get("key_env", ""), "")
        if not api_key:
            self._deny(500, (
                f"model lock: upstream key {upstream.get('key_env')} is not set. "
                f"Put it in {UPSTREAM_ENV} (chmod 600) and restart the proxy."
            ), requested)
            return

        url = upstream["base_url"].rstrip("/") + "/" + path.split("/v1/", 1)[-1].lstrip("/")
        if "/v1/" not in path:
            url = upstream["base_url"].rstrip("/") + path

        body = json.dumps(payload).encode()
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
            # Nous sits behind Cloudflare, which answers error 1010 to the
            # default Python-urllib signature. Send a normal client UA instead.
            "User-Agent": "curl/8.7.1",
            "Accept": "text/event-stream" if streaming else "application/json",
        }
        if up_name == "openrouter":
            headers["HTTP-Referer"] = "https://localhost/hermes-modellock"
            headers["X-Title"] = "hermes-modellock"

        wall_s, stall_s = _wall_and_stall(policy, model)
        ctx = dict(policy=policy, model=model, requested=requested, reason=reason,
                   started=time.time(), up_name=up_name, bucket=bucket, extra=extra)
        if streaming:
            self._relay_stream(url, body, headers, wall_s, stall_s, ctx)
        else:
            self._relay_once(url, body, headers, wall_s, stall_s, ctx)

    # -- relays ----------------------------------------------------------

    def _record(self, policy, model, requested, reason, started, usage, streamed, upstream_name="",
                bucket="default", source_override=None):
        prompt_tok = int((usage or {}).get("prompt_tokens") or 0)
        completion_tok = int((usage or {}).get("completion_tokens") or 0)
        details = (usage or {}).get("prompt_tokens_details") or {}
        cached_tok = int(details.get("cached_tokens") or 0) if isinstance(details, dict) else 0
        upstream_cost = (usage or {}).get("cost")
        local_cost = price(policy, model, prompt_tok, completion_tok, cached_tok)

        # Some upstreams report a constant placeholder rather than real cost.
        # Nous returns exactly 0.00005 whether the call is 13 tokens or 5,008,
        # measured 2026-08-12. Trusting that under-counts a real agentic turn by
        # about twenty times, which would let a spend cap sit there never firing
        # while the balance drains. Where the upstream is not trusted, take the
        # larger of the two so the ledger can err high but never low.
        trusted = policy.get("upstreams", {}).get(upstream_name, {}).get("trust_upstream_cost", True)
        if source_override:
            cost, source = local_cost, source_override
        elif isinstance(upstream_cost, (int, float)):
            if trusted:
                cost, source = float(upstream_cost), "upstream"
            else:
                cost = max(local_cost, float(upstream_cost))
                source = "local_rates" if local_cost >= float(upstream_cost) else "upstream_floor"
        else:
            cost, source = local_cost, "local_rates"

        running_total, state_write, calls = None, "ok", 0
        try:
            with _state_lock:
                state = load_state()
                _apply_cost(state, model, bucket, cost, today())
                save_state(state)
                running_total = state["total_usd"]
                calls = int(state.get("calls", 0))
        except StateUnavailable as exc:
            state_write = "failed"
            sys.stderr.write(f"{now_iso()} WARN model lock: spend ${cost:.6f} not applied to state: {exc}\n")

        row = {
            "ts": now_iso(), "event": "call", "model": model, "bucket": bucket,
            "requested_model": requested, "rewrite": reason or None,
            "prompt_tokens": prompt_tok, "completion_tokens": completion_tok,
            "cached_tokens": cached_tok,
            "cost_usd": round(cost, 8), "cost_source": source,
            "running_total_usd": None if running_total is None else round(running_total, 8),
            "latency_s": round(time.time() - started, 3), "streamed": streamed,
        }
        if source_override:
            row["partial"] = True
        if state_write != "ok":
            row["state_write"] = state_write
        append_ledger(row)

        pol = policy.get("portal") or {}
        try:
            every_calls = int(pol.get("every_calls", 50))
        except (TypeError, ValueError):
            every_calls = 50
        if pol.get("enabled") and calls and every_calls > 0 and calls % every_calls == 0:
            threading.Thread(target=portal_sync, args=("calls",), daemon=True).start()

    def _relay_upstream_error(self, status: int, err_body: bytes, ctx: dict) -> None:
        append_ledger({
            "ts": now_iso(), "event": "upstream_error", "model": ctx["model"], "bucket": ctx["bucket"],
            "requested_model": ctx["requested"], "status": status,
            "body": err_body.decode("utf-8", "replace")[:2000],
        })
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(err_body)))
        for k, v in ctx["extra"].items():
            self.send_header(k, str(v))
        self.end_headers()
        self.wfile.write(err_body)

    def _relay_once(self, url, body, headers, wall_s, stall_s, ctx):
        policy, model = ctx["policy"], ctx["model"]
        try:
            resp = _curl_post(url, body, headers, wall_s, stall_s)
        except urllib.error.HTTPError as exc:
            self._relay_upstream_error(exc.code, exc.read(), ctx)
            return
        except CurlTimeout as exc:
            # The upstream may have billed for whatever it generated; price
            # the partial fail-high and tell the client it timed out.
            usage = _estimate_usage(body, len(exc.partial))
            self._record(policy, model, ctx["requested"], ctx["reason"], ctx["started"], usage, False,
                         ctx["up_name"], ctx["bucket"], source_override=f"partial_estimate:curl_exit_{exc.exit_code}")
            self._send_json(504, {"error": {"message": f"model lock: upstream timed out after wall {wall_s}s / stall {stall_s}s "
                                                       f"(curl exit {exc.exit_code}); partial priced fail-high",
                                            "type": "model_lock", "code": 504}}, ctx["extra"])
            return
        except Exception as exc:
            self._deny(502, f"model lock: upstream unreachable: {exc}", ctx["requested"])
            return

        data = resp.read()
        try:
            parsed = json.loads(data)
            usage = parsed.get("usage") or {}
        except (ValueError, AttributeError):
            usage = {}
        self._record(policy, model, ctx["requested"], ctx["reason"], ctx["started"], usage, False,
                     ctx["up_name"], ctx["bucket"])
        self.send_response(resp.status)
        self.send_header("Content-Type", resp.headers.get("Content-Type", "application/json"))
        self.send_header("Content-Length", str(len(data)))
        for k, v in ctx["extra"].items():
            self.send_header(k, str(v))
        self.end_headers()
        self.wfile.write(data)

    def _write_chunk(self, data: bytes) -> None:
        self.wfile.write(b"%x\r\n" % len(data) + data + b"\r\n")
        self.wfile.flush()

    def _relay_stream(self, url, body, headers, wall_s, stall_s, ctx):
        """Live relay: each SSE line goes to the client as curl receives it.

        Chunked transfer encoding gives the client unambiguous framing (the
        2026-08-23 buffered relay used Content-Length for the same reason) and
        `data: [DONE]` is guaranteed even when the upstream omits it. The usage
        chunk is parsed on the way through; if curl exits before it arrives
        (stall, wall time, hang-up) the call is priced from the bytes seen,
        fail-high, as cost_source partial_estimate:curl_exit_N.
        """
        policy, model = ctx["policy"], ctx["model"]
        proc, status, _, tmp = _curl_stream(url, body, headers, wall_s, stall_s)
        usage, content_bytes, saw_done, client_gone, started_relay = {}, 0, False, False, False
        try:
            if status == 0:
                try:
                    proc.wait(timeout=wall_s + 5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                err = proc.stderr.read().decode("utf-8", "replace")
                if proc.returncode == 28:
                    partial = proc.stdout.read()
                    usage = _estimate_usage(body, len(partial))
                    self._record(policy, model, ctx["requested"], ctx["reason"], ctx["started"], usage, True,
                                 ctx["up_name"], ctx["bucket"], source_override="partial_estimate:curl_exit_28")
                    usage = None  # already recorded
                    self._send_json(504, {"error": {"message": f"model lock: upstream produced no response within "
                                                               f"stall {stall_s}s / wall {wall_s}s (curl exit 28)",
                                                    "type": "model_lock", "code": 504}}, ctx["extra"])
                    return
                self._deny(502, f"model lock: upstream unreachable: curl exit {proc.returncode}: {err[:300]}", ctx["requested"])
                usage = None
                return
            if status >= 400:
                err_body = proc.stdout.read()
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    proc.kill()
                self._relay_upstream_error(status, err_body, ctx)
                usage = None
                return

            self.send_response(status)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Transfer-Encoding", "chunked")
            for k, v in ctx["extra"].items():
                self.send_header(k, str(v))
            self.end_headers()
            started_relay = True
            for line in iter(proc.stdout.readline, b""):
                if line.startswith(b"data:"):
                    chunk = line[5:].strip()
                    if chunk == b"[DONE]":
                        saw_done = True
                    elif chunk:
                        try:
                            obj = json.loads(chunk)
                            if isinstance(obj, dict):
                                if isinstance(obj.get("usage"), dict):
                                    usage = obj["usage"]
                                for ch in obj.get("choices") or []:
                                    delta = (ch.get("delta") or {}) if isinstance(ch, dict) else {}
                                    content_bytes += len(((delta.get("content") or "")).encode())
                                    content_bytes += len(((delta.get("reasoning_content") or delta.get("reasoning") or "")
                                                          if isinstance(delta.get("reasoning_content") or delta.get("reasoning"), str)
                                                          else "").encode())
                        except ValueError:
                            pass
                if not client_gone:
                    try:
                        self._write_chunk(line)
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        client_gone = True
                        try:
                            proc.terminate()
                        except OSError:
                            pass
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
            if not client_gone:
                try:
                    if not saw_done:
                        self._write_chunk(b"data: [DONE]\n\n")
                    self.wfile.write(b"0\r\n\r\n")
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError, OSError):
                    client_gone = True
            if client_gone:
                self.close_connection = True
        finally:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            if usage is not None:  # None = already recorded or nothing billed (403/5xx path)
                source = None
                if not usage:
                    usage = _estimate_usage(body, content_bytes)
                    rc = proc.returncode if proc.returncode is not None else -1
                    source = f"partial_estimate:curl_exit_{rc}" if started_relay else None
                    if source is None:
                        source = f"partial_estimate:curl_exit_{rc}"
                self._record(policy, model, ctx["requested"], ctx["reason"], ctx["started"], usage, True,
                             ctx["up_name"], ctx["bucket"], source_override=source)


class Server(socketserver.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, (BrokenPipeError, ConnectionResetError)):
            sys.stderr.write(f"{now_iso()} client {client_address[0]} hung up: {type(exc).__name__}\n")
            return
        super().handle_error(request, client_address)


# --- signals and rotation -----------------------------------------------------

def _reopen_logs(signum=None, frame=None) -> None:
    """SIGHUP: reopen proxy.log (newsyslog renamed it) and anchor the ledger."""
    try:
        fd = os.open(LOG_PATH, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
        os.dup2(fd, 1)
        os.dup2(fd, 2)
        os.close(fd)
    except OSError as exc:
        sys.stderr.write(f"{now_iso()} model lock: log reopen failed: {exc}\n")
    try:
        with _state_lock:
            write_anchor(load_state(), "sighup")
    except StateUnavailable as exc:
        sys.stderr.write(f"{now_iso()} model lock: no anchor on SIGHUP: {exc}\n")
    sys.stderr.write(f"{now_iso()} model lock: logs reopened, anchor written\n")


def _install_signals() -> None:
    try:
        with open(PID_PATH, "w") as fh:
            fh.write(str(os.getpid()))
    except OSError:
        pass
    signal.signal(signal.SIGHUP, _reopen_logs)


# --- main ---------------------------------------------------------------------

def main() -> int:
    os.makedirs(ROOT, exist_ok=True)
    argv = sys.argv[1:]
    if argv and argv[0] == "--anchor":
        reason = argv[1] if len(argv) > 1 else "manual"
        try:
            with _state_lock:
                state = load_state()
                write_anchor(state, reason)
        except StateUnavailable as exc:
            sys.stderr.write(f"model lock: cannot anchor: {exc}\n")
            return 2
        print(json.dumps({"anchored": True, "reason": reason, "total_usd": state.get("total_usd"),
                          "today_usd": state.get("days", {}).get(today(), 0.0), "ledger": LEDGER_PATH}))
        return 0
    if argv and argv[0] == "--refresh-rates":
        return refresh_rates(force=True)
    if argv and argv[0] == "--portal-sync":
        print(json.dumps(portal_sync("cli"), indent=2))
        return 0
    if argv and argv[0] == "--stats":
        try:
            print(json.dumps(stats(load_policy(), load_state()), indent=2))
            return 0
        except StateUnavailable as exc:
            sys.stderr.write(f"model lock: {exc}\n")
            return 2

    try:
        policy = load_policy()
    except Exception as exc:
        sys.stderr.write(f"model lock: cannot start, policy unreadable: {exc}\n")
        return 2
    load_upstream_env()

    try:
        with _state_lock:
            state = load_state()
            write_anchor(state, "startup")
    except StateUnavailable as exc:
        # Fail closed: launchd retries every 10 s; the harness sees a refused
        # connection, which is the documented contract, never a zeroed ledger.
        sys.stderr.write(f"{now_iso()} model lock: cannot start, {exc}. "
                         f"Restore state.json or append an anchor row and retry.\n")
        return 2

    host = policy.get("listen_host", "127.0.0.1")
    port = int(os.environ.get("MODELLOCK_PORT") or policy.get("listen_port", 8788))
    if host not in ("127.0.0.1", "localhost", "::1"):
        sys.stderr.write("model lock: refusing to bind a non-loopback address\n")
        return 2

    srv = Server((host, port), Handler)
    _install_signals()
    threading.Thread(target=_portal_timer, daemon=True).start()
    sys.stderr.write(
        f"{now_iso()} {VERSION} listening on http://{host}:{port}/v1 root={ROOT} "
        f"allow={policy.get('allow')} caps={ {k: v for k, v in policy.get('caps', {}).items() if not k.startswith('_')} } "
        f"total={state.get('total_usd')}\n")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
