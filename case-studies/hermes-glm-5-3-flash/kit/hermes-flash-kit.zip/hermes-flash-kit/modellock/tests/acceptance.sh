#!/bin/bash
# Acceptance suite for the model-lock proxy. Runs a SECOND proxy on 8799
# against a scratch copy of the modellock dir plus a stdlib mock upstream on
# 8790. Production state, ledger and the launchd job are never touched.
#
# Usage: tests/acceptance.sh [--real N]     N = number of real 5-token glm
#        calls at the end (default 0; each costs < $0.0005). Everything else
#        is zero spend. Set S to choose the scratch dir.
#        MOCK_MODE=1 needs no live install: the sandbox is built from policy.example.json,
#        upstream.env.example, an empty ledger, a zero state and a dummy auth.json, and the
#        production-ledger checks (Z) are skipped. Without it, $PROD must hold a working
#        install (policy.json, state.json, upstream.env, ledger.jsonl) and ~/.hermes/auth.json
#        must be signed in.
set -u
MOCK_MODE="${MOCK_MODE:-0}"
HERE="$(cd "$(dirname "$0")" && pwd)"
PROXY="${PROXY:-$HERE/../proxy.py}"
PROD="${PROD:-$HOME/.hermes/modellock}"
S="${S:-/tmp/scratch/mlock-test}"
P=127.0.0.1:8799
M=127.0.0.1:8790
PY=/usr/bin/python3
REAL=0
[ "${1:-}" = "--real" ] && REAL="${2:-0}"
FAILS=0; PASSES=0
pass(){ echo "PASS $1"; PASSES=$((PASSES+1)); }
fail(){ echo "FAIL $1"; FAILS=$((FAILS+1)); }
check(){ if eval "$2"; then pass "$1"; else fail "$1"; fi; }
jget(){ $PY -c 'import sys,json; d=json.load(sys.stdin)
for k in sys.argv[1].split("."):
    d = d[int(k)] if isinstance(d, list) else d.get(k)
print(d)' "$1"; }
setpol(){ $PY - "$S/policy.json" "$1" <<'EOF'
import json,sys
p=json.load(open(sys.argv[1])); exec(sys.argv[2]); json.dump(p,open(sys.argv[1],"w"),indent=2)
EOF
}
post(){ curl -s -o "$S/b" -D "$S/h" -w '%{http_code}' "$P/v1/chat/completions" -H 'Content-Type: application/json' "$@"; }
BODY_GLM='{"model":"glm","messages":[{"role":"user","content":"hi"}],"max_tokens":5}'

if [ "$MOCK_MODE" = 1 ]; then
  PROD_ANCHORS_BEFORE=0; PROD_SMOKE_BEFORE=0
else
  for f in policy.json state.json upstream.env ledger.jsonl; do
    [ -f "$PROD/$f" ] || { echo "missing $PROD/$f (set MOCK_MODE=1 to run without a live install)" >&2; exit 2; }
  done
  [ -f "$HOME/.hermes/auth.json" ] || { echo "missing ~/.hermes/auth.json (set MOCK_MODE=1 to run without it)" >&2; exit 2; }
  PROD_ANCHORS_BEFORE=$(/usr/bin/grep -c '"event":"anchor"' "$PROD/ledger.jsonl")
  PROD_SMOKE_BEFORE=$(/usr/bin/grep -c '"bucket":"pl-smoke"' "$PROD/ledger.jsonl")
fi

# --- 0 sandbox --------------------------------------------------------------
rm -rf "$S"; mkdir -p "$S"
if [ "$MOCK_MODE" = 1 ]; then
  cp "$HERE/../policy.example.json" "$S/policy.json"; cp "$HERE/../upstream.env.example" "$S/upstream.env"
  echo '{"total_usd": 0.0, "days": {}, "model_days": {}, "calls": 0, "blocked": 0, "buckets": {}, "bucket_days": {}}' > "$S/state.json"
  : > "$S/ledger.jsonl"
else
  cp "$PROD/policy.json" "$PROD/state.json" "$PROD/upstream.env" "$S/"
  tail -200 "$PROD/ledger.jsonl" > "$S/ledger.jsonl"
fi
$PY "$HERE/patch_policy.py" "$S/policy.json" >/dev/null
setpol 'p["listen_port"]=8799; p["upstreams"]["nous"]["base_url"]="http://127.0.0.1:8790/v1"; p["portal"]["enabled"]=False; p["caps"]["stall_s"]=5; p["caps"]["default_wall_s"]=30; p["caps"]["max_wall_s"]={}'
if [ "$MOCK_MODE" = 1 ]; then
  echo '{"providers": {"nous": {"access_token": "mock-token", "expires_at": "2099-01-01T00:00:00+00:00"}}}' > "$S/auth.json"
else
  cp "$HOME/.hermes/auth.json" "$S/auth.json"
fi
chmod 600 "$S/auth.json"
pkill -f "mock_upstream.py" 2>/dev/null; pkill -f "MODELLOCK_PORT=8799" 2>/dev/null
lsof -ti tcp:8799 -sTCP:LISTEN | xargs kill 2>/dev/null; lsof -ti tcp:8790 -sTCP:LISTEN | xargs kill 2>/dev/null; sleep 0.5
MOCK_DIR="$S" MOCK_PORT=8790 $PY "$HERE/mock_upstream.py" > "$S/mock.log" 2>&1 &
MOCK_PID=$!
( cd "$S" && MODELLOCK_ROOT="$S" MODELLOCK_PORT=8799 MODELLOCK_AUTH_JSON="$S/auth.json" $PY "$PROXY" >> "$S/proxy.log" 2>&1 ) &
for i in $(seq 1 30); do curl -s -o /dev/null "$P/healthz" && break; sleep 0.2; done
PROXY_PID=$(cat "$S/proxy.pid" 2>/dev/null)
check "A0 proxy up on 8799 (pid $PROXY_PID)" '[ -n "$PROXY_PID" ] && curl -s "$P/healthz" | /usr/bin/grep -q "\"ok\": true"'
check "A0 startup anchor row in ledger" 'tail -1 "$S/ledger.jsonl" | /usr/bin/grep -q "\"event\":\"anchor\",\"reason\":\"startup\""'
check "A0 mock up on 8790" 'curl -s "$M/v1/models" | /usr/bin/grep -q glm'

# --- A1 body drain -----------------------------------------------------------
codes=$(curl -s -o /dev/null -w '%{http_code} ' -X POST "$P/api/show" -H 'Content-Type: application/json' -d '{"name":"z-ai/glm-5.3-flash"}' --next -s -o /dev/null -w '%{http_code}' "$P/v1/models")
check "A1 /api/show then /v1/models on one keep-alive connection = '200 200' (got '$codes')" '[ "$codes" = "200 200" ]'
check "A1 no 'Bad request syntax' in proxy.log" '! /usr/bin/grep -q "Bad request syntax" "$S/proxy.log"'
codes=$(curl -s -o /dev/null -w '%{http_code} ' -X POST "$P/api/nope" -H 'Content-Type: application/json' -d '{"x":1}' --next -s -o /dev/null -w '%{http_code}' "$P/healthz")
check "A1 unknown POST drained: 404 then 200 (got '$codes')" '[ "$codes" = "404 200" ]'

# --- A2 provider sweep --------------------------------------------------------
check "A2 /version 200 with version key" 'curl -s "$P/version" | /usr/bin/grep -q "\"version\""'
t=$(curl -s -w ' %{http_code}' "$P/api/tags")
check "A2 /api/tags 200 without models key ($t)" 'echo "$t" | /usr/bin/grep -q " 200$" && ! echo "$t" | /usr/bin/grep -q "\"models\""'
t=$(curl -s -w ' %{http_code}' "$P/v1/props")
check "A2 /v1/props 200 without default_generation_settings" 'echo "$t" | /usr/bin/grep -q " 200$" && ! echo "$t" | /usr/bin/grep -q default_generation_settings'
check "A2 /api/v1/models stays 404" '[ "$(curl -s -o /dev/null -w %{http_code} $P/api/v1/models)" = "404" ]'
t=$(curl -s "$P/v1/models/z-ai/glm-5.3-flash")
check "A2 /v1/models/<glm> serves max_model_len 1048576 ($t)" 'echo "$t" | /usr/bin/grep -q "\"max_model_len\": 1048576"'
check "A2 /v1/models/<alias glm> resolves" 'curl -s "$P/v1/models/glm" | /usr/bin/grep -q "z-ai/glm-5.3-flash"'
check "A2 /v1/models/<denied> 404" '[ "$(curl -s -o /dev/null -w %{http_code} $P/v1/models/deepseek/deepseek-v4-pro)" = "404" ]'

# --- A3 fail-closed state -----------------------------------------------------
anchor_total=$(curl -s "$P/healthz" | jget spent_total_usd)
c=$(post -d "$BODY_GLM"); c2=$(post -d "$BODY_GLM")
after_total=$(curl -s "$P/healthz" | jget spent_total_usd)
check "A3 two mock calls 200/200 and total grew ($anchor_total -> $after_total)" '[ "$c" = 200 ] && [ "$c2" = 200 ] && $PY -c "import sys; sys.exit(0 if float(\"$after_total\") > float(\"$anchor_total\") else 1)"'
cp "$S/state.json" "$S/state.good.json"
printf '{garbage' > "$S/state.json"
rebuilt=$(curl -s "$P/healthz" | jget spent_total_usd)
check "A3 corrupt state.json rebuilt from anchor+calls: $rebuilt == $after_total" '$PY -c "import sys; sys.exit(0 if abs(float(\"$rebuilt\")-float(\"$after_total\"))<1e-6 else 1)"'
check "A3 /stats state_source=rebuilt" '[ "$(curl -s $P/stats | jget state_source)" = rebuilt ]'
rm -f "$S/state.json"; mv "$S/ledger.jsonl" "$S/ledger.keep"; : > "$S/ledger.jsonl"
c=$(post -d "$BODY_GLM")
check "A3 no state + no anchor -> POST 503 (got $c)" '[ "$c" = 503 ]'
check "A3 no state.json written with zeros" '[ ! -e "$S/state.json" ]'
check "A3 /healthz 503 when state unavailable" '[ "$(curl -s -o /dev/null -w %{http_code} $P/healthz)" = 503 ]'
cat "$S/ledger.jsonl" >> "$S/ledger.keep"; mv "$S/ledger.keep" "$S/ledger.jsonl"; cp "$S/state.good.json" "$S/state.json"
check "A3 restored: /healthz 200" '[ "$(curl -s -o /dev/null -w %{http_code} $P/healthz)" = 200 ]'

# --- A4 warning headers ----------------------------------------------------------
today_spent=$(curl -s "$P/healthz" | jget spent_today_usd)
setpol "p['caps']['daily_usd']=max(1e-6, float('$today_spent')/0.85)"
: > "$S/warn.log"
c=$(post -d "$BODY_GLM")
check "A4 call at 85% still 200 (got $c)" '[ "$c" = 200 ]'
check "A4 X-ModelLock-Remaining-USD header present" '/usr/bin/grep -qi "^X-ModelLock-Remaining-USD:" "$S/h"'
check "A4 X-ModelLock-Warning: daily:80" '/usr/bin/grep -qi "^X-ModelLock-Warning: daily:80" "$S/h"'
post -d "$BODY_GLM" >/dev/null
check "A4 warn.log deduped: exactly 1 line after 2 calls ($(wc -l < "$S/warn.log" | tr -d ' '))" '[ "$(wc -l < "$S/warn.log" | tr -d " ")" = 1 ]'
setpol "p['caps']['daily_usd']=10.0"

# --- A5 degrade -----------------------------------------------------------------
setpol "p['caps']['per_model_daily_usd']['z-ai/glm-5.3-flash']=0.000001"
c=$(post -d '{"model":"glm","messages":[{"role":"user","content":"hi"}],"max_tokens":5,"reasoning":{"effort":"low"}}')
check "A5 per-model cap -> 200 via degrade (got $c)" '[ "$c" = 200 ]'
check "A5 X-ModelLock-Degraded header" '/usr/bin/grep -qi "^X-ModelLock-Degraded: z-ai/glm-5.3-flash -> deepseek/deepseek-v4-flash-0731" "$S/h"'
row=$(tail -1 "$S/ledger.jsonl")
check "A5 ledger row model=deepseek and rewrite mentions degraded" 'echo "$row" | /usr/bin/grep -q "\"model\":\"deepseek/deepseek-v4-flash-0731\"" && echo "$row" | /usr/bin/grep -q degraded'
eff=$(jget reasoning.effort < "$S/mock_last_request.json")
check "A5 mock saw reasoning.effort=none (overwrote caller's low): $eff" '[ "$eff" = none ]'
setpol "p['caps']['per_model_daily_usd']['deepseek/deepseek-v4-flash-0731']=0.000001"
c=$(post -d "$BODY_GLM")
check "A5 both per-model caps -> 402 (got $c)" '[ "$c" = 402 ] && /usr/bin/grep -q "daily cap for" "$S/b"'
setpol "p['caps']['per_model_daily_usd']={'z-ai/glm-5.3-flash':10.0,'deepseek/deepseek-v4-flash-0731':10.0}; p['caps']['daily_usd']=0.000001"
c=$(post -d "$BODY_GLM")
check "A5 global daily cap -> 402 with 'daily spend cap' (got $c)" '[ "$c" = 402 ] && /usr/bin/grep -q "daily spend cap" "$S/b"'
check "A5 402 carries X-ModelLock-Remaining-USD" '/usr/bin/grep -qi "^X-ModelLock-Remaining-USD:" "$S/h"'
setpol "p['caps']['daily_usd']=10.0"

# --- A6 buckets -----------------------------------------------------------------
c1=$(post -H "Authorization: Bearer pl-smoke" -d "$BODY_GLM"); c2=$(post -H "Authorization: Bearer nobody" -d "$BODY_GLM"); c3=$(post -d "$BODY_GLM")
check "A6 pl-smoke/nobody/none all 200 ($c1 $c2 $c3)" '[ "$c1$c2$c3" = 200200200 ]'
bd=$($PY -c 'import json,sys; s=json.load(open(sys.argv[1])); d=s["bucket_days"][max(s["bucket_days"])]; print(sorted(d))' "$S/state.json")
check "A6 state.bucket_days has pl-smoke and default: $bd" 'echo "$bd" | /usr/bin/grep -q "pl-smoke" && echo "$bd" | /usr/bin/grep -q default'
check "A6 ledger rows carry bucket field" '[ "$(tail -3 "$S/ledger.jsonl" | /usr/bin/grep -c "\"bucket\":\"")" = 3 ]'
check "A6 X-ModelLock-Bucket header = default for unknown bearer" '/usr/bin/grep -qi "^X-ModelLock-Bucket: default" "$S/h"'
setpol "p['buckets']['pl-smoke']['daily_usd']=0.000001"
c1=$(post -H "Authorization: Bearer pl-smoke" -d "$BODY_GLM"); m1=$(cat "$S/b")
c2=$(post -H "Authorization: Bearer nobody" -d "$BODY_GLM")
check "A6 pl-smoke capped -> 402 pipeline message, nobody still 200 ($c1 $c2)" '[ "$c1" = 402 ] && echo "$m1" | /usr/bin/grep -q "pipeline .pl-smoke." && [ "$c2" = 200 ]'
check "A6 bucket cap does NOT degrade (no Degraded header)" '! /usr/bin/grep -qi "X-ModelLock-Degraded" "$S/h"'
setpol "p['buckets']['pl-smoke']['daily_usd']=0.50"

# --- A7 stats + rotation ------------------------------------------------------------
st=$(curl -s "$P/stats")
check "A7 /stats has the required keys" 'for k in today_usd lifetime_usd per_model_today per_bucket_today per_bucket_lifetime remaining portal warned calls blocked; do echo "$st" | /usr/bin/grep -q "\"$k\"" || exit 1; done'
mv "$S/proxy.log" "$S/proxy.log.0"; kill -HUP "$PROXY_PID"; sleep 1
check "A7 SIGHUP reopened proxy.log (non-empty new file)" '[ -s "$S/proxy.log" ] && /usr/bin/grep -q "logs reopened" "$S/proxy.log"'
check "A7 SIGHUP wrote a sighup anchor" 'tail -1 "$S/ledger.jsonl" | /usr/bin/grep -q "\"event\":\"anchor\",\"reason\":\"sighup\""'
check "A7 proxy still serving after HUP" '[ "$(curl -s -o /dev/null -w %{http_code} $P/healthz)" = 200 ]'

# --- A8 live streaming -----------------------------------------------------------------
out=$(curl -sN -o "$S/stream.out" -w '%{time_starttransfer} %{time_total}' "$P/v1/chat/completions" -H 'Content-Type: application/json' -d '{"model":"glm","stream":true,"messages":[{"role":"user","content":"hello"}],"max_tokens":5}')
check "A8 normal stream: body has 3 deltas, usage and [DONE] (timing $out)" '[ "$(/usr/bin/grep -c "^data: " "$S/stream.out")" -ge 5 ] && /usr/bin/grep -q "cached_tokens" "$S/stream.out" && tail -c 20 "$S/stream.out" | /usr/bin/grep -q "\[DONE\]"'
check "A8 normal stream priced from usage (cached_tokens 90, local_rates|upstream_floor, streamed)" 'tail -1 "$S/ledger.jsonl" | /usr/bin/grep -Eq "\"cost_source\":\"(local_rates|upstream_floor)\"" && tail -1 "$S/ledger.jsonl" | /usr/bin/grep -q "\"cached_tokens\":90" && tail -1 "$S/ledger.jsonl" | /usr/bin/grep -q "\"streamed\":true"'
out=$(curl -sN -o "$S/slow.out" -w '%{time_starttransfer} %{time_total}' "$P/v1/chat/completions" -H 'Content-Type: application/json' -d '{"model":"glm","stream":true,"messages":[{"role":"user","content":"slow"}],"max_tokens":5}')
ttfb=${out% *}; total=${out#* }
check "A8 slow stream: first byte < 2 s (live relay), total < 12 s (stall 5 s): ttfb=$ttfb total=$total" '$PY -c "import sys; sys.exit(0 if float(\"$ttfb\")<2 and float(\"$total\")<12 else 1)"'
check "A8 slow stream: 3 deltas arrived and body ends with [DONE]" '[ "$(/usr/bin/grep -c "^data: {" "$S/slow.out")" = 3 ] && tail -c 20 "$S/slow.out" | /usr/bin/grep -q "\[DONE\]"'
check "A8 slow stream priced fail-high as partial_estimate:curl_exit_28" 'tail -1 "$S/ledger.jsonl" | /usr/bin/grep -q "\"cost_source\":\"partial_estimate:curl_exit_28\"" && tail -1 "$S/ledger.jsonl" | /usr/bin/grep -q "\"partial\":true"'
c=$(post -d '{"model":"glm","messages":[{"role":"user","content":"upstream400"}],"max_tokens":5}')
check "A8 upstream 400 relayed as 400 with upstream_error row (got $c)" '[ "$c" = 400 ] && tail -1 "$S/ledger.jsonl" | /usr/bin/grep -q "\"event\":\"upstream_error\""'

# --- A9 rates refresh (offline, mock catalog) ---------------------------------------------
: > "$S/rates_refresh.log"
MODELLOCK_ROOT="$S" $PY "$PROXY" --refresh-rates >/dev/null 2>&1
check "A9 refresh against identical catalog: policy untouched, log says no change" '/usr/bin/grep -q "no rate change" "$S/rates_refresh.log" && [ "$(ls "$S"/policy.json.bak-rates-* 2>/dev/null | wc -l | tr -d " ")" = 0 ]'
setpol "p['rates_usd_per_mtok']['z-ai/glm-5.3-flash']['in']=9.9"
MODELLOCK_ROOT="$S" $PY "$PROXY" --refresh-rates >/dev/null 2>&1
v=$($PY -c 'import json,sys; print(json.load(open(sys.argv[1]))["rates_usd_per_mtok"]["z-ai/glm-5.3-flash"])' "$S/policy.json")
check "A9 poisoned in=9.9 restored to 0.075 with backup + diff line: $v" 'echo "$v" | /usr/bin/grep -q "0.075" && /usr/bin/grep -q "9.9" "$S/rates_refresh.log" && [ "$(ls "$S"/policy.json.bak-rates-* | wc -l | tr -d " ")" = 1 ]'
check "A9 deepseek rate 0.04/0.1/0.01 intact" '$PY -c "import json,sys; r=json.load(open(sys.argv[1]))[\"rates_usd_per_mtok\"][\"deepseek/deepseek-v4-flash-0731\"]; sys.exit(0 if (r[\"in\"],r[\"out\"],r[\"cache_read\"])==(0.04,0.1,0.01) else 1)" "$S/policy.json"'

# --- A10 portal guard (expiry path offline; one real read only with --real) -------------------
setpol "p['portal']['enabled']=True"
$PY - "$S/auth.json" <<'EOF'
import json,sys
a=json.load(open(sys.argv[1])); a["providers"]["nous"]["expires_at"]="2020-01-01T00:00:00+00:00"
a["credential_pool"]={}
json.dump(a,open(sys.argv[1],"w"))
EOF
r=$(curl -s "$P/portal-sync")
check "A10 expired token: portal skipped with 'expir' error, no network" 'echo "$r" | /usr/bin/grep -q expir'
c=$(post -d "$BODY_GLM")
check "A10 expired token: POST still answers from local caps (got $c)" '[ "$c" = 200 ]'
# fake a fresh snapshot to test the reserve path with zero network
$PY - "$S/state.json" <<'EOF'
import json,sys,datetime
s=json.load(open(sys.argv[1]))
s["portal"]={"read_at":datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),"total_usable_credits":1.15,
             "ledger_total_at_read":float(s["total_usd"])-0.10,"member_spend_usd":2.0,"last_error":None}
json.dump(s,open(sys.argv[1],"w"),indent=2)
EOF
c=$(post -d "$BODY_GLM")
check "A10 fresh snapshot usable 1.05 <= reserve 1.10 -> 402 portal message (got $c)" '[ "$c" = 402 ] && /usr/bin/grep -q "portal credits" "$S/b"'
$PY - "$S/state.json" <<'EOF'
import json,sys
s=json.load(open(sys.argv[1])); s["portal"]["total_usable_credits"]=35.0; json.dump(s,open(sys.argv[1],"w"),indent=2)
EOF
c=$(post -d "$BODY_GLM")
check "A10 usable 34.9 -> 200 and remaining header reflects portal ($(/usr/bin/grep -i remaining "$S/h" | tr -d '\r'))" '[ "$c" = 200 ]'
rem=$(curl -s "$P/stats" | jget remaining.portal_above_reserve)
check "A10 /stats remaining.portal_above_reserve is a number ($rem)" '$PY -c "float(\"$rem\")"'
$PY - "$S/state.json" <<'EOF'
import json,sys
s=json.load(open(sys.argv[1])); s["portal"]["read_at"]="2020-01-01T00:00:00+00:00"; s["portal"]["total_usable_credits"]=0.0; json.dump(s,open(sys.argv[1],"w"),indent=2)
EOF
c=$(post -d "$BODY_GLM")
check "A10 stale snapshot (usable 0 but 6 years old) ignored -> local caps -> 200 (got $c)" '[ "$c" = 200 ]'
setpol "p['portal']['enabled']=False"

# --- A11 real probes (optional) ----------------------------------------------------------
if [ "$REAL" -gt 0 ]; then
  setpol "p['upstreams']['nous']['base_url']='https://inference-api.nousresearch.com/v1'; p['caps']['stall_s']=60; p['caps']['default_wall_s']=120"
  n=0
  while [ $n -lt "$REAL" ]; do
    n=$((n+1))
    if [ $((n % 2)) = 1 ]; then
      c=$(post -H "Authorization: Bearer pl-smoke" -d '{"model":"z-ai/glm-5.3-flash","messages":[{"role":"user","content":"Reply with the single word ok."}],"max_tokens":5}')
      kind=nonstream
    else
      c=$(curl -sN -o "$S/b" -D "$S/h" -w '%{http_code}' "$P/v1/chat/completions" -H "Authorization: Bearer pl-smoke" -H 'Content-Type: application/json' -d '{"model":"z-ai/glm-5.3-flash","stream":true,"messages":[{"role":"user","content":"Reply with the single word ok."}],"max_tokens":5}')
      kind=stream
    fi
    row=$(tail -1 "$S/ledger.jsonl")
    echo "REAL$n $kind http=$c ledger=$row"
    check "A11 REAL$n $kind 200" '[ "$c" = 200 ]'
    check "A11 REAL$n ledger: call row, cached_tokens present, bucket pl-smoke, priced (local_rates|upstream_floor)" 'echo "$row" | /usr/bin/grep -q "\"event\":\"call\"" && echo "$row" | /usr/bin/grep -q "\"cached_tokens\":" && echo "$row" | /usr/bin/grep -q "\"bucket\":\"pl-smoke\"" && echo "$row" | /usr/bin/grep -Eq "\"cost_source\":\"(local_rates|upstream_floor)\""'
    check "A11 REAL$n cost < 0.0005" 'echo "$row" | $PY -c "import sys,json; sys.exit(0 if json.load(sys.stdin)[\"cost_usd\"] < 0.0005 else 1)"'
    check "A11 REAL$n X-ModelLock-Remaining-USD + Bucket headers" '/usr/bin/grep -qi "^X-ModelLock-Remaining-USD:" "$S/h" && /usr/bin/grep -qi "^X-ModelLock-Bucket: pl-smoke" "$S/h"'
    [ "$kind" = stream ] && check "A11 REAL$n stream ends with [DONE]" 'tail -c 20 "$S/b" | /usr/bin/grep -q "\[DONE\]"'
  done
fi

# --- teardown -------------------------------------------------------------------------------
kill "$PROXY_PID" "$MOCK_PID" 2>/dev/null; sleep 0.3
if [ "$MOCK_MODE" = 1 ]; then
  echo "SKIP Z production ledger checks (MOCK_MODE)"
else
  PROD_ANCHORS_AFTER=$(/usr/bin/grep -c '"event":"anchor"' "$PROD/ledger.jsonl")
  check "Z production ledger gained no anchor rows from the scratch instance ($PROD_ANCHORS_BEFORE == $PROD_ANCHORS_AFTER)" '[ "$PROD_ANCHORS_BEFORE" = "$PROD_ANCHORS_AFTER" ]'
  PROD_SMOKE_AFTER=$(/usr/bin/grep -c '"bucket":"pl-smoke"' "$PROD/ledger.jsonl")
  check "Z production ledger gained no pl-smoke rows from the scratch instance ($PROD_SMOKE_BEFORE == $PROD_SMOKE_AFTER)" '[ "$PROD_SMOKE_BEFORE" = "$PROD_SMOKE_AFTER" ]'
fi
echo "PASSES=$PASSES FAILS=$FAILS"
exit $FAILS
