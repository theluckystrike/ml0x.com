#!/usr/bin/env python3
"""Add the 2026-09-17 tuning sections to a policy.json in place (idempotent)."""
import json
import sys

path = sys.argv[1]
p = json.load(open(path))
caps = p.setdefault("caps", {})
caps.setdefault("warn_at", [0.8, 0.95])
caps.setdefault("portal_reserve_usd", 1.10)
caps.setdefault("stall_s", 60)
caps.setdefault("default_wall_s", 300)
caps.setdefault("max_wall_s", {"z-ai/glm-5.3-flash": 300, "deepseek/deepseek-v4-flash-0731": 420})
caps.setdefault("_tuning_note",
    "2026-09-17 tuning: warn_at = soft thresholds (X-ModelLock-Warning header + warn.log, one line per cap/threshold/day). "
    "portal_reserve_usd = refuse when the portal's total_usable_credits minus spend since the last read is at or below this. "
    "stall_s = curl --speed-time (abort when no bytes for this long); max_wall_s per model, default_wall_s otherwise.")
p.setdefault("degrade", {
    "enabled": True,
    "order": ["deepseek/deepseek-v4-flash-0731", "z-ai/glm-5.3-flash"],
    "_comment": "When ONLY a per-model daily cap binds, rewrite to the first other allowed model with headroom and overwrite "
                "the reasoning field with that model's reasoning_overrides entry. Global, bucket and portal caps still 402."})
p.setdefault("buckets", {
    "_comment": "Key = the bearer value the pipeline sets as NOUS_API_KEY (Hermes forwards it verbatim; the proxy never uses it "
                "for auth, the upstream key is in upstream.env). Unknown or missing bearer -> default. daily_usd / total_usd per bucket.",
    "default": {},
    "pl-smoke": {"daily_usd": 0.50},
    "pl-example-site": {"daily_usd": 3.00}})
p.setdefault("portal", {
    "enabled": True, "every_calls": 50, "every_seconds": 300, "max_stale_s": 3600,
    "drift_warn_usd": 0.25, "auto_rebase": False,
    "_comment": "Token read from ~/.hermes/auth.json providers.nous.access_token; the proxy NEVER calls /api/oauth/token "
                "(single-use refresh tokens, auth.py:5700). Expired token or portal error => stale snapshot => local caps only. "
                "Drift between ledger delta and member_spend delta is logged, never rebased automatically."})
p.setdefault("context_length", {
    "_comment": "Served on GET /v1/models/<id> as max_model_len/context_length so Hermes stops sweeping for it. "
                "glm: 1048576 (top provider window, operator choice 2026-09-17).",
    "z-ai/glm-5.3-flash": 1048576})
p.setdefault("rates_refresh", {"every_s": 604800,
    "_comment": "python3 proxy.py --refresh-rates re-reads /v1/models pricing for allow[]; diff to rates_refresh.log; policy written only on change. Not scheduled."})
json.dump(p, open(path, "w"), indent=2)
print("patched", path)
