#!/usr/bin/env python3
"""Stdlib mock of the Nous inference API for the model-lock acceptance suite.

Zero spend. POST /v1/chat/completions writes the request it saw to
$MOCK_DIR/mock_last_request.json. Non-stream: canned completion with a
cached-token usage block. Stream: 3 deltas + usage + [DONE]. If the last user
message is "slow": 3 deltas then sleep 90 s without closing (stall test).
If it is "upstream400": HTTP 400 JSON error. GET /v1/models: two allowed
models with per-token pricing (policy rates / 1e6) and a context_length.
"""
import json
import os
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MOCK_DIR = os.environ.get("MOCK_DIR") or "."
PORT = int(os.environ.get("MOCK_PORT") or 8790)
RATES = {  # per Mtok, the 2026-09-17 catalog values
    "z-ai/glm-5.3-flash": {"in": 0.075, "out": 0.25, "cache_read": 0.01, "ctx": 1048576},
    "deepseek/deepseek-v4-flash-0731": {"in": 0.04, "out": 0.10, "cache_read": 0.01, "ctx": 163840},
}


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        sys.stderr.write("mock %s\n" % (fmt % args))

    def _json(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path.rstrip("/") == "/v1/models":
            data = []
            for mid, r in RATES.items():
                data.append({"id": mid, "object": "model", "context_length": r["ctx"],
                             "pricing": {"prompt": r["in"] / 1e6, "completion": r["out"] / 1e6,
                                         "input_cache_read": r["cache_read"] / 1e6}})
            self._json(200, {"object": "list", "data": data})
            return
        self._json(404, {"error": "no route"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n)
        try:
            req = json.loads(raw)
        except ValueError:
            self._json(400, {"error": "bad json"})
            return
        req["_auth_header"] = self.headers.get("Authorization", "")[:12] + "..."
        with open(os.path.join(MOCK_DIR, "mock_last_request.json"), "w") as fh:
            json.dump(req, fh, indent=2)
        msgs = req.get("messages") or []
        last = (msgs[-1].get("content") if msgs else "") or ""
        model = req.get("model", "?")
        if last == "upstream400":
            self._json(400, {"error": {"message": "Reasoning is mandatory", "type": "invalid_request_error"}})
            return
        usage = {"prompt_tokens": 100, "completion_tokens": 5, "total_tokens": 105,
                 "prompt_tokens_details": {"cached_tokens": 90}, "cost": 0.00005}
        if not req.get("stream"):
            self._json(200, {"id": "mock-1", "object": "chat.completion", "model": model,
                             "choices": [{"index": 0, "message": {"role": "assistant", "content": "ok from mock"},
                                          "finish_reason": "stop"}],
                             "usage": usage})
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Transfer-Encoding", "chunked")
        self.end_headers()

        def chunk(obj):
            d = ("data: " + json.dumps(obj) + "\n\n").encode()
            self.wfile.write(b"%x\r\n" % len(d) + d + b"\r\n")
            self.wfile.flush()

        for i, tok in enumerate(("Hel", "lo ", "mock")):
            chunk({"id": "mock-s", "object": "chat.completion.chunk", "model": model,
                   "choices": [{"index": 0, "delta": {"content": tok}, "finish_reason": None}]})
        if last == "slow":
            time.sleep(90)
            return
        chunk({"id": "mock-s", "object": "chat.completion.chunk", "model": model,
               "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}]})
        chunk({"id": "mock-s", "object": "chat.completion.chunk", "model": model, "choices": [], "usage": usage})
        d = b"data: [DONE]\n\n"
        self.wfile.write(b"%x\r\n" % len(d) + d + b"\r\n0\r\n\r\n")
        self.wfile.flush()


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    srv.daemon_threads = True
    sys.stderr.write("mock upstream on 127.0.0.1:%d dir=%s\n" % (PORT, MOCK_DIR))
    srv.serve_forever()
