# Changelog

## 2026-09-17

First public release. Everything in this repo except proxy v1.0 was built and measured on this date; v1.1 extended
the existing proxy.

- modellock proxy v1.1: cache-aware pricing (`cache_read` rate), rates refresh from the upstream catalog, warning
  thresholds, portal reserve, per-bucket caps, degrade-to-other-lane, per-model reasoning overrides, stall and wall
  timeouts, `context_length` on `/v1/models/<id>`, keep-alive body drain, ledger anchors, SIGHUP log reopen
- policy example, launchd plist, newsyslog rotation, acceptance test with a mock upstream
- recommended `config.yaml` keys (compaction at 48k instead of the 75 percent floor, max_turns 40, delegation caps,
  tool output cap, terminal timeout 120)
- `budget_gate.py` pre_tool_call hook and the delegation-contract skill plus its SOUL.md rule
- five source patches with a reapply guide
- measure / compare / after.sh acceptance harness, `apply_tuning.py`, `setkey.py`
- pipeline runner kit (`chat -q` per step, script gates, exit 75 for retry-later, launchd template)
- `docs/README.md` pointing at the public case study
