# Migrating long-running Hermes sessions onto pipelines

The kit was written to replace five open-ended `/goal` sessions with bounded, gated pipelines. The names below are
examples; substitute your own. `$RUNNER` is the directory you copied `runner/` to (or `HERMES_PIPELINES`).

| # | Pipeline | Profile | Why this position | Start command |
|---|---|---|---|---|
| 1 | example-site (a staged site build, phases 1-4) | pl-example-site | already a stage runner with a state file and a score gate; the most expensive context, so the biggest saving; no live `/goal` to interrupt | `bash $RUNNER/bin/runner.sh example-site` |
| 2 | example-site-2 (same phases, second slug) | pl-example-site-2 | same steps file with the slug swapped; wait for its current `/goal` session to finish first | `sed 's/example-site/example-site-2/g'` over `pipelines/example-site/{steps.txt,prompts/phase*.md,gates/p*.sh}` into `pipelines/example-site-2`, create `pl-example-site-2`, then `bash $RUNNER/bin/runner.sh example-site-2` |
| 3 | example-service (improve / iterate / KPIs) | pl-example-service | unbounded today; becomes one step with a written pass condition and a gate script that measures the KPI | write `pipelines/example-service/steps.txt` with one step, `bash $RUNNER/bin/runner.sh example-service` |
| 4 | example-spec (an orchestration or spec-writing task) | pl-example-spec | single step, pass condition = the spec file exists and passes its own checklist gate | `bash $RUNNER/bin/runner.sh example-spec` |
| 5 | example-fanout (a "10 parallel agents" job) | pl-example-fanout | fan-out heavy; only after the delegation caps (max_concurrent_children 2, max_iterations 30, child_timeout 900) are proven on 1-4 | `bash $RUNNER/bin/runner.sh example-fanout` |

Each new pipeline: `hermes profile create pl-<name> --clone --no-alias --description "..."`, the .env and config edits
from README.md step 1, `mkdir -p $RUNNER/pipelines/<name>/{prompts,gates,usage,logs}`, copy
`prompts/_preamble.md` and `prompts/_resume.md`, write `steps.txt`, one `<step>.md` and one `gates/<step>.sh` per step.
Never give two pipelines the same repo checkout; give `browser` to at most one at a time.

## Staged-build specifics (example-site)

If the work is already driven by a stage runner (a script that renders a phase file, has the agent follow it, and
records a score), keep that script as the source of truth: each step prompt tells the agent to render phase N, read
the rendered file, follow it, and record its score; the gate re-reads the runner's state under `timeout 20` and
requires the phase-N line to say it is cleared. Before the first real run, run `bash gates/p1.sh` once by hand to
confirm the grep matches the runner's actual line format, and adjust the pattern if it does not. If the working tree
lives on a synced folder, check nothing is evicted (`ls -lO` on macOS must not say `dataless`) before starting.

## Reading per-pipeline cost

```
# per attempt: the end event carries the ledger window summary
cat $RUNNER/pipelines/<name>/logs/<step>.jsonl
# per step attempt: usage/<step>.<n>.json  (estimated_cost_usd, api_calls, ledger_* tokens, session tokens)
# whole pipeline so far:
RUNNER=$RUNNER python3 - <<'PY'
import json,glob,os,sys
n=sys.argv[1] if len(sys.argv)>1 else "example-site"
tot=calls=0
for f in sorted(glob.glob(f"{os.environ['RUNNER']}/pipelines/{n}/usage/*.json")):
    u=json.load(open(f)); tot+=u.get("estimated_cost_usd") or 0; calls+=u.get("api_calls") or 0; print(f, u.get("estimated_cost_usd"), u.get("api_calls"))
print("TOTAL usd", round(tot,6), "calls", calls)
PY
# arbitrary window (exact when one pipeline runs; --bucket takes effect once the proxy tags rows):
python3 $RUNNER/bin/cost.py 2026-09-17T08:30:46+00:00 2026-09-17T08:31:33+00:00 --bucket pl-<name>
```

## Kanban lane commands for later (verified against the Hermes source; not run here)

```
# gateway hosts the dispatcher (kanban.dispatch_in_gateway: true); in ~/.hermes/config.yaml (operator edit, root profile):
#   kanban.failure_limit: 2, kanban.max_in_progress_per_profile: 1, kanban.auto_decompose: false
hermes gateway start
hermes kanban init
hermes kanban create "example-site phase 1" --assignee pl-example-site \
  --workspace dir:$HOME/example-site --max-runtime 3h --max-retries 2 \
  --model z-ai/glm-5.3-flash --provider custom:nous-api \
  --body "$(cat $RUNNER/pipelines/example-site/prompts/_preamble.md $RUNNER/pipelines/example-site/prompts/phase1.md)"
# repeat for phases 2-4 (phase 4 with --model deepseek/deepseek-v4-flash-0731), then chain:
hermes kanban link <p1-id> <p2-id>; hermes kanban link <p2-id> <p3-id>; hermes kanban link <p3-id> <p4-id>
hermes kanban dispatch --dry-run
# optional: --goal --goal-max-turns 40 on create makes the worker loop under the judge in one session
```
Workers are spawned as `hermes -p <assignee> chat -q "work kanban task <id>"` with HERMES_HOME set to the profile, so
the pl-* profiles, their .env buckets and config carry over unchanged. Exit 75 on rate_limit/billing releases the card
without a failure count; `--max-runtime` and the consecutive-failure breaker replace the runner's attempt counters.
