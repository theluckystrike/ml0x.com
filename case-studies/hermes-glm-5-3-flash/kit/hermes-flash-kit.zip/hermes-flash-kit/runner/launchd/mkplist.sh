#!/usr/bin/env bash
# mkplist.sh <pipeline>  renders the template to launchd/com.example.hermes-pipeline.<pipeline>.plist and prints the load command.
# It does NOT load anything. __HOME__ becomes $HOME and __ROOT__ the runner directory (HERMES_PIPELINES or the parent of launchd/). Semantics: StartInterval 900 fires every 15 min regardless of a running instance; the runner's
# mkdir .lock makes a second start a no-op; a finished pipeline exits 0 in under a second; exit 75 (cap/upstream/proxy down)
# means "try again at the next tick"; KeepAlive must stay false or a blocked pipeline restarts every 10 s and burns a 12k-token prompt each time.
set -eu; N=${1:?pipeline}; D=$(cd "$(dirname "$0")" && pwd); OUT=$D/com.example.hermes-pipeline.$N.plist
ROOT=${HERMES_PIPELINES:-$(cd "$D/.." && pwd)}   # same default as bin/runner.sh
sed -e "s/NAME/$N/g" -e "s|__ROOT__|$ROOT|g" -e "s|__HOME__|$HOME|g" "$D/com.example.hermes-pipeline.TEMPLATE.plist" > "$OUT"; plutil -lint "$OUT"
echo "load:    cp $OUT ~/Library/LaunchAgents/ && launchctl bootstrap gui/\$(id -u) ~/Library/LaunchAgents/com.example.hermes-pipeline.$N.plist"
echo "unload:  launchctl bootout gui/\$(id -u)/com.example.hermes-pipeline.$N"
echo "status:  launchctl print gui/\$(id -u)/com.example.hermes-pipeline.$N | grep -E 'state|last exit'"
