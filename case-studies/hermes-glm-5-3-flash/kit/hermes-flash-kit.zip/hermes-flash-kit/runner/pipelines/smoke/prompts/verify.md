Verify /tmp/hermes-smoke/hello.txt exists and its single line is exactly `hello from pl-smoke`. Run
`shasum -a 256 /tmp/hermes-smoke/hello.txt` and compare against `printf 'hello from pl-smoke\n' | shasum -a 256`.
Report both hashes in your answer. Pass condition: the two hashes match. Do not modify the file.
