#!/usr/bin/env bash
[ "$(cat /tmp/hermes-smoke/hello.txt 2>/dev/null)" = "hello from pl-smoke" ]
