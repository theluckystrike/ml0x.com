Continue the same task in this session. Re-read your last messages, check what already exists on disk, and finish
every unmet deliverable without restarting from scratch. End with `STEP DONE` or `BLOCKED: <reason>` as before.
