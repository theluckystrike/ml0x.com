#!/usr/bin/env bash
# the gate is a script, not the model's word
f=/tmp/hermes-smoke/hello.txt
[ -f "$f" ] || { echo "missing $f"; exit 1; }
want=$(printf 'hello from pl-smoke\n' | shasum -a 256 | cut -d' ' -f1); got=$(shasum -a 256 "$f" | cut -d' ' -f1)
echo "want $want"; echo "got  $got"; [ "$want" = "$got" ]
