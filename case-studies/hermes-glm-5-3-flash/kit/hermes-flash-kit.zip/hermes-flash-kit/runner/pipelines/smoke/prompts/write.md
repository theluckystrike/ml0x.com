Create the directory /tmp/hermes-smoke if missing and write /tmp/hermes-smoke/hello.txt containing exactly one line:
hello from pl-smoke
(no leading or trailing spaces, a single trailing newline). Then print the file with cat. Pass condition: the cat
output is exactly that line.
