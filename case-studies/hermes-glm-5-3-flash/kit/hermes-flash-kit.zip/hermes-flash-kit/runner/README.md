# runner: hermes pipelines

One Hermes profile per pipeline, one `hermes -p pl-<name> chat -q` per step, a script gate per step, cost from the
model-lock ledger. Copy this `runner/` directory somewhere durable (the examples below use `~/hermes-pipelines`; never
`~/Desktop` on a Mac with iCloud Desktop sync, files get evicted) or point `HERMES_PIPELINES` at it; `bin/runner.sh`
defaults to its own parent directory. `HERMES_BIN` overrides the Hermes binary (default `~/.local/bin/hermes`). The
runner plan is summarised in the case study linked from `../docs/README.md`; smoke-tested 2026-09-17 (2 steps, 47 s,
5 calls, $0.001211).

## Layout

```
bin/runner.sh               supervisor: fresh step = chat -q, retry = chat -q --resume <session>; exit 0 done, 1 blocked, 75 retry later
bin/cost.py                 ledger window summary; honours a per-row "bucket" field when the proxy starts writing one
bin/classify.py             DONE|CAP|UPSTREAM|OVERBUDGET|PARTIAL|FAIL from rc + usage.json + ledger + `STEP DONE` sentinel
bin/synth_usage.py          builds usage/<step>.<n>.json (chat -q never writes --usage-file; that flag is oneshot-only)
bin/st.py                   state.json get/set
prompts/_preamble.md        master copy; each pipeline has its own copy under pipelines/<name>/prompts/
prompts/_resume.md          continuation prompt for --resume
pipelines/<name>/steps.txt  name|model|toolsets|max_usd|prompt_file|max_turns   (# lines ignored)
pipelines/<name>/prompts/   _preamble.md, _resume.md, <step>.md
pipelines/<name>/gates/<step>.sh   exit 0 = pass; runs only after the model printed STEP DONE; this is the real pass condition
pipelines/<name>/state.json        {"done":{},"sessions":{},"attempts":{},"blocked":{}}
pipelines/<name>/usage/<step>.<n>.json, logs/<step>.out|.err|.jsonl|.gate, logs/pipeline.log
launchd/com.example.hermes-pipeline.TEMPLATE.plist + mkplist.sh   (renders __HOME__ and __ROOT__; nothing is loaded by this kit)
```

## Why `chat -q` and not `-z`

`-z` ignores `--skills` (main.py forwards only oneshot/model/provider/toolsets/usage_file), has a fixed 90-iteration cap
(agent_init.py:470) and exits 0 on a partial run with text (oneshot.py:283-294). `chat -q` honours `--max-turns`, `-s`,
`--resume`, prints `session_id:` to stderr and exits 1 on `failed`. The one thing it lacks is `--usage-file`
(`hermes --help`: "One-shot mode only"), so `bin/synth_usage.py` writes the same JSON shape from the profile's
`state.db` sessions row (input/output/cache_read tokens, message and tool counts) plus the ledger window
(`api_calls`, `estimated_cost_usd`, `ledger_*` tokens). `--usage-file` is still passed at top level so a future
Hermes that writes it on this path is used automatically (the runner only synthesizes when the file is empty).
Token counts on a resumed session are cumulative for the session; `ledger_*` fields are the attempt's window.
`completed` stays false because `chat -q` does not stamp `ended_at`; the runner keys on rc + sentinel + gate instead.

## Exact commands

```
# 1. profile (once per pipeline)
hermes profile create pl-<name> --clone --no-alias --description "pipeline lane: <what>"
#    then in ~/.hermes/profiles/pl-<name>/.env:  NOUS_API_KEY=pl-<name>   HERMES_VERIFY_ON_STOP=0   (replace, do not append a second NOUS_API_KEY)
#    and config.yaml via the comment-preserving helper:
PY=~/.hermes/hermes-agent/venv/bin/python; SK=/path/to/hermes-flash-kit/measure/setkey.py; C=~/.hermes/profiles/pl-<name>/config.yaml
$PY $SK $C agent.verify_on_stop false; $PY $SK $C agent.max_turns 40; $PY $SK $C delegation.max_iterations 30
$PY $SK $C delegation.max_concurrent_children 2; $PY $SK $C delegation.child_timeout_seconds 900
$PY $SK $C compression.threshold_tokens 48000; $PY $SK $C compression.proactive_prune_tokens 24000
$PY $SK $C tool_output.max_bytes 20000; $PY $SK $C terminal.timeout 120; $PY $SK $C skills.creation_nudge_interval 0
$PY $SK $C memory.nudge_interval 30
$PY $SK $C platform_toolsets.cli '["browser","clarify","code_execution","delegation","file","memory","skills","terminal","todo","web"]'
test -f ~/.hermes/profiles/pl-<name>/skills/software-development/delegation-contract/SKILL.md || cp -R ~/.hermes/skills/software-development/delegation-contract ~/.hermes/profiles/pl-<name>/skills/software-development/

# 2. run a pipeline by hand (idempotent: done steps are skipped, a blocked step stops it)
bash ~/hermes-pipelines/bin/runner.sh <name>; echo rc=$?

# 3. read results
cat ~/hermes-pipelines/pipelines/<name>/state.json
cat ~/hermes-pipelines/pipelines/<name>/usage/*.json
cat ~/hermes-pipelines/pipelines/<name>/logs/*.jsonl          # start/end events with the ledger window per attempt
python3 ~/hermes-pipelines/bin/cost.py <since> <until> --bucket pl-<name>   # ts format 2026-09-17T08:30:46+00:00

# 4. schedule (optional)
bash ~/hermes-pipelines/launchd/mkplist.sh <name>            # renders the plist and prints the bootstrap/bootout commands; loads nothing

# 5. reset a step / unblock
python3 ~/hermes-pipelines/bin/st.py set blocked.<step> ""   # then re-run; or delete state.json to start the pipeline over
rmdir ~/hermes-pipelines/pipelines/<name>/.lock              # only if a run died without cleaning up
```

What the runner does per attempt: probe `127.0.0.1:8788/v1/models` (6 tries, 10 s apart; all refused = exit 75),
run the step, capture `session_id`, synthesize usage.json, sum the ledger window, classify, run the gate, log an
`end` event. CAP (402 or "Billing or credits exhausted") exits 75 with the session kept for resume; UPSTREAM backs off
30..600 s with jitter for 6 attempts then exits 75; OVERBUDGET (window cost > max_usd) blocks; PARTIAL/FAIL/GATEFAIL
resume the same session up to 3 attempts then block. Logs over 10 MB are truncated to their last 1 MB.

Cost attribution: rows in `~/.hermes/modellock/ledger.jsonl` carry no pipeline tag today (the proxy never reads the
inbound bearer), so a window is exact for one running pipeline and an upper bound for N. `NOUS_API_KEY=pl-<name>` is
already set per profile; when the proxy patch lands and rows carry `"bucket"`, `cost.py --bucket pl-<name>` filters on
it automatically (`attribution` in its output says `window`, `mixed` or `bucket`).

Rules: one pipeline per repo checkout; at most one pipeline with the `browser` toolset at a time (one Chrome profile
cannot be driven by two agents); never point `KeepAlive true` at a runner; no emojis in prompts or output.
