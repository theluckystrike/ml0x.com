# docs

The audits and plans this kit was built from are not shipped in this repository. They are summarised, with the
measured numbers and the two HTML reports, in the public case study:

https://ml0x.com/case-studies/hermes-glm-5-3-flash/

Line numbers cited elsewhere in the kit refer to Hermes Agent at git HEAD f5be9236 and to the proxy as it was
before v1.1.
