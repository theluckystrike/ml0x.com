---
name: delegation-contract
description: Use before every delegate_task call to size and brief it.
---
# Delegation contract

Before calling delegate_task:
1. One deliverable per task. Name the absolute output path in `goal`. Reject any goal over 1,500 chars; split it.
2. Paste this block verbatim at the top of `context`, filling BUDGET from delegation.max_iterations (currently 30):

   DELIVERABLE CONTRACT: you have BUDGET tool-call iterations, no extension. Iteration 1: create
   <output path> with final headings and 'STATUS: in progress'; append evidence as you go. By
   iteration BUDGET-10 the file must be shippable; after that only refine. Every 10 iterations
   reply one line 'budget: N of BUDGET used, next: <action>'. Never run sleep or poll in a loop;
   use terminal(background=True, notify_on_complete=True) once. Read each file once. Same command,
   same failure, twice: stop and report. If a prior attempt's log exists at <path>, read its failure
   section first.

3. After dispatch, do not sleep or poll. Finish your current step, then end the turn with one status line; the result arrives as the next message.
4. On `exit_reason: billing_blocked` do not re-dispatch; report the cap. On `max_iterations`, read the child's partial file before deciding to re-delegate, and pass its path as the prior attempt.
5. Verify child claims yourself (stat the file, fetch the URL) before reporting success.
