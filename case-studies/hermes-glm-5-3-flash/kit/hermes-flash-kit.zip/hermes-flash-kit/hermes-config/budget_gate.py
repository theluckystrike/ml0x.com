#!/usr/bin/env python3
"""pre_tool_call hook for delegate_task: refuse to spawn a subagent when the model-lock budget is nearly gone.
Reads the proxy /healthz first, falls back to state.json + policy.json. stdlib only, loopback only."""
import json, os, sys, datetime, urllib.request
HERMES_HOME = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
PROXY_HEALTHZ = os.environ.get("MODELLOCK_HEALTHZ", "http://127.0.0.1:8788/healthz")
MIN_REMAINING_USD = 1.00
try:
    payload = json.load(sys.stdin)
except Exception:
    sys.exit(0)
if payload.get("tool_name") != "delegate_task":
    sys.exit(0)
def from_proxy():
    with urllib.request.urlopen(PROXY_HEALTHZ, timeout=2) as r:
        j = json.load(r)
    return float(j.get("spent_today_usd", 0.0)), j.get("caps") or {}, float(j.get("total_usd", 0.0) or 0.0)
def from_files():
    st = json.load(open(os.path.join(HERMES_HOME, "modellock", "state.json")))
    pol = json.load(open(os.path.join(HERMES_HOME, "modellock", "policy.json")))
    today = datetime.datetime.now(datetime.timezone.utc).date().isoformat()
    return float(st.get("days", {}).get(today, 0.0)), pol.get("caps") or {}, float(st.get("total_usd", 0.0))
try:
    spent, caps, total = from_proxy()
    if not caps:
        _, caps, _ = from_files()
except Exception:
    spent, caps, total = from_files()
checks = []
if caps.get("daily_usd"):
    checks.append(("daily", float(caps["daily_usd"]) - spent, spent, float(caps["daily_usd"])))
if caps.get("total_usd") and total:
    checks.append(("lifetime", float(caps["total_usd"]) - total, total, float(caps["total_usd"])))
for name, remaining, used, cap in checks:
    if remaining < MIN_REMAINING_USD:
        print(json.dumps({"action": "block", "message":
            f"delegate_task refused: model-lock {name} budget has ${remaining:.2f} left "
            f"(spent ${used:.2f} of ${cap:.2f}). Do not spawn; finish with what you have and write your deliverable file now."}))
        break
