# hermes-config: the four pieces that go into ~/.hermes

Each file here has one destination. Paths assume the default `HERMES_HOME=~/.hermes`; a profile lives at
`~/.hermes/profiles/<name>/` and takes the same files.

## config.recommended.yaml -> merge into ~/.hermes/config.yaml

Not a drop-in replacement: it lists only the keys to change, with the measured reason for each on the same line.
Apply by hand, or with the comment-preserving helpers in `../measure/`:
`python3 ../measure/apply_tuning.py ~/.hermes/config.yaml` applies every key at once (make a backup first), and
`python3 ../measure/setkey.py ~/.hermes/config.yaml compression.threshold_tokens 48000` sets one dotted key.
Both need `ruamel.yaml`, which the Hermes venv already has (`~/.hermes/hermes-agent/venv/bin/python`).
Every key is hot-read except `platform_toolsets` and `personalities`, which take effect on the next session start.

## budget_gate.py -> ~/.hermes/hooks/budget_gate.py (chmod +x)

A `pre_tool_call` hook for `delegate_task`. It asks the proxy's `/healthz` (falling back to `state.json` and
`policy.json` under `HERMES_HOME`) how much of the daily and lifetime caps is left and blocks the spawn when less than
`MIN_REMAINING_USD` (1.00) remains, telling the parent to finish with what it has and write its deliverable. Register it
in `config.yaml` under the hooks section as a `pre_tool_call` hook for the `delegate_task` tool, as your Hermes
version's docs describe. Without the proxy it still works from the files.

## delegation-contract.SKILL.md -> ~/.hermes/skills/software-development/delegation-contract/SKILL.md

A skill the parent loads before every `delegate_task`. It sizes the goal (one deliverable, under 1,500 chars), pastes
a DELIVERABLE CONTRACT block into the child context (create the output file on iteration 1, shippable by BUDGET-10,
status line every 10 iterations, no sleep-polling, same failure twice = stop), and tells the parent what to do on
`billing_blocked` and `max_iterations`. Fill BUDGET from `delegation.max_iterations` (30 in the recommended config).

## SOUL.md.rule -> one line appended to ~/.hermes/SOUL.md

The single rule that makes the skill load: before any `delegate_task`, load `delegation-contract` and paste its block;
never sleep-poll for a delegation result. The skill is instruction-level; the hook is the enforcement.
