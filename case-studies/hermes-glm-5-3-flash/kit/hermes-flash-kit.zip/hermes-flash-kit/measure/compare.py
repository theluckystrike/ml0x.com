#!/usr/bin/env python3
"""compare.py - side-by-side before/after readout for the Hermes tuning rollout. Stdlib only, no network.

Usage:
  python3 compare.py before.json after.json [--json-out after_<ts>.json]

Both inputs are `measure.py --json` dumps. The after dump should have been produced with
`--sessions-started-after <apply time>` so that sessions-db and agent.log metrics cover only sessions
that run the new config. Ledger and proxy metrics are time-window only (rows carry no session id).

Thresholds are the acceptance criteria from plan_acceptance.md section 2, as fixed for this rollout:
  C1 p90 prompt < 60k            C2 compaction 2-20 per 1,000 calls   C3 cache share >= 90 percent
  C4 exit-124 < 3 per CLI session-hour                                D1 max_iterations share < 15 percent over >= 20 tasks
  D2 zero 402 deaths labelled max_iterations                          D3 delivery lag p50 < 3 min
  S1 skill_manage errors = 0     T1 first-call prompt < 12k
  P1 zero bad-syntax 400s        P2 sweep 404s < 5 per hour            P3 zero 402 while credits > reserve
A criterion with no data in the after window is n/a and is excluded from the weighted score; the
score then reports how much of the total weight it covers.
"""
import argparse
import datetime as dt
import json
import sys

# (id, label, weight, threshold text)
CRITERIA = [
    ("C1", "p90 prompt tokens", 15, "< 60,000"),
    ("C2", "compactions per 1,000 calls", 8, "2 to 20"),
    ("C3", "cache hit share", 12, ">= 90 percent"),
    ("C4", "exit-124 per CLI session-hour", 8, "< 3.0"),
    ("D1", "max_iterations share (>= 20 tasks)", 12, "< 15 percent"),
    ("D2", "402 deaths labelled max_iterations", 6, "= 0"),
    ("D3", "delivery lag p50, min", 6, "< 3.0"),
    ("S1", "skill_manage errors", 6, "= 0"),
    ("T1", "first-call prompt tokens p50", 10, "< 12,000"),
    ("P1", "bad-syntax 400s in window, count (proxy.log)", 5, "= 0"),
    ("P2", "sweep 404s per hour, window mean (proxy.log)", 4, "< 5"),
    ("P3", "402 denies while credits > reserve", 8, "= 0"),
]
assert sum(c[2] for c in CRITERIA) == 100


def g(M, k, d=None):
    v = M.get(k)
    return d if v is None else v


def div(a, b):
    return (a / b) if b else None


def evaluate(M):
    """Returns {id: (value, verdict)} where verdict is PASS / FAIL / n/a and value may be None."""
    calls = g(M, "calls", 0)
    hours = g(M, "window_hours", 0) or 0
    csh = g(M, "cli_session_hours", 0) or 0
    tasks = g(M, "delegation_tasks", 0)
    log_lines = g(M, "al_lines", 0)
    proxy_lines = g(M, "proxy_lines", 0)
    R = {}

    def put(i, val, ok, enough=True):
        if val is None or not enough:
            R[i] = (val, "n/a")
        else:
            R[i] = (val, "PASS" if ok else "FAIL")

    v = g(M, "prompt_p90")
    put("C1", v if calls else None, (v or 0) < 60000)
    v = div(g(M, "al_compression_started", 0) * 1000.0, calls)
    put("C2", v, v is not None and 2 <= v <= 20, enough=calls >= 50)
    v = g(M, "cache_hit_share")
    put("C3", v, (v or 0) >= 0.90)
    v = div(g(M, "exit_124", 0), csh)
    put("C4", v, (v or 0) < 3.0)
    v = g(M, "delegation_max_iterations_share")
    put("D1", v, (v or 0) < 0.15, enough=tasks >= 20)
    v = g(M, "delegation_402_deaths", 0) if tasks else None
    put("D2", v, v == 0)
    v = g(M, "delivery_lag_p50_min") if g(M, "delegations", 0) else None
    put("D3", v, (v or 0) < 3.0)
    v = g(M, "al_skill_manage_errors", 0) if log_lines else None
    put("S1", v, v == 0)
    v = g(M, "al_first_call_in_p50") if g(M, "al_first_call_in_n", 0) else None
    put("T1", v, (v or 0) < 12000)
    # P-series needs real traffic: sweep probes hit the proxy even when no session is running
    traffic = bool(proxy_lines) and calls > 0
    v = g(M, "proxy_400_bad_syntax", 0) if traffic else None
    put("P1", v, v == 0)
    v = div(g(M, "proxy_404_sweep", 0), hours) if traffic else None
    put("P2", v, (v or 0) < 5)
    if traffic:
        d402 = g(M, "deny_402", 0)
        usable = g(M, "usable_credits_now_est", 0) or 0
        reserve = g(M, "reserve", 1.10) or 0
        put("P3", d402, d402 == 0 or usable <= reserve)
    else:
        put("P3", None, False)
    return R


FMT = {
    "C1": lambda v: "{:,}".format(int(v)), "C2": lambda v: "%.1f" % v, "C3": lambda v: "%.1f%%" % (100 * v),
    "C4": lambda v: "%.2f" % v, "D1": lambda v: "%.1f%%" % (100 * v), "D2": lambda v: "%d" % v,
    "D3": lambda v: "%.1f" % v, "S1": lambda v: "%d" % v, "T1": lambda v: "{:,}".format(int(v)),
    "P1": lambda v: "%d" % v, "P2": lambda v: "%.1f" % v, "P3": lambda v: "%d" % v,
}


def fmt(i, v):
    if v is None:
        return "-"
    try:
        return FMT[i](v)
    except (TypeError, ValueError):
        return str(v)


def delta(i, b, a):
    if b is None or a is None:
        return "-"
    d = a - b
    if i in ("C3", "D1"):
        return "%+.1f pt" % (100 * d)
    if i in ("C1", "T1", "D2", "S1", "P1", "P3"):
        return "%+d" % d
    return "%+.2f" % d


def money_rows(B, A):
    rows = []
    for label, key in (("real cost per call, USD", "real_cost_per_call"),
                       ("real cost per wall-clock hour, USD", "real_cost_per_wallclock_h")):
        rows.append((label, g(B, key), g(A, key)))
    rows.append(("real cost per CLI session-hour, USD",
                 div(g(B, "real_cost_total", 0), g(B, "cli_session_hours", 0)),
                 div(g(A, "real_cost_total", 0), g(A, "cli_session_hours", 0))))
    rows.append(("cache re-read share of real cost", g(B, "real_cost_cache_share"), g(A, "real_cost_cache_share")))
    return rows


def score(R):
    got = evaluable = 0
    for i, _, w, _ in CRITERIA:
        val, ver = R[i]
        if ver == "n/a":
            continue
        evaluable += w
        if ver == "PASS":
            got += w
    return (100.0 * got / evaluable if evaluable else 0.0), evaluable


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("before")
    ap.add_argument("after")
    ap.add_argument("--json-out", default=None, help="write the combined readout (rows, score, verdict, both inputs) here")
    ap.add_argument("--hours-per-day", type=float, default=8.0, help="running hours per day for the monthly projection")
    args = ap.parse_args()
    with open(args.before) as fh:
        B = json.load(fh)
    with open(args.after) as fh:
        A = json.load(fh)
    RB, RA = evaluate(B), evaluate(A)
    sc, cov = score(RA)
    sc_b, cov_b = score(RB)

    P = print
    P("Hermes before/after  (compare.py)")
    P("before: %s -> %s  (%.2f h, %d ledger calls, %d CLI + %d subagent sessions)" % (
        B.get("since"), B.get("until"), g(B, "window_hours", 0), g(B, "calls", 0), g(B, "cli_sessions", 0), g(B, "subagent_sessions", 0)))
    P("after : %s -> %s  (%.2f h, %d ledger calls, %d CLI + %d subagent sessions)" % (
        A.get("since"), A.get("until"), g(A, "window_hours", 0), g(A, "calls", 0), g(A, "cli_sessions", 0), g(A, "subagent_sessions", 0)))
    if A.get("session_filter_active"):
        P("after window session filter: %d post-apply sessions (%d fresh roots + %d subagents), %d post-apply subagents of pre-apply parents excluded, "
          "%d pre-apply sessions still active on the OLD config" % (
              g(A, "session_filter_n", 0), g(A, "session_filter_roots", 0), g(A, "session_filter_descendants_added", 0),
              g(A, "post_apply_children_of_pre_apply_parents_excluded", 0), g(A, "pre_apply_sessions_active_after", 0)))
    else:
        P("after window session filter: NOT active (run measure.py with --sessions-started-after)")
    P("")
    hdr = "%-4s %-36s %-12s %-12s %-11s %-6s %-6s %s" % ("id", "metric", "before", "after", "delta", "w", "verdict", "threshold")
    P(hdr)
    P("-" * len(hdr))
    rows = []
    for i, label, w, thr in CRITERIA:
        vb, verb = RB[i]
        va, vera = RA[i]
        P("%-4s %-36s %-12s %-12s %-11s %-6d %-6s %s" % (i, label, fmt(i, vb), fmt(i, va), delta(i, vb, va), w, vera, thr))
        rows.append({"id": i, "metric": label, "before": vb, "after": va, "before_verdict": verb, "verdict": vera, "weight": w, "threshold": thr})
    P("")
    P("weighted score: after %.0f/100 over %d%% of the weight evaluable (before window scored %.0f over %d%%)" % (sc, cov, sc_b, cov_b))
    P("")
    P("COST (real, catalog rates)")
    P("%-40s %-14s %-14s %s" % ("line", "before", "after", "delta"))
    cost_rows = []
    for label, vb, va in money_rows(B, A):
        share = "share" in label
        f = (lambda x: "-" if x is None else ("%.1f%%" % (100 * x) if share else "$%.4f" % x))
        d = "-" if (vb is None or va is None) else (("%+.1f pt" % (100 * (va - vb))) if share else ("%+.1f%%" % (100 * (va - vb) / vb) if vb else "-"))
        P("%-40s %-14s %-14s %s" % (label, f(vb), f(va), d))
        cost_rows.append({"line": label, "before": vb, "after": va})
    hpd = args.hours_per_day
    proj = {}
    for tag, M in (("before", B), ("after", A)):
        rate = g(M, "real_cost_per_wallclock_h", 0) or 0
        proj[tag] = {"per_wallclock_h": rate, "monthly_at_%gh" % hpd: rate * hpd * 30, "monthly_at_24h": rate * 24 * 30}
        if rate > 0:
            P("projected monthly credits, %s pace: $%.2f at %g h/day, $%.2f at 24 h/day (rate $%.4f per wall-clock hour)" % (
                tag, rate * hpd * 30, hpd, rate * 24 * 30, rate))
        else:
            P("projected monthly credits, %s pace: no ledger calls in window, no projection" % tag)
    usable = g(A, "usable_credits_now_est", g(B, "usable_credits_now_est"))
    if usable is not None:
        P("credits usable now (est.): %.2f; reserve %.2f" % (usable, g(A, "reserve", g(B, "reserve", 1.10)) or 0))
    P("")
    # verdict
    n_pass = sum(1 for r in rows if r["verdict"] == "PASS")
    n_fail = sum(1 for r in rows if r["verdict"] == "FAIL")
    n_na = sum(1 for r in rows if r["verdict"] == "n/a")
    fails = [r["id"] for r in rows if r["verdict"] == "FAIL"]
    sess = g(A, "session_filter_n", 0) if A.get("session_filter_active") else (g(A, "cli_sessions", 0) + g(A, "subagent_sessions", 0))
    calls_a = g(A, "calls", 0)
    if sess == 0 and calls_a == 0:
        verdict = ("NO DATA YET: the after window has 0 post-apply sessions and 0 ledger calls. Nothing here measures the new config. "
                   "Sessions started before the apply keep the old config until they are restarted; start fresh Hermes sessions, "
                   "let them work for at least 2 hours (or 500 calls), then run after.sh again.")
    elif cov < 50:
        verdict = ("INSUFFICIENT DATA: %d post-apply sessions and %d ledger calls; only %d%% of the acceptance weight is evaluable "
                   "(%d PASS, %d FAIL, %d n/a). Score %.0f/100 is provisional. Failing so far: %s. Keep the sessions running and re-run." % (
                       sess, calls_a, cov, n_pass, n_fail, n_na, sc, ", ".join(fails) or "none"))
    else:
        b_sh = div(g(B, "real_cost_total", 0), g(B, "cli_session_hours", 0))
        a_sh = div(g(A, "real_cost_total", 0), g(A, "cli_session_hours", 0))
        cost_txt = ""
        if b_sh and a_sh:
            cost_txt = " Real cost per CLI session-hour moved from $%.4f to $%.4f (%+.0f%%)." % (b_sh, a_sh, 100 * (a_sh - b_sh) / b_sh)
        grade = "PASS" if sc >= 80 and n_fail == 0 else ("PARTIAL" if sc >= 50 else "FAIL")
        verdict = ("%s: score %.0f/100 over %d%% of the weight (%d PASS, %d FAIL, %d n/a) from %d post-apply sessions and %d ledger calls.%s "
                   "Failing: %s.%s" % (
                       grade, sc, cov, n_pass, n_fail, n_na, sess, calls_a, cost_txt, ", ".join(fails) or "none",
                       " Pre-apply sessions still active on the old config: %d; the ledger rows mix both until they restart." % g(A, "pre_apply_sessions_active_after", 0)
                       if g(A, "pre_apply_sessions_active_after", 0) else ""))
    P("VERDICT: " + verdict)
    if args.json_out:
        out = {"generated_at": dt.datetime.now(dt.timezone.utc).isoformat(), "score": sc, "weight_evaluable_pct": cov,
               "before_score": sc_b, "before_weight_evaluable_pct": cov_b, "rows": rows, "cost": cost_rows, "projection": proj,
               "verdict": verdict, "post_apply_sessions": sess, "after_calls": calls_a, "before": B, "after": A}
        with open(args.json_out, "w") as fh:
            json.dump(out, fh, indent=1, default=str)
    return 0


if __name__ == "__main__":
    sys.exit(main())
