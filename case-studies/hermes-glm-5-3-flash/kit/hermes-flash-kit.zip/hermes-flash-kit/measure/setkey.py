#!/usr/bin/env python3
"""setkey.py <config.yaml> <dotted.key> <json-value> | --delete
Comment-preserving single-key edit (ruamel round-trip). Example:
  setkey.py ~/.hermes/config.yaml compression.threshold_tokens 48000
  setkey.py ~/.hermes/config.yaml compression.summary_model --delete
  setkey.py ~/.hermes/config.yaml platform_toolsets.cli '["browser","file"]'"""
import json, sys
from ruamel.yaml import YAML
path, dotted, raw = sys.argv[1], sys.argv[2], sys.argv[3]
yaml = YAML(); yaml.preserve_quotes = True; yaml.width = 4096
yaml.indent(mapping=2, sequence=4, offset=2)
with open(path, encoding="utf-8") as f: cfg = yaml.load(f)
keys = dotted.split("."); node = cfg
for k in keys[:-1]:
    if k not in node or node[k] is None: node[k] = {}
    node = node[k]
if raw == "--delete":
    print("deleted" if node.pop(keys[-1], None) is not None else "absent", dotted)
else:
    node[keys[-1]] = json.loads(raw); print("set", dotted, "=", raw)
with open(path, "w", encoding="utf-8") as f: yaml.dump(cfg, f)
