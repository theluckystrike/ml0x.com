#!/usr/bin/env python3
"""Comment-preserving edit of a Hermes config.yaml (ruamel round-trip).
Usage: apply_tuning.py <config.yaml>  -- edits in place; caller makes the backup."""
import sys
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedSeq

path = sys.argv[1]
yaml = YAML()
yaml.preserve_quotes = True
yaml.width = 4096
yaml.indent(mapping=2, sequence=4, offset=2)
with open(path, encoding="utf-8") as f:
    cfg = yaml.load(f)

def setk(section, key, value):
    cfg.setdefault(section, {})
    cfg[section][key] = value

setk("agent", "max_turns", 40)
cfg["agent"].pop("personalities", None)
setk("compression", "threshold_tokens", 48000)
setk("compression", "proactive_prune_tokens", 24000)
setk("compression", "proactive_prune_min_result_chars", 4000)
setk("compression", "protect_last_n", 10)
cfg["compression"].pop("summary_model", None)
setk("terminal", "timeout", 120)
setk("tool_output", "max_bytes", 20000)
setk("tool_loop_guardrails", "hard_stop_enabled", True)
setk("delegation", "max_iterations", 30)
setk("delegation", "max_concurrent_children", 2)
setk("delegation", "child_timeout_seconds", 900)
setk("memory", "nudge_interval", 30)
setk("skills", "creation_nudge_interval", 40)
setk("updates", "pre_update_backup", True)
cfg["platform_toolsets"]["cli"] = CommentedSeq(
    ["browser", "clarify", "code_execution", "delegation", "file",
     "memory", "skills", "terminal", "todo", "web"])

with open(path, "w", encoding="utf-8") as f:
    yaml.dump(cfg, f)
print("ok", path)
