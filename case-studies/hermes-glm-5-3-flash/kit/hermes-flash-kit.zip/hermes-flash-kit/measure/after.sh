#!/bin/bash
# after.sh - one-command before/after readout for the Hermes tuning rollout.
# Run after new Hermes sessions (started AFTER the apply time) have worked for at least 2 hours:
#   bash measure/after.sh          (HERMES_HOME is honoured by measure.py; default ~/.hermes)
# Reads apply_time_wave1.txt, measures the before window (00:00 UTC of the apply day -> apply time) and the
# after window (apply time -> now, sessions started after the apply only), compares them, and writes
#   measure/after_<ts>.txt   the readout you see on screen (next to this script)
#   measure/after_<ts>.json  the same plus both raw measure.py dumps
#   measure/RESULTS.md       one dated row appended per run
# Read-only against ~/.hermes (state.db opened mode=ro). No network. Safe on an empty after window.
set -u
PLAN="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PLAN" || exit 1
if [ ! -s apply_time_wave1.txt ]; then
  # apply_time_wave1.txt holds the UTC ISO time you applied the config, e.g. 2026-09-17T08:20:44Z
  echo "apply_time_wave1.txt missing or empty in $PLAN" >&2
  exit 2
fi
APPLY="$(tr -d '[:space:]' < apply_time_wave1.txt)"
DAY="${APPLY:0:10}"
NOW="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
TS="$(date -u +%Y%m%dT%H%M%SZ)"
BEFORE_JSON="$PLAN/.before_$TS.json"
AFTER_JSON="$PLAN/.after_measure_$TS.json"
OUT_TXT="$PLAN/after_$TS.txt"
OUT_JSON="$PLAN/after_$TS.json"

echo "apply time : $APPLY"
echo "before     : ${DAY}T00:00:00Z -> $APPLY (all sessions)"
echo "after      : $APPLY -> $NOW (sessions started after $APPLY only, plus their subagents)"
python3 measure.py --since "${DAY}T00:00:00Z" --until "$APPLY" --json > "$BEFORE_JSON" || { echo "measure.py (before) failed" >&2; exit 3; }
python3 measure.py --since "$APPLY" --until "$NOW" --sessions-started-after "$APPLY" --json > "$AFTER_JSON" || { echo "measure.py (after) failed" >&2; exit 3; }

read -r N_SESS N_ROOTS N_CALLS N_OLD < <(python3 - "$AFTER_JSON" <<'PY'
import json, sys
a = json.load(open(sys.argv[1]))
print(a.get("session_filter_n", 0), a.get("session_filter_roots", 0), a.get("calls", 0), a.get("pre_apply_sessions_active_after", 0))
PY
)
HOURS_AFTER="$(python3 -c "import json,sys; print('%.2f' % json.load(open(sys.argv[1])).get('window_hours', 0))" "$AFTER_JSON")"
{
  echo "after.sh run $NOW  (apply $APPLY, after window $HOURS_AFTER h)"
  echo "post-apply sessions found: $N_SESS ($N_ROOTS fresh-process roots); ledger calls in after window: $N_CALLS; pre-apply sessions still active on the OLD config: $N_OLD"
  if [ "$N_SESS" = "0" ]; then
    echo "NOTE: no session has started since the apply. Restart Hermes sessions (a running session keeps the old config) and re-run after 2 hours."
  fi
  echo
  python3 compare.py "$BEFORE_JSON" "$AFTER_JSON" --json-out "$OUT_JSON"
} | tee "$OUT_TXT"
RC=${PIPESTATUS[0]}
rm -f "$BEFORE_JSON" "$AFTER_JSON"

SCORE="$(python3 -c "import json,sys; d=json.load(open(sys.argv[1])); print('%.0f/%d%%' % (d['score'], d['weight_evaluable_pct']))" "$OUT_JSON" 2>/dev/null || echo '-')"
PASSFAIL="$(python3 -c "import json,sys; r=json.load(open(sys.argv[1]))['rows']; print('%d/%d/%d' % (sum(x['verdict']=='PASS' for x in r), sum(x['verdict']=='FAIL' for x in r), sum(x['verdict']=='n/a' for x in r)))" "$OUT_JSON" 2>/dev/null || echo '-')"
COSTSH="$(python3 - "$OUT_JSON" <<'PY' 2>/dev/null || echo '-'
import json, sys
d = json.load(open(sys.argv[1]))
row = [c for c in d["cost"] if "session-hour" in c["line"]][0]
f = lambda v: "-" if v is None else "%.4f" % v
print("%s -> %s" % (f(row["before"]), f(row["after"])))
PY
)"
VERD="$(python3 -c "import json,sys; print(json.load(open(sys.argv[1]))['verdict'].split(':')[0])" "$OUT_JSON" 2>/dev/null || echo '-')"
if [ ! -f RESULTS.md ]; then
  {
    echo "# Hermes tuning: before/after results"
    echo
    echo "One row per after.sh run. Score is the weighted acceptance score over the evaluable weight (compare.py). Cost is real USD per CLI session-hour, before -> after."
    echo
    echo "| run (UTC) | apply | after h | post-apply sessions | after calls | old sessions active | PASS/FAIL/n/a | score | \$/session-h | verdict | files |"
    echo "|---|---|---|---|---|---|---|---|---|---|---|"
  } > RESULTS.md
fi
echo "| $NOW | $APPLY | $HOURS_AFTER | $N_SESS | $N_CALLS | $N_OLD | $PASSFAIL | $SCORE | $COSTSH | $VERD | after_$TS.txt, after_$TS.json |" >> RESULTS.md
echo
echo "wrote $OUT_TXT"
echo "wrote $OUT_JSON"
echo "appended a row to $PLAN/RESULTS.md"
exit "$RC"
