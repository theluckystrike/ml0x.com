# measure: before and after, from the files Hermes and the proxy already write

Everything here is read-only against `HERMES_HOME` (default `~/.hermes`) and stdlib-only except the two ruamel
helpers. No network.

| file | what it does |
|---|---|
| `measure.py` | one metrics dump for a UTC window: ledger cost and tokens, prompt-size percentiles, cache share, compactions, exit-124s, delegation outcomes, skill errors, proxy 4xx counts. `--json` for machine output, `--sessions-started-after <ts>` to restrict the session metrics to sessions that run the new config. |
| `compare.py` | side-by-side of two `measure.py --json` dumps, scored against the twelve acceptance criteria (C1-C4, D1-D3, S1, T1, P1-P3) with weights; criteria without after-data are n/a and excluded from the score. |
| `after.sh` | the one-command readout: reads `apply_time_wave1.txt`, measures the before window (00:00 UTC of the apply day to the apply time) and the after window (apply time to now, new sessions only), runs `compare.py`, writes `after_<ts>.txt/.json` and appends a row to `RESULTS.md`. |
| `apply_tuning.py` | comment-preserving apply of every key in `../hermes-config/config.recommended.yaml` to a config.yaml (ruamel round-trip). Back the file up first. |
| `setkey.py` | comment-preserving edit of one dotted key, or `--delete`. |

## Procedure

1. Before touching anything: `python3 measure.py --since <today>T00:00:00Z > before.txt` and keep it.
2. Apply the proxy, policy, config and hook. Write the UTC time you did so into `apply_time_wave1.txt`
   (for example `2026-09-17T08:20:44Z`). Restart Hermes sessions: a running session keeps the old config.
3. After at least two hours of new sessions: `bash after.sh`. It prints post-apply session count, ledger calls, the
   PASS/FAIL/n/a tally, the weighted score and USD per CLI session-hour before and after, and appends to `RESULTS.md`.
4. Re-run `after.sh` as often as you like; each run is one row.

`HERMES_HOME=~/.hermes/profiles/pl-smoke python3 measure.py` measures a profile instead of the root install.
Criterion ids are shared between `measure.py` and `compare.py`. P1 is the count of `Bad request syntax` 400s in the
window (a total, not a rate); P2 is sweep 404s (Ollama-style probe paths such as `/api/tags`, `/api/show`,
`/v1/models/*`) divided by the window length in hours. `measure.py` also prints P0 (state.json readable and
reconciling with the ledger) and P2b (non-sweep 404s in the worst hour), which `compare.py` does not score.
`after.sh` writes its output files next to itself in this directory.

The rates table at the top of `measure.py` is the catalog price per model; keep it equal to `rates_usd_per_mtok`
in `policy.json`.
