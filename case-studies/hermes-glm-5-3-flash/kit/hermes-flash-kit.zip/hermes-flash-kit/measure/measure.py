#!/usr/bin/env python3
"""measure.py - Hermes tuning baseline and acceptance metrics. Read-only, stdlib only.

Sources (all opened read-only, nothing is written anywhere; HERMES_HOME overrides ~/.hermes):
  ~/.hermes/modellock/ledger.jsonl   per-call rows: ts, model, prompt_tokens, completion_tokens,
                                     cached_tokens (present since 2026-09-17T07:23Z), cost_usd,
                                     cost_source, running_total_usd, latency_s, streamed; plus
                                     event=deny (code 402/403/502) and event=upstream_error rows
  ~/.hermes/modellock/state.json     running totals the proxy caps against
  ~/.hermes/modellock/proxy.log      one access-log line per HTTP request, ISO UTC prefix
  ~/.hermes/state.db                 sessions, messages, async_delegations (sqlite, mode=ro)
  ~/.hermes/logs/agent.log           "API call #N ... in= out= cache=X/Y", "Preflight compression",
                                     "context compression started", "Tool skill_manage returned error",
                                     "Non-retryable client error", "hardcoded context length"

Usage:
  python3 measure.py                         # today 00:00 UTC to now
  python3 measure.py --since 2026-09-17T09:00:00Z
  python3 measure.py --since 2026-09-17T09:00:00Z --until 2026-09-17T11:00:00Z
  python3 measure.py --json                  # machine-readable dump of every metric
  python3 measure.py --since 2026-09-17T08:20:44Z --sessions-started-after 2026-09-17T08:20:44Z
        # restrict every sessions-db and agent.log metric to sessions (and their subagents, via
        # parent_session_id) created after the config apply; ledger/proxy metrics stay time-window only
        # because ledger rows carry no session id (the header reports how many pre-apply sessions were open)

Re-run before and after each rollout wave and diff the ACCEPTANCE table.
"""
import argparse
import calendar
import collections
import datetime as dt
import json
import os
import re
import sqlite3
import statistics
import sys

HOME = os.path.expanduser("~")
HERMES = os.environ.get("HERMES_HOME") or os.path.join(HOME, ".hermes")  # set HERMES_HOME to point at a profile
LEDGER = os.path.join(HERMES, "modellock", "ledger.jsonl")
STATE = os.path.join(HERMES, "modellock", "state.json")
POLICY = os.path.join(HERMES, "modellock", "policy.json")
PROXYLOG = os.path.join(HERMES, "modellock", "proxy.log")
STATEDB = os.path.join(HERMES, "state.db")
AGENTLOG = os.path.join(HERMES, "logs", "agent.log")
MEMORY_MD = os.path.join(HERMES, "memories", "MEMORY.md")

# Catalog rates, USD per million tokens, read from the Nous /v1/models pricing on 2026-09-17.
RATES = {
    "z-ai/glm-5.3-flash": {"in": 0.075, "out": 0.25, "cache": 0.01},
    "deepseek/deepseek-v4-flash-0731": {"in": 0.04, "out": 0.10, "cache": 0.01},
    "deepseek/deepseek-v4-flash": {"in": 0.05, "out": 0.14, "cache": 0.014},
}
DEFAULT_RATE = RATES["z-ai/glm-5.3-flash"]  # conservative for any unknown model
CACHE_CUTOFF = "2026-09-17T07:23:00+00:00"  # ledger rows before this have no cached_tokens
ASSUMED_CACHE_SHARE = 0.975                  # measured at the portal for the pre-cutoff window


def parse_iso(s):
    s = s.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    d = dt.datetime.fromisoformat(s)
    if d.tzinfo is None:
        d = d.replace(tzinfo=dt.timezone.utc)
    return d.astimezone(dt.timezone.utc)


def pct(xs, p):
    """Nearest-rank percentile."""
    if not xs:
        return 0
    xs = sorted(xs)
    k = max(0, min(len(xs) - 1, int(round(p / 100.0 * len(xs) + 0.5)) - 1))
    return xs[k]


def real_cost(row):
    """Catalog-rate cost of one ledger call row, cache-aware."""
    model = row.get("model") or ""
    r = RATES.get(model, DEFAULT_RATE)
    pt = row.get("prompt_tokens") or 0
    ct = row.get("completion_tokens") or 0
    if "cached_tokens" in row and row["cached_tokens"] is not None:
        cached = min(pt, row["cached_tokens"] or 0)
    else:
        cached = pt * ASSUMED_CACHE_SHARE
    unc = pt - cached
    return (unc * r["in"] + cached * r["cache"] + ct * r["out"]) / 1e6, cached


def cost_at_cap(row, cap):
    """Counterfactual: same call with prompt tokens clipped to `cap`, same cache share."""
    model = row.get("model") or ""
    r = RATES.get(model, DEFAULT_RATE)
    pt = row.get("prompt_tokens") or 0
    ct = row.get("completion_tokens") or 0
    if "cached_tokens" in row and row["cached_tokens"] is not None and pt:
        share = min(1.0, (row["cached_tokens"] or 0) / pt)
    else:
        share = ASSUMED_CACHE_SHARE
    pt2 = min(pt, cap)
    return (pt2 * (1 - share) * r["in"] + pt2 * share * r["cache"] + ct * r["out"]) / 1e6


def bucket_of(row):
    """Budget bucket of a ledger row: `bucket`, else the aliases `budget_key` / `key_suffix`, else (none)."""
    for k in ("bucket", "budget_key", "key_suffix"):
        v = row.get(k)
        if v not in (None, ""):
            return str(v)
    return "(none)"


# ---------------------------------------------------------------- ledger
def read_ledger(since, until):
    calls, denies, upstream_errs, other = [], [], [], collections.Counter()
    if not os.path.exists(LEDGER):
        return calls, denies, upstream_errs, other
    with open(LEDGER, errors="replace") as fh:
        for line in fh:
            try:
                row = json.loads(line)
            except ValueError:
                continue
            ts = row.get("ts")
            if not ts:
                continue
            try:
                t = parse_iso(ts)
            except ValueError:
                continue
            if t < since or t >= until:
                continue
            row["_t"] = t
            ev = row.get("event")
            if ev == "call":
                calls.append(row)
            elif ev == "deny":
                denies.append(row)
            elif ev == "upstream_error":
                upstream_errs.append(row)
            else:
                other[ev] += 1
    return calls, denies, upstream_errs, other


def ledger_metrics(calls, denies, upstream_errs, other, since, until):
    m = {}
    m["calls"] = len(calls)
    pts = [c.get("prompt_tokens") or 0 for c in calls]
    cts = [c.get("completion_tokens") or 0 for c in calls]
    lats = [c.get("latency_s") or 0 for c in calls]
    m["prompt_p50"] = pct(pts, 50)
    m["prompt_p90"] = pct(pts, 90)
    m["prompt_max"] = max(pts) if pts else 0
    m["prompt_mean"] = statistics.mean(pts) if pts else 0
    m["completion_p50"] = pct(cts, 50)
    m["prompt_tokens_total"] = sum(pts)
    m["completion_tokens_total"] = sum(cts)
    m["calls_over_60k"] = sum(1 for p in pts if p > 60000)
    m["calls_over_100k"] = sum(1 for p in pts if p > 100000)
    m["latency_p50"] = pct(lats, 50)
    m["latency_p90"] = pct(lats, 90)
    m["latency_over_120s"] = sum(1 for x in lats if x > 120)
    # cache share, measured only on rows that carry cached_tokens
    meas = [c for c in calls if c.get("cached_tokens") is not None]
    mp = sum(c.get("prompt_tokens") or 0 for c in meas)
    mc = sum(min(c.get("prompt_tokens") or 0, c.get("cached_tokens") or 0) for c in meas)
    m["cache_measured_rows"] = len(meas)
    m["cache_hit_share"] = (mc / mp) if mp else None
    # real cost
    tot = 0.0
    cache_cost = 0.0
    unc_cost = 0.0
    out_cost = 0.0
    by_model = collections.defaultdict(lambda: {"calls": 0, "cost": 0.0, "prompt": 0, "out": 0})
    for c in calls:
        cst, cached = real_cost(c)
        tot += cst
        r = RATES.get(c.get("model") or "", DEFAULT_RATE)
        cache_cost += cached * r["cache"] / 1e6
        unc_cost += ((c.get("prompt_tokens") or 0) - cached) * r["in"] / 1e6
        out_cost += (c.get("completion_tokens") or 0) * r["out"] / 1e6
        b = by_model[c.get("model") or "?"]
        b["calls"] += 1
        b["cost"] += cst
        b["prompt"] += c.get("prompt_tokens") or 0
        b["out"] += c.get("completion_tokens") or 0
    m["real_cost_total"] = tot
    m["real_cost_cache"] = cache_cost
    m["real_cost_uncached_in"] = unc_cost
    m["real_cost_out"] = out_cost
    m["real_cost_cache_share"] = (cache_cost / tot) if tot else None
    m["real_cost_per_call"] = (tot / len(calls)) if calls else 0
    m["ledger_cost_total"] = sum(c.get("cost_usd") or 0 for c in calls)
    m["by_model"] = dict(by_model)
    # counterfactual caps
    m["cost_if_cap"] = {cap: sum(cost_at_cap(c, cap) for c in calls) for cap in (40000, 50000, 60000)}
    # wall-clock span of the ledger inside the window
    if calls:
        first, last = min(c["_t"] for c in calls), max(c["_t"] for c in calls)
        m["ledger_span_h"] = max((last - first).total_seconds(), 60) / 3600.0
        # active hours: distinct minutes with at least one call
        mins = {c["_t"].replace(second=0, microsecond=0) for c in calls}
        m["active_h"] = len(mins) / 60.0
    else:
        m["ledger_span_h"] = 0
        m["active_h"] = 0
    m["real_cost_per_wallclock_h"] = (tot / m["ledger_span_h"]) if m["ledger_span_h"] else 0
    # denies and errors
    codes = collections.Counter(d.get("code") for d in denies)
    m["deny_402"] = codes.get(402, 0)
    m["deny_403"] = codes.get(403, 0)
    m["deny_502"] = codes.get(502, 0)
    m["deny_other"] = sum(v for k, v in codes.items() if k not in (402, 403, 502))
    m["deny_502_timeout"] = sum(1 for d in denies if d.get("code") == 502 and re.search(r"exit 28|timed out|timeout", str(d.get("message")), re.I))
    m["upstream_error"] = len(upstream_errs)
    m["upstream_error_status"] = dict(collections.Counter(e.get("status") for e in upstream_errs))
    m["degrade_rewrites"] = sum(1 for c in calls if c.get("rewrite") or (c.get("requested_model") and c.get("requested_model") != c.get("model")))
    # new event kinds the planned proxy changes will add (warn, degrade, bucket)
    m["events_other"] = dict(other)
    m["calls_with_bucket"] = sum(1 for c in calls if c.get("bucket") or c.get("budget_key") or c.get("key_suffix"))
    # per-bucket split (the proxy is gaining a `bucket` field; budget_key/key_suffix are accepted aliases)
    bb = collections.defaultdict(lambda: {"calls": 0, "real_cost": 0.0, "prompt_tokens": [], "deny_402": 0, "deny_other": 0})
    any_bucket = False
    for c in calls:
        b = bucket_of(c)
        if b != "(none)":
            any_bucket = True
        bb[b]["calls"] += 1
        bb[b]["real_cost"] += real_cost(c)[0]
        bb[b]["prompt_tokens"].append(c.get("prompt_tokens") or 0)
    for d in denies:
        b = bucket_of(d)
        if b != "(none)":
            any_bucket = True
        if d.get("code") == 402:
            bb[b]["deny_402"] += 1
        else:
            bb[b]["deny_other"] += 1
    m["by_bucket"] = {}
    if any_bucket:
        for b, v in sorted(bb.items()):
            pts_b = v.pop("prompt_tokens")
            v["prompt_p50"] = pct(pts_b, 50)
            v["prompt_p90"] = pct(pts_b, 90)
            v["real_cost_per_call"] = (v["real_cost"] / v["calls"]) if v["calls"] else 0
            m["by_bucket"][b] = v
    m["warn_events"] = sum(v for k, v in other.items() if k and ("warn" in k))
    m["degrade_events"] = sum(v for k, v in other.items() if k and ("degrade" in k))
    # every 402 preceded by a warn event? (only meaningful once warn events exist)
    m["hours_with_402"] = sorted({d["_t"].strftime("%H") for d in denies if d.get("code") == 402})
    return m


# ---------------------------------------------------------------- state.json / policy.json
def state_metrics():
    m = {}
    try:
        with open(STATE) as fh:
            st = json.load(fh)
        m["state_ok"] = True
        m["state_total_usd"] = st.get("total_usd")
        m["state_calls"] = st.get("calls")
        m["state_blocked"] = st.get("blocked")
        today = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d")
        m["state_today_usd"] = (st.get("days") or {}).get(today)
        m["state_portal_keys"] = sorted(k for k in st.keys() if "portal" in k or "credit" in k or "usable" in k)
        for k in m["state_portal_keys"]:
            m["state_" + k] = st.get(k)
    except Exception as e:  # noqa
        m["state_ok"] = False
        m["state_error"] = str(e)[:120]
    try:
        with open(POLICY) as fh:
            pol = json.load(fh)
        caps = pol.get("caps", {})
        m["cap_total_usd"] = caps.get("total_usd")
        m["cap_daily_usd"] = caps.get("daily_usd")
        m["policy_has_buckets"] = bool(pol.get("buckets") or pol.get("budgets") or pol.get("keys"))
        m["policy_has_warn"] = any("warn" in k for k in caps.keys())
        m["policy_has_degrade"] = any("degrade" in k for k in list(caps.keys()) + list(pol.keys()))
        m["policy_has_portal"] = any("portal" in k or "credit" in k for k in list(caps.keys()) + list(pol.keys()))
        m["policy_stream_timeout_keys"] = sorted(k for k in list(pol.keys()) + list(caps.keys()) if "timeout" in k or "stall" in k)
    except Exception as e:  # noqa
        m["policy_error"] = str(e)[:120]
    return m


# ---------------------------------------------------------------- proxy.log
def proxy_metrics(since, until):
    m = {"proxy_lines": 0}
    codes = collections.Counter()
    per_hour_404 = collections.Counter()
    per_hour_400 = collections.Counter()
    api_show = 0
    bad_syntax = 0
    sweep_paths = ("/api/v1/models", "/api/tags", "/v1/props", "/props", "/version", "/api/show", "/v1/models/")
    per_hour_404_other = collections.Counter()
    sweep_404 = 0
    if not os.path.exists(PROXYLOG):
        m["proxy_missing"] = True
        return m
    rx = re.compile(r'^(\S+) "(\w+) (\S+) [^"]*" (\d{3})')
    rx_bad = re.compile(r'^(\S+) code 400, message Bad request syntax')
    with open(PROXYLOG, errors="replace") as fh:
        for line in fh:
            if not line[:4].isdigit():
                continue
            try:
                t = parse_iso(line.split(" ", 1)[0])
            except ValueError:
                continue
            if t < since or t >= until:
                continue
            m["proxy_lines"] += 1
            mm = rx.match(line)
            if mm:
                code = int(mm.group(4))
                codes[code] += 1
                hr = t.strftime("%Y-%m-%dT%H")
                if code == 404:
                    per_hour_404[hr] += 1
                    path = mm.group(3)
                    if path.startswith("/api/show"):
                        api_show += 1
                    if path.startswith(sweep_paths):
                        sweep_404 += 1
                    else:
                        per_hour_404_other[hr] += 1
                continue
            if rx_bad.match(line):
                bad_syntax += 1
                per_hour_400[t.strftime("%Y-%m-%dT%H")] += 1
    m["proxy_codes"] = dict(sorted(codes.items()))
    m["proxy_402"] = codes.get(402, 0)
    m["proxy_404"] = codes.get(404, 0)
    m["proxy_400_bad_syntax"] = bad_syntax
    m["proxy_api_show_404"] = api_show
    hours = max(1.0, (until - since).total_seconds() / 3600.0)
    m["proxy_404_per_hour_mean"] = codes.get(404, 0) / hours
    m["proxy_404_per_hour_max"] = max(per_hour_404.values()) if per_hour_404 else 0
    m["proxy_400_per_hour_max"] = max(per_hour_400.values()) if per_hour_400 else 0
    m["proxy_404_sweep"] = sweep_404
    m["proxy_404_other"] = sum(per_hour_404_other.values())
    m["proxy_404_other_per_hour_max"] = max(per_hour_404_other.values()) if per_hour_404_other else 0
    return m


# ---------------------------------------------------------------- state.db
def session_filter_ids(started_after):
    """Ids of sessions started at or after `started_after` (UTC datetime) plus every descendant
    reached through parent_session_id. Returns (ids, info). Read-only."""
    info = {"session_filter_after": started_after.isoformat()}
    try:
        con = sqlite3.connect("file:%s?mode=ro" % STATEDB, uri=True, timeout=5)
    except sqlite3.Error as e:
        info["session_filter_error"] = str(e)
        return set(), info
    ep = started_after.timestamp()
    # Roots: sessions started at/after the cut whose parent is not a known session (a fresh process).
    # Descendants: anything reached through parent_session_id from a root. A subagent started after
    # the cut by a PRE-cut parent runs inside that parent's process and keeps the old config, so it is
    # excluded and counted separately.
    rows = con.execute("""
        with recursive tree(id, depth) as (
            select id, 0 from sessions
             where started_at >= ?
               and (parent_session_id is null or parent_session_id = ''
                    or parent_session_id not in (select id from sessions))
            union
            select s.id, t.depth + 1 from sessions s join tree t on s.parent_session_id = t.id
        ) select id, min(depth) d from tree group by id""", (ep,)).fetchall()
    ids = {r[0] for r in rows}
    info["session_filter_roots"] = sum(1 for r in rows if r[1] == 0)
    info["session_filter_descendants_added"] = sum(1 for r in rows if r[1] > 0)
    info["session_filter_n"] = len(ids)
    srcs = con.execute("select source, id from sessions where started_at >= ?", (ep,)).fetchall()
    info["session_filter_by_source"] = dict(collections.Counter(r[0] for r in srcs if r[1] in ids))
    info["post_apply_children_of_pre_apply_parents_excluded"] = sum(1 for r in srcs if r[1] not in ids)
    # sessions started before the cut that still wrote messages after it: they run the OLD config
    # (ended_at is never populated, so activity is measured from the messages table)
    info["pre_apply_sessions_active_after"] = con.execute(
        "select count(distinct s.id) from sessions s join messages m on m.session_id = s.id "
        "where s.started_at < ? and m.timestamp >= ?", (ep, ep)).fetchone()[0]
    info["pre_apply_cli_sessions_active_after"] = con.execute(
        "select count(distinct s.id) from sessions s join messages m on m.session_id = s.id "
        "where s.started_at < ? and m.timestamp >= ? and s.source='cli'", (ep, ep)).fetchone()[0]
    con.close()
    return ids, info


def _sql_id_list(ids):
    safe = sorted(i for i in ids if re.fullmatch(r"[\w.-]+", str(i)))
    return "(" + ",".join("'%s'" % i for i in safe) + ")" if safe else "('')"


def db_metrics(since, until, only_ids=None):
    m = {}
    s_ep, u_ep = since.timestamp(), until.timestamp()
    try:
        con = sqlite3.connect("file:%s?mode=ro" % STATEDB, uri=True, timeout=5)
    except sqlite3.Error as e:
        m["db_error"] = str(e)
        return m
    con.row_factory = sqlite3.Row
    q = lambda sql, *a: con.execute(sql, a).fetchall()  # noqa
    W = "started_at>=? and started_at<?"
    DW = ""
    if only_ids is not None:
        idl = _sql_id_list(only_ids)
        W += " and id in " + idl
        DW = " and (origin_session in %s or parent_session_id in %s or coalesce(origin_session_id,'') in %s)" % (idl, idl, idl)
    IDS = "(select id from sessions where %s)" % W
    # sessions
    rows = q("select source, count(*) n, sum(api_call_count) api, sum(input_tokens) inp, "
             "sum(cache_read_tokens) cr, sum(output_tokens) outp, "
             "sum(max(0, coalesce(ended_at, last_activity_at, started_at)-started_at))/3600.0 hours "
             "from sessions where %s group by 1" % W, s_ep, u_ep)
    m["sessions"] = {r["source"]: dict(r) for r in rows}
    cli = m["sessions"].get("cli", {})
    m["cli_sessions"] = cli.get("n", 0)
    m["subagent_sessions"] = m["sessions"].get("subagent", {}).get("n", 0)
    m["cli_session_hours"] = cli.get("hours", 0) or 0
    m["all_session_hours"] = sum((v.get("hours") or 0) for v in m["sessions"].values())
    m["cli_api_calls"] = cli.get("api", 0) or 0
    m["subagent_api_calls"] = m["sessions"].get("subagent", {}).get("api", 0) or 0
    # db cache share (cache_read / (input + cache_read))
    inp = sum((v.get("inp") or 0) for v in m["sessions"].values())
    cr = sum((v.get("cr") or 0) for v in m["sessions"].values())
    m["db_cache_share"] = (cr / (inp + cr)) if (inp + cr) else None
    m["profile_sessions"] = q("select coalesce(profile_name,'(none)') p, count(*) n from sessions where %s group by 1" % W, s_ep, u_ep)
    m["profile_sessions"] = {r["p"]: r["n"] for r in m["profile_sessions"]}
    m["cost_status"] = {r["c"]: r["n"] for r in q("select coalesce(cost_status,'NULL') c, count(*) n from sessions where %s group by 1" % W, s_ep, u_ep)}
    m["sessions_with_cost"] = q("select count(*) n from sessions where %s and coalesce(estimated_cost_usd, actual_cost_usd, 0) > 0" % W, s_ep, u_ep)[0]["n"]
    # finish reasons
    m["finish_reasons"] = {str(r["f"]): r["n"] for r in q("select finish_reason f, count(*) n from messages where role='assistant' and session_id in %s group by 1" % IDS, s_ep, u_ep)}
    m["verification_required"] = m["finish_reasons"].get("verification_required", 0)
    m["finish_length"] = m["finish_reasons"].get("length", 0)
    # exit 124 and sleep
    m["exit_124"] = q("select count(*) n from messages where role='tool' and tool_name='terminal' and session_id in %s and content like '%%\"exit_code\": 124%%'" % IDS, s_ep, u_ep)[0]["n"]
    sleep_s, sleep_n = 0, 0
    to_over_120 = 0
    term_n = 0
    bg_n = 0
    rx_sleep = re.compile(r"(?<![\w.-])sleep\s+(\d+(?:\.\d+)?)")
    for r in q("select tool_calls from messages where role='assistant' and tool_calls is not null and session_id in %s" % IDS, s_ep, u_ep):
        try:
            arr = json.loads(r["tool_calls"])
        except ValueError:
            continue
        for t in arr:
            f = t.get("function") or {}
            if f.get("name") != "terminal":
                continue
            term_n += 1
            try:
                a = json.loads(f.get("arguments") or "{}")
            except ValueError:
                continue
            cmd = a.get("command") or ""
            for mm in rx_sleep.finditer(cmd):
                sleep_s += float(mm.group(1))
                sleep_n += 1
            if a.get("background"):
                bg_n += 1
            elif (a.get("timeout") or 0) > 120:
                to_over_120 += 1
    m["terminal_calls"] = term_n
    m["terminal_background"] = bg_n
    m["terminal_timeout_over_120_fg"] = to_over_120
    m["sleep_commands"] = sleep_n
    m["sleep_seconds"] = sleep_s
    # tool result sizes
    r = q("select count(*) n, max(length(content)) mx, sum(length(content)>20000) gt20k, sum(length(content)>25000) gt25k, sum(length(content)>50000) gt50k from messages where role='tool' and session_id in %s" % IDS, s_ep, u_ep)[0]
    m["tool_results"] = r["n"]
    m["tool_result_max_chars"] = r["mx"] or 0
    m["tool_result_gt20k"] = r["gt20k"] or 0
    m["tool_result_gt25k"] = r["gt25k"] or 0
    m["tool_result_gt50k"] = r["gt50k"] or 0
    m["compacted_messages"] = q("select count(*) n from messages where compacted=1 and session_id in %s" % IDS, s_ep, u_ep)[0]["n"]
    # delegations
    dl = q("select * from async_delegations where dispatched_at>=? and dispatched_at<?%s order by dispatched_at" % DW, s_ep, u_ep)
    m["delegations"] = len(dl)
    tasks = []
    lags = []
    durs = []
    undelivered = 0
    for d in dl:
        if d["completed_at"] and d["delivered_at"]:
            lags.append(d["delivered_at"] - d["completed_at"])
        if d["completed_at"] and d["delivery_state"] != "delivered":
            undelivered += 1
        if d["completed_at"]:
            durs.append(d["completed_at"] - d["dispatched_at"])
        if d["result_json"]:
            try:
                j = json.loads(d["result_json"])
            except ValueError:
                j = {}
            for t in j.get("results") or []:
                summ = str(t.get("summary") or "")
                head = summ[:300]
                is_402 = bool(re.search(r"HTTP 402|\b402\b|credits exhausted|spend cap|daily cap", head))
                is_502 = bool(re.search(r"HTTP 502|\b502\b|upstream unreachable", head))
                tasks.append({"status": t.get("status"), "exit": t.get("exit_reason"), "api_calls": t.get("api_calls"),
                              "dur": t.get("duration_seconds"), "is_402": is_402, "is_502": is_502,
                              "wrote_file": bool(re.search(r"(wrote|written|saved|created).{0,40}(\.md|\.json|\.html|\.py|\.txt)", summ, re.I))})
    m["delegation_tasks"] = len(tasks)
    m["delegation_completed_tasks"] = sum(1 for t in tasks if t["status"] == "completed")
    mi = [t for t in tasks if t["exit"] == "max_iterations"]
    m["delegation_max_iterations"] = len(mi)
    m["delegation_max_iterations_share"] = (len(mi) / len(tasks)) if tasks else None
    m["delegation_402_deaths"] = sum(1 for t in tasks if t["is_402"])
    m["delegation_502_deaths"] = sum(1 for t in tasks if t["is_502"])
    m["delegation_genuine_cap_no_file"] = sum(1 for t in mi if not t["is_402"] and not t["is_502"] and not t["wrote_file"])
    m["delegation_exit_reasons"] = dict(collections.Counter(str(t["exit"]) for t in tasks))
    m["delegation_api_calls_p50"] = pct([t["api_calls"] or 0 for t in tasks], 50)
    m["delegation_api_calls_max"] = max([t["api_calls"] or 0 for t in tasks], default=0)
    m["delegation_dur_p50_min"] = pct(durs, 50) / 60.0 if durs else 0
    m["delegation_dur_p90_min"] = pct(durs, 90) / 60.0 if durs else 0
    m["delegation_dur_max_min"] = max(durs) / 60.0 if durs else 0
    m["delegation_over_900s"] = sum(1 for x in durs if x > 900)
    m["delegation_over_1800s"] = sum(1 for x in durs if x > 1800)
    m["delivery_lag_p50_min"] = pct(lags, 50) / 60.0 if lags else 0
    m["delivery_lag_max_min"] = max(lags) / 60.0 if lags else 0
    m["delegation_undelivered_completed"] = undelivered
    # max concurrent delegations in flight
    ev = []
    for d in dl:
        ev.append((d["dispatched_at"], 1))
        ev.append((d["completed_at"] or u_ep, -1))
    ev.sort()
    cur = peak = 0
    for _, delta in ev:
        cur += delta
        peak = max(peak, cur)
    m["delegation_peak_in_flight"] = peak
    con.close()
    return m


# ---------------------------------------------------------------- agent.log
def detect_log_offset(last_ledger_ts):
    """agent.log timestamps are naive local time. Calibrate the offset by comparing the last
    'API call #' line with the last ledger call (they are the same event within seconds).
    Falls back to the system offset."""
    sys_off = dt.datetime.now().astimezone().utcoffset()
    if not last_ledger_ts or not os.path.exists(AGENTLOG):
        return sys_off
    try:
        with open(AGENTLOG, "rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(0, size - 400000))
            tail = fh.read().decode("utf-8", "replace")
    except OSError:
        return sys_off
    last = None
    for line in tail.splitlines():
        if "API call #" in line and line[:4].isdigit():
            last = line[:19]
    if not last:
        return sys_off
    try:
        t_log = dt.datetime.strptime(last, "%Y-%m-%d %H:%M:%S").replace(tzinfo=dt.timezone.utc)
    except ValueError:
        return sys_off
    diff_h = (t_log - last_ledger_ts).total_seconds() / 3600.0
    return dt.timedelta(hours=round(diff_h))


RX_LOG_SID = re.compile(r"\[(\d{8}_\d{6}_[0-9a-zA-Z]+)\]|session=(\d{8}_\d{6}_[0-9a-zA-Z]+)")


def agentlog_metrics(since, until, local_off, only_ids=None):
    m = {}
    if not os.path.exists(AGENTLOG):
        m["agentlog_missing"] = True
        return m
    dropped_untagged = 0
    dropped_other_session = 0
    # agent.log timestamps are naive local time; convert the window to local strings
    lo = (since + local_off).strftime("%Y-%m-%d %H:%M:%S")
    hi = (until + local_off).strftime("%Y-%m-%d %H:%M:%S")
    m["al_local_offset_h"] = local_off.total_seconds() / 3600.0
    rx_api = re.compile(r"\[(\d{8}_\d{6}_\w+)\] agent\.conversation_loop: API call #(\d+): model=(\S+) .*?in=(\d+) out=(\d+).*?(?:cache=(\d+)/(\d+))?\s*$")
    rx_pre = re.compile(r"Preflight compression: ~([\d,]+) tokens >= ([\d,]+) threshold \(model (\S+), ctx ([\d,]+)\)")
    rx_hc = re.compile(r"hardcoded context length ([\d,]+) for model '([^']+)'")
    c = collections.Counter()
    first_call_in = []
    first_call_in_sub = []
    preflight_thresholds = collections.Counter()
    ctx_lengths = collections.Counter()
    sm_err_kinds = collections.Counter()
    sessions_seen = {}
    with open(AGENTLOG, errors="replace") as fh:
        for line in fh:
            ts = line[:19]
            if not (lo <= ts < hi):
                continue
            if only_ids is not None:
                mm = RX_LOG_SID.search(line)
                sid = (mm.group(1) or mm.group(2)) if mm else None
                if sid is None:
                    dropped_untagged += 1
                    continue
                if sid not in only_ids:
                    dropped_other_session += 1
                    continue
            c["lines"] += 1
            if "API call #" in line:
                mm = rx_api.search(line)
                if mm:
                    c["api_calls"] += 1
                    sid, n, model, inn = mm.group(1), int(mm.group(2)), mm.group(3), int(mm.group(4))
                    if n == 1:
                        first_call_in.append(inn)
                        sessions_seen[sid] = inn
                continue
            if "Preflight compression" in line:
                c["preflight_compression"] += 1
                mm = rx_pre.search(line)
                if mm:
                    preflight_thresholds[int(mm.group(2).replace(",", ""))] += 1
            elif "context compression started" in line:
                c["compression_started"] += 1
            elif "compression" in line and ("failed" in line or "ineffective" in line):
                c["compression_failed"] += 1
            elif "prune" in line.lower() and "tool" in line.lower():
                c["proactive_prune"] += 1
            if "hardcoded context length" in line:
                mm = rx_hc.search(line)
                if mm:
                    ctx_lengths[(mm.group(2), int(mm.group(1).replace(",", "")))] += 1
            if "Tool skill_manage returned error" in line:
                c["skill_manage_errors"] += 1
                if "curator" in line:
                    sm_err_kinds["curator_refused"] += 1
                elif "60-char" in line or "chars" in line:
                    sm_err_kinds["description_too_long"] += 1
                else:
                    sm_err_kinds["other"] += 1
            if "Non-retryable client error" in line:
                c["non_retryable"] += 1
                if "402" in line:
                    c["non_retryable_402"] += 1
            if "nudge" in line.lower() and ("memory" in line.lower() or "skill" in line.lower()) and "Tool terminal" not in line:
                c["nudge_lines"] += 1
            if "verification_required" in line or "verify_on_stop" in line:
                c["verify_lines"] += 1
            if "Relay turn finalization failed" in line:
                c["relay_fail"] += 1
            if "BLOCKED (hardline)" in line:
                c["hardline_blocks"] += 1
            if "Auxiliary" in line and "402" in line:
                c["aux_402"] += 1
    m.update({"al_" + k: v for k, v in c.items()})
    m["al_first_call_in_p50"] = pct(first_call_in, 50)
    m["al_first_call_in_n"] = len(first_call_in)
    m["al_preflight_thresholds"] = dict(preflight_thresholds)
    m["al_ctx_lengths"] = {"%s@%d" % k: v for k, v in ctx_lengths.items()}
    m["al_skill_manage_error_kinds"] = dict(sm_err_kinds)
    if only_ids is not None:
        m["al_filtered_to_sessions"] = len(only_ids)
        m["al_dropped_untagged_lines"] = dropped_untagged
        m["al_dropped_other_session_lines"] = dropped_other_session
    return m


def memory_metrics():
    m = {}
    try:
        m["memory_md_bytes"] = os.path.getsize(MEMORY_MD)
    except OSError:
        m["memory_md_bytes"] = 0
    return m


# ---------------------------------------------------------------- acceptance
def acceptance(M, hours):
    """Returns list of (id, change, metric, value, threshold, verdict)."""
    A = []

    def add(i, change, metric, val, thr, ok, fmt="{}"):
        if val is None:
            verdict = "n/a"
        elif ok is None:
            verdict = "info"
        else:
            verdict = "PASS" if ok else "FAIL"
        A.append((i, change, metric, (fmt.format(val) if val is not None else "-"), thr, verdict))

    p90, p50 = M["prompt_p90"], M["prompt_p50"]
    add("C1", "compression 48k", "ledger p90 prompt tokens", p90, "< 60,000", p90 < 60000, "{:,}")
    add("C1b", "compression 48k", "ledger p50 prompt tokens", p50, "< 45,000", p50 < 45000, "{:,}")
    add("C1c", "compression 48k", "preflight threshold seen in agent.log", ",".join(str(k) for k in sorted(M.get("al_preflight_thresholds", {}))) or None, "= 48000 (any other value = config not live)", (list(M.get("al_preflight_thresholds", {}).keys()) == [48000]) if M.get("al_preflight_thresholds") else None)
    add("C1d", "compression 48k", "calls over 100k prompt", M["calls_over_100k"], "= 0", M["calls_over_100k"] == 0, "{:,}")
    add("C2", "prune 24k", "compression_started per 1000 calls", (M.get("al_compression_started", 0) * 1000.0 / M["calls"]) if M["calls"] else None, "between 2 and 20 (0 = not firing, >20 = thrashing)", (2 <= (M.get("al_compression_started", 0) * 1000.0 / max(M["calls"], 1)) <= 20) if M["calls"] else None, "{:.1f}")
    add("C2b", "prune 24k", "share of calls over 60k prompt", (M["calls_over_60k"] / M["calls"]) if M["calls"] else None, "< 10 percent", ((M["calls_over_60k"] / M["calls"]) < 0.10) if M["calls"] else None, "{:.1%}")
    add("C3", "tool_output 20k", "tool results over 25k chars", M["tool_result_gt25k"], "= 0", M["tool_result_gt25k"] == 0, "{:,}")
    add("C3b", "tool_output 20k", "largest tool result, chars", M["tool_result_max_chars"], "< 25,000", M["tool_result_max_chars"] < 25000, "{:,}")
    add("C4", "terminal timeout 120", "exit-124 per CLI session-hour", (M["exit_124"] / M["cli_session_hours"]) if M["cli_session_hours"] else None, "< 1.0", ((M["exit_124"] / M["cli_session_hours"]) < 1.0) if M["cli_session_hours"] else None, "{:.2f}")
    add("C4b", "terminal timeout 120", "foreground terminal calls with timeout > 120", M["terminal_timeout_over_120_fg"], "= 0 (long jobs must use background=true)", M["terminal_timeout_over_120_fg"] == 0, "{:,}")
    add("C4c", "terminal timeout 120", "sleep seconds per CLI session-hour", (M["sleep_seconds"] / M["cli_session_hours"]) if M["cli_session_hours"] else None, "< 120", ((M["sleep_seconds"] / M["cli_session_hours"]) < 120) if M["cli_session_hours"] else None, "{:.0f}")
    n_tasks = M["delegation_tasks"]
    share = M["delegation_max_iterations_share"]
    add("D1", "delegation 30/2/900", "max_iterations share (n=%d tasks)" % n_tasks, share, "< 15 percent over >= 20 tasks", (share < 0.15 and n_tasks >= 20) if share is not None else None, "{:.1%}")
    add("D1b", "delegation 30/2/900", "402/502 deaths labelled max_iterations", M["delegation_402_deaths"] + M["delegation_502_deaths"], "= 0", (M["delegation_402_deaths"] + M["delegation_502_deaths"]) == 0, "{:,}")
    add("D1c", "delegation 30/2/900", "genuine cap hits with no file written", M["delegation_genuine_cap_no_file"], "= 0", M["delegation_genuine_cap_no_file"] == 0, "{:,}")
    add("D2", "delegation 30/2/900", "peak delegations in flight", M["delegation_peak_in_flight"], "<= 2 per parent (<= 10 total across 5 parents)", M["delegation_peak_in_flight"] <= 10, "{:,}")
    add("D3", "delegation 30/2/900", "delegations over 900 s", M["delegation_over_900s"], "= 0 after child_timeout_seconds=900", M["delegation_over_900s"] == 0, "{:,}")
    add("D3b", "delegation 30/2/900", "subagent duration p50 / p90, min", "%.1f / %.1f" % (M["delegation_dur_p50_min"], M["delegation_dur_p90_min"]), "p90 <= 15", M["delegation_dur_p90_min"] <= 15)
    add("D4", "delegation 30/2/900", "delivery lag p50, min", M["delivery_lag_p50_min"], "< 5 (target after runner or push delivery)", M["delivery_lag_p50_min"] < 5, "{:.1f}")
    add("D4b", "delegation 30/2/900", "completed but undelivered results", M["delegation_undelivered_completed"], "= 0 at end of window", M["delegation_undelivered_completed"] == 0, "{:,}")
    add("N1", "nudges 30/40", "skill_manage errors per day-equivalent", (M.get("al_skill_manage_errors", 0) * 24.0 / hours) if hours else None, "< 5", ((M.get("al_skill_manage_errors", 0) * 24.0 / hours) < 5) if hours else None, "{:.1f}")
    add("N1b", "nudges 30/40", "curator refusals", M.get("al_skill_manage_error_kinds", {}).get("curator_refused", 0), "= 0 with curator opt-in", M.get("al_skill_manage_error_kinds", {}).get("curator_refused", 0) == 0, "{:,}")
    add("T1", "toolset trim", "agent.log API call #1 prompt tokens p50 (n=%d)" % M["al_first_call_in_n"], M["al_first_call_in_p50"] or None, "< 12,000 (fresh subagent was 16.3k: 3.3k system + 12.7k schema)", (M["al_first_call_in_p50"] < 12000) if M["al_first_call_in_p50"] else None, "{:,}")
    add("M1", "memory purge", "MEMORY.md bytes", M["memory_md_bytes"], "< 400", M["memory_md_bytes"] < 400, "{:,}")
    add("V1", "verify_on_stop off per profile", "verification_required finishes", M["verification_required"], "= 0 in profile sessions (global count shown; split by profile once profiles exist)", M["verification_required"] == 0, "{:,}")
    add("V1b", "verify_on_stop off per profile", "sessions with a profile_name", sum(v for k, v in M["profile_sessions"].items() if k != "(none)"), "> 0 once the runner is live", sum(v for k, v in M["profile_sessions"].items() if k != "(none)") > 0, "{:,}")
    add("P0", "proxy fail-closed", "state.json parses and reconciles", ("ok total=%.4f" % M["state_total_usd"]) if M.get("state_ok") else "UNREADABLE", "readable; a corrupt file must produce deny code 503, never zeros", M.get("state_ok"))
    add("P0b", "proxy fail-closed", "ledger real cost since window start vs state today", ("ledger %.4f / state %.4f" % (M["real_cost_total"], M["state_today_usd"] or 0)) if M.get("state_ok") else None, "difference < 10 percent for a full-day window (state was rebased to the portal at 07:30)", (abs(M["real_cost_total"] - (M["state_today_usd"] or 0)) / max(M["real_cost_total"], 0.01) < 0.10) if M.get("state_ok") else None)
    add("P1", "drain-body", "bad-syntax 400s in window (count)", M["proxy_400_bad_syntax"], "= 0 while /api/show 404s still occur (%d in window)" % M["proxy_api_show_404"], M["proxy_400_bad_syntax"] == 0, "{:,}")
    add("P2", "drain-body", "sweep 404s per hour (window mean)", (M["proxy_404_sweep"] / M["window_hours"]) if M.get("window_hours") else None, "< 5 (sweep paths /api/tags,/props,/version,/api/show,/v1/models/*; %d sweep 404s in window)" % M["proxy_404_sweep"], ((M["proxy_404_sweep"] / M["window_hours"]) < 5) if M.get("window_hours") else None, "{:.1f}")
    add("P2b", "drain-body", "non-sweep 404s per hour, max hour", M["proxy_404_other_per_hour_max"], "< 5 (sweep paths /api/tags,/props,/version,/api/show,/v1/models/* excluded; %d sweep 404s in window)" % M["proxy_404_sweep"], M["proxy_404_other_per_hour_max"] < 5, "{:,}")
    add("P3", "warning header", "warn events in ledger", M["warn_events"], ">= 1 before every 402; 0 402s without a prior warn", (M["warn_events"] >= 1 and M["deny_402"] == 0) or (M["warn_events"] >= M["deny_402"] > 0), "{:,}")
    add("P4", "degrade", "402 denies (ledger); est. usable credits %.2f" % M["usable_credits_now_est"], M["deny_402"], "= 0 while usable credits > reserve %.2f" % M["reserve"], M["deny_402"] == 0 or M["usable_credits_now_est"] <= M["reserve"], "{:,}")
    add("P4b", "degrade", "degrade events / rewrites", M["degrade_events"] + M["degrade_rewrites"], ">= 1 on any day the 80 percent line is crossed; else 0", None, "{:,}")
    add("P5", "buckets", "calls carrying a budget bucket", ("%d of %d" % (M["calls_with_bucket"], M["calls"])), "> 95 percent once pipelines run under the runner", (M["calls_with_bucket"] / M["calls"] > 0.95) if M["calls"] else None)
    add("P6", "portal guard", "state.json portal/credit keys", ",".join(M.get("state_portal_keys", [])) or None, "present, polled < 10 min ago, usable_credits within 0.05 of portal", bool(M.get("state_portal_keys")))
    add("P7", "streaming timeout", "502 denies that are curl timeouts", M["deny_502_timeout"], "= 0", M["deny_502_timeout"] == 0, "{:,}")
    add("P7b", "streaming timeout", "calls with latency > 120 s recorded as calls", M["latency_over_120s"], ">= 0 and priced (was killed at 120 s and booked $0)", None, "{:,}")
    add("P7c", "streaming timeout", "upstream_error rows", M["upstream_error"], "< 5 per day", M["upstream_error"] < 5, "{:,}")
    add("R1", "runner", "sessions with estimated/actual cost populated", M["sessions_with_cost"], "= all CLI sessions once ledger backfill runs", M["sessions_with_cost"] > 0, "{:,}")
    add("R2", "runner", "non-retryable 402 in agent.log", M.get("al_non_retryable_402", 0), "= 0 (runner resumes instead of dying)", M.get("al_non_retryable_402", 0) == 0, "{:,}")
    add("Q1", "cost (all waves)", "real cost per call, USD", M["real_cost_per_call"], "< 0.00060 after waves 1-2; < 0.00050 after 3-4", M["real_cost_per_call"] < 0.0006, "{:.5f}")
    add("Q2", "cost (all waves)", "real cost per CLI session-hour, USD", (M["real_cost_total"] / M["cli_session_hours"]) if M["cli_session_hours"] else None, "< 0.12 after waves 1-2; < 0.10 after 3-4", ((M["real_cost_total"] / M["cli_session_hours"]) < 0.12) if M["cli_session_hours"] else None, "{:.4f}")
    add("Q3", "cost (all waves)", "cache-read share of real cost", M["real_cost_cache_share"], "< 60 percent (was 75-77)", (M["real_cost_cache_share"] < 0.60) if M["real_cost_cache_share"] is not None else None, "{:.1%}")
    return A


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    now = dt.datetime.now(dt.timezone.utc)
    ap.add_argument("--since", default=now.strftime("%Y-%m-%dT00:00:00Z"), help="ISO time, UTC assumed if no offset")
    ap.add_argument("--until", default=None, help="ISO time; default now")
    ap.add_argument("--usable-credits", type=float, default=35.10, help="portal total_usable_credits at last read")
    ap.add_argument("--credits-read-at", default="2026-09-17T07:22:00Z", help="when --usable-credits was read (ledger burn after this is subtracted)")
    ap.add_argument("--reserve", type=float, default=1.10, help="credits kept back (cap_total = usable - reserve)")
    ap.add_argument("--grant", type=float, default=22.0, help="monthly subscription grant, credits")
    ap.add_argument("--grant-date", default="2026-10-04", help="next grant date")
    ap.add_argument("--log-offset-hours", type=float, default=None, help="agent.log local-time offset from UTC; default: calibrated against the ledger")
    ap.add_argument("--sessions-started-after", default=None, metavar="ISO",
                    help="restrict sessions-db and agent.log metrics to sessions started at/after this time, "
                         "plus their subagents via parent_session_id (use the config apply time)")
    ap.add_argument("--json", action="store_true", help="dump every metric as JSON")
    args = ap.parse_args()
    since = parse_iso(args.since)
    until = parse_iso(args.until) if args.until else now
    hours = max((until - since).total_seconds() / 3600.0, 1 / 60.0)

    only_ids = None
    finfo = {}
    if args.sessions_started_after:
        only_ids, finfo = session_filter_ids(parse_iso(args.sessions_started_after))

    calls, denies, ue, other = read_ledger(since, until)
    M = {}
    M.update(ledger_metrics(calls, denies, ue, other, since, until))
    M.update(state_metrics())
    M.update(proxy_metrics(since, until))
    M.update(db_metrics(since, until, only_ids))
    last_ledger = max((c["_t"] for c in calls), default=None)
    off = dt.timedelta(hours=args.log_offset_hours) if args.log_offset_hours is not None else detect_log_offset(last_ledger)
    M.update(agentlog_metrics(since, until, off, only_ids))
    M.update(finfo)
    M["session_filter_active"] = only_ids is not None
    M.update(memory_metrics())
    M["window_hours"] = hours
    M["since"] = since.isoformat()
    M["until"] = until.isoformat()

    # burn since the credits were read, so runway reflects what is left now
    cr_at = parse_iso(args.credits_read_at)
    burn_since_read = 0.0
    if os.path.exists(LEDGER):
        with open(LEDGER, errors="replace") as fh:
            for line in fh:
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                if row.get("event") != "call":
                    continue
                try:
                    t = parse_iso(row.get("ts", ""))
                except ValueError:
                    continue
                if t >= cr_at:
                    burn_since_read += real_cost(row)[0]
    M["burn_since_credits_read"] = burn_since_read
    M["usable_credits_now_est"] = args.usable_credits - burn_since_read
    M["reserve"] = args.reserve

    A = acceptance(M, hours)
    if args.json:
        out = dict(M)
        out["acceptance"] = [dict(zip(("id", "change", "metric", "value", "threshold", "verdict"), a)) for a in A]
        out.pop("by_model", None)
        print(json.dumps(out, indent=1, default=str))
        return

    P = print
    P("Hermes measure.py  window %s -> %s  (%.2f h)" % (M["since"], M["until"], hours))
    P("Sources: ledger.jsonl, state.json, policy.json, proxy.log, state.db (ro), agent.log (local offset %+.0f h), MEMORY.md" % M.get("al_local_offset_h", 0))
    if M.get("session_filter_active"):
        P("Session filter: sessions started at/after %s = %d (%d fresh-process roots + %d subagents via parent_session_id) %s; "
          "%d post-apply subagents of PRE-apply parents excluded (they inherit the old process config). "
          "Sessions-db and agent.log metrics use only these; ledger and proxy metrics are time-window only. "
          "Pre-apply sessions still active after the cut (OLD config): %d (%d CLI); agent.log lines dropped: %d untagged, %d other sessions."
          % (M.get("session_filter_after"), M.get("session_filter_n", 0), M.get("session_filter_roots", 0),
             M.get("session_filter_descendants_added", 0), M.get("session_filter_by_source", {}),
             M.get("post_apply_children_of_pre_apply_parents_excluded", 0),
             M.get("pre_apply_sessions_active_after", 0), M.get("pre_apply_cli_sessions_active_after", 0), M.get("al_dropped_untagged_lines", 0), M.get("al_dropped_other_session_lines", 0)))
    P("")
    P("BASELINE")
    P("-" * 78)
    csh = M["cli_session_hours"]
    rows = [
        ("ledger calls", "{:,}".format(M["calls"])),
        ("  by model", ", ".join("%s %d ($%.4f)" % (k.split("/")[-1], v["calls"], v["cost"]) for k, v in sorted(M["by_model"].items())) or "-"),
        ("  by bucket (calls, $real, p50 prompt, 402s)", ", ".join("%s %d ($%.4f, %s, %d)" % (k, v["calls"], v["real_cost"], "{:,}".format(v["prompt_p50"]), v["deny_402"]) for k, v in sorted(M["by_bucket"].items())) if M["by_bucket"] else "(no bucket field on any row yet)"),
        ("prompt tokens p50 / p90 / max", "{:,} / {:,} / {:,}".format(M["prompt_p50"], M["prompt_p90"], M["prompt_max"])),
        ("completion tokens p50", "{:,}".format(M["completion_p50"])),
        ("calls over 60k / over 100k prompt", "{:,} ({:.1%}) / {:,}".format(M["calls_over_60k"], M["calls_over_60k"] / max(M["calls"], 1), M["calls_over_100k"])),
        ("cache hit share (rows with cached_tokens, n=%d)" % M["cache_measured_rows"], "{:.2%}".format(M["cache_hit_share"]) if M["cache_hit_share"] is not None else "-"),
        ("cache share (sessions db, cache_read/(input+cache_read))", "{:.2%}".format(M["db_cache_share"]) if M["db_cache_share"] is not None else "-"),
        ("prompt tokens mean", "{:,.0f}".format(M["prompt_mean"])),
        ("real cost total (catalog rates, cache-aware)", "$%.4f  (ledger cost_usd column: $%.4f)" % (M["real_cost_total"], M["ledger_cost_total"])),
        ("  components: cache re-reads / uncached input / output", "$%.4f (%.1f%%) / $%.4f / $%.4f" % (M["real_cost_cache"], 100 * (M["real_cost_cache_share"] or 0), M["real_cost_uncached_in"], M["real_cost_out"])),
        ("real cost per call", "$%.5f" % M["real_cost_per_call"]),
        ("ledger wall-clock span / active minutes as hours", "%.2f h / %.2f h" % (M["ledger_span_h"], M["active_h"])),
        ("real cost per wall-clock hour", "$%.4f" % M["real_cost_per_wallclock_h"]),
        ("CLI sessions / subagent sessions", "%d / %d" % (M["cli_sessions"], M["subagent_sessions"])),
        ("CLI session-hours (sum of session spans)", "%.2f h" % csh),
        ("real cost per CLI session-hour", ("$%.4f" % (M["real_cost_total"] / csh)) if csh else "-"),
        ("api calls: CLI / subagent (sessions db)", "%d / %d" % (M["cli_api_calls"], M["subagent_api_calls"])),
        ("counterfactual real cost if prompt capped 40k / 50k / 60k", " / ".join("$%.4f" % M["cost_if_cap"][k] for k in (40000, 50000, 60000))),
        ("delegation tasks / max_iterations / share", "%d / %d / %s" % (M["delegation_tasks"], M["delegation_max_iterations"], ("%.1f%%" % (100 * M["delegation_max_iterations_share"])) if M["delegation_max_iterations_share"] is not None else "-")),
        ("  402 deaths / 502 deaths mislabelled / genuine cap, no file", "%d / %d / %d" % (M["delegation_402_deaths"], M["delegation_502_deaths"], M["delegation_genuine_cap_no_file"])),
        ("subagent duration p50 / p90 / max, min", "%.1f / %.1f / %.1f" % (M["delegation_dur_p50_min"], M["delegation_dur_p90_min"], M["delegation_dur_max_min"])),
        ("delivery lag p50 / max, min; undelivered completed", "%.1f / %.1f; %d" % (M["delivery_lag_p50_min"], M["delivery_lag_max_min"], M["delegation_undelivered_completed"])),
        ("peak delegations in flight", str(M["delegation_peak_in_flight"])),
        ("exit-124 terminal results", "{:,}".format(M["exit_124"])),
        ("terminal calls / background / fg timeout>120", "%d / %d / %d" % (M["terminal_calls"], M["terminal_background"], M["terminal_timeout_over_120_fg"])),
        ("sleep commands / seconds", "%d / %.0f" % (M["sleep_commands"], M["sleep_seconds"])),
        ("skill_manage errors (agent.log)", "%d %s" % (M.get("al_skill_manage_errors", 0), M.get("al_skill_manage_error_kinds"))),
        ("compression: preflight / started / failed; prune lines", "%d / %d / %d; %d" % (M.get("al_preflight_compression", 0), M.get("al_compression_started", 0), M.get("al_compression_failed", 0), M.get("al_proactive_prune", 0))),
        ("  preflight thresholds seen", str(M.get("al_preflight_thresholds"))),
        ("  hardcoded context lengths", str(M.get("al_ctx_lengths"))),
        ("compacted messages (sessions db)", "{:,}".format(M["compacted_messages"])),
        ("402: ledger deny / proxy.log / agent.log non-retryable", "%d / %d / %d" % (M["deny_402"], M["proxy_402"], M.get("al_non_retryable_402", 0))),
        ("  hours with a 402", ",".join(M["hours_with_402"]) or "-"),
        ("502 deny / of which curl timeouts; upstream_error", "%d / %d; %d %s" % (M["deny_502"], M["deny_502_timeout"], M["upstream_error"], M["upstream_error_status"])),
        ("proxy status codes", str(M.get("proxy_codes"))),
        ("proxy 404 per hour mean / max; sweep / other; 400 bad-syntax", "%.0f / %d; %d / %d; %d" % (M["proxy_404_per_hour_mean"], M["proxy_404_per_hour_max"], M["proxy_404_sweep"], M["proxy_404_other"], M["proxy_400_bad_syntax"])),
        ("verification_required finishes / length finishes", "%d / %d" % (M["verification_required"], M["finish_length"])),
        ("tool results / >20k chars / >50k / max", "%d / %d / %d / %s" % (M["tool_results"], M["tool_result_gt20k"], M["tool_result_gt50k"], "{:,}".format(M["tool_result_max_chars"]))),
        ("first API call prompt tokens p50 (n=%d)" % M.get("al_first_call_in_n", 0), "{:,}".format(M.get("al_first_call_in_p50", 0))),
        ("MEMORY.md bytes", "{:,}".format(M["memory_md_bytes"])),
        ("sessions cost_status / with cost > 0", "%s / %d" % (M["cost_status"], M["sessions_with_cost"])),
        ("profile_name distribution", str(M["profile_sessions"])),
        ("state.json total / today / calls / blocked", "%s / %s / %s / %s" % (M.get("state_total_usd"), M.get("state_today_usd"), M.get("state_calls"), M.get("state_blocked"))),
        ("policy caps total / daily; buckets / warn / degrade / portal keys", "%s / %s; %s / %s / %s / %s" % (M.get("cap_total_usd"), M.get("cap_daily_usd"), M.get("policy_has_buckets"), M.get("policy_has_warn"), M.get("policy_has_degrade"), M.get("policy_has_portal"))),
    ]
    w = max(len(r[0]) for r in rows)
    for k, v in rows:
        P("%-*s  %s" % (w, k, v))

    P("")
    P("ACCEPTANCE")
    P("-" * 78)
    P("%-4s %-30s %-52s %-22s %-6s %s" % ("id", "change", "metric", "value", "verdict", "threshold"))
    for i, ch, met, val, thr, ver in A:
        P("%-4s %-30s %-52s %-22s %-6s %s" % (i, ch[:30], met[:52], str(val)[:22], ver, thr))

    P("")
    P("COST PROJECTION (real, catalog rates)")
    P("-" * 78)
    tot = M["real_cost_total"]
    per_h = M["real_cost_per_wallclock_h"]
    P("today: $%.4f over %.2f wall-clock h = $%.4f per wall-clock hour; $%.4f per CLI session-hour (%.2f session-hours)" % (tot, M["ledger_span_h"], per_h, tot / csh if csh else 0, csh))
    for cap in (40000, 50000, 60000):
        c = M["cost_if_cap"][cap]
        P("  prompt cap %6d: $%.4f (%.1f%% of today) -> $%.4f per wall-clock hour" % (cap, c, 100 * c / tot if tot else 0, c / M["ledger_span_h"] if M["ledger_span_h"] else 0))
    grant_date = dt.date.fromisoformat(args.grant_date)
    days_to_grant = (grant_date - now.date()).days
    usable = M["usable_credits_now_est"]
    P("credits: %.2f usable at read - %.4f real burn since read = %.2f now; reserve %.2f; grant %.0f on %s (%d days)" % (args.usable_credits, burn_since_read, usable, args.reserve, args.grant, args.grant_date, days_to_grant))
    for label, rate in (("today", per_h), ("after waves 1-2 (50k cap counterfactual)", M["cost_if_cap"][50000] / M["ledger_span_h"] if M["ledger_span_h"] else 0), ("after waves 3-4 (50k cap x 0.85)", 0.85 * M["cost_if_cap"][50000] / M["ledger_span_h"] if M["ledger_span_h"] else 0)):
        if rate <= 0:
            continue
        hrs = (usable - args.reserve) / rate
        need_to_grant = rate * 24 * days_to_grant
        P("  %-42s $%.4f/h -> %.0f running hours (%.1f days at 24 h/day, %.1f days at 8 h/day); %d days to grant at 8 h/day needs $%.2f" % (label, rate, hrs, hrs / 24, hrs / 8, days_to_grant, rate * 8 * days_to_grant))


if __name__ == "__main__":
    main()
