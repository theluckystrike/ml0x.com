# Re-applying the vendor patches after `hermes update`

Checkout: $HOME/.hermes/hermes-agent (base commit f5be923, 2026-08-04).
`hermes update` stashes local edits (hermes_cli/update_cmd.py) and prints the
stash name `hermes-update-autostash-<ts>`. Do NOT rely on `git stash pop`;
the diffs below are the source of truth and apply in numeric order.

Every diff is a plain unified diff with a/ b/ prefixes. 02 is INCREMENTAL on
01 (both touch tools/delegate_tool.py and tests/tools/test_delegate.py), so
the order matters: 01 -> 02 -> 03 -> 04 -> 05.

## 1. Sequence

    cd $HOME/.hermes/hermes-agent
    git status --short                      # expect clean after the update
    P=/path/to/hermes-flash-kit/patches            # this directory
    for f in $P/01-exit-reasons.diff \
             $P/02-child-deliverable-contract.diff \
             $P/03-busy-parent-steer-drain.diff \
             $P/04-curator-60-char-rule.diff \
             $P/05-verify-on-stop-scope.diff; do
      echo "== $f"
      git apply --check "$f" && git apply "$f" || { echo "STOP: $f did not apply"; break; }
    done
    for m in tools/delegate_tool.py cli.py agent/background_review.py agent/verification_stop.py; do
      venv/bin/python -m py_compile $m && echo "compiled $m"
    done

If `git apply --check` fails on one diff, try `git apply --3way <diff>`; if
that still fails, stop and re-locate the anchors listed under "Check" below
before hand-porting. Do not skip a diff and continue: 02 depends on 01.

If the venv lost pytest (fresh venv after update), it is in the uv cache:
`VIRTUAL_ENV=$PWD/venv uv pip install --offline --python venv/bin/python pytest`.

## 2. Check per patch

01-exit-reasons.diff (tools/delegate_tool.py, tests/tools/test_delegate.py)
    grep -n 'exit_reason = "billing_blocked"' tools/delegate_tool.py     # 1 hit
    grep -n '"failure_reason": _failure_reason or None' tools/delegate_tool.py
    venv/bin/python -m pytest -q -p no:cacheprovider tests/tools/test_delegate.py -k "billing or provider_failure or budget_exhaustion or incomplete"
    # expect 4 passed

02-child-deliverable-contract.diff (tools/delegate_tool.py, tests/tools/test_delegate.py)
    venv/bin/python -c "from tools.delegate_tool import _build_child_system_prompt as b; t=b('write /tmp/x.md','ctx',max_iterations=50); assert 'By iteration 40' in t; print('ok')"
    venv/bin/python -m pytest -q -p no:cacheprovider tests/tools/test_delegate.py -k DeliverableContract
    # expect 4 passed

03-busy-parent-steer-drain.diff (cli.py, tests/cli/test_cli_async_delegation_delivery.py)
    grep -n '_drain_process_notifications_to_steer("cli-busy")' cli.py     # 1 hit in process_loop
    grep -n 'def _flush_busy_steered_notifications' cli.py                  # 1 hit
    venv/bin/python -m pytest -q -p no:cacheprovider tests/cli/test_cli_async_delegation_delivery.py
    # expect 9 passed
    # Live check after one fan-out session (target: lag under 60 s):
    sqlite3 -readonly ~/.hermes/state.db "select delegation_id, round(delivered_at-completed_at) lag_s from async_delegations where delivered_at is not null order by completed_at desc limit 10"

04-curator-60-char-rule.diff (agent/background_review.py, tests/run_agent/test_review_prompt_class_first.py)
    grep -c 'RULES FOR ANY CREATE' agent/background_review.py               # 2 (both prompts)
    venv/bin/python -m pytest -q -p no:cacheprovider tests/run_agent/test_review_prompt_class_first.py
    # Note: skills.creation_nudge_interval is 0 in ~/.hermes/config.yaml, so the
    # review fork is off; this patch only matters once it is re-enabled.

05-verify-on-stop-scope.diff (agent/verification_stop.py, tests/agent/test_verification_stop.py)
    HERMES_VERIFY_ON_STOP=1 venv/bin/python -c "from agent.verification_stop import build_verify_on_stop_nudge as b; assert b(session_id=None, changed_paths=['/x/runs/site/y.json']) is None; assert b(session_id=None, changed_paths=['/x/stages/05-generate.mjs']); print('ok')"
    venv/bin/python -m pytest -q -p no:cacheprovider tests/agent/test_verification_stop.py
    # expect 20 passed

## 3. Full regression set (the same list as the pre/post run when the patches were written)

    venv/bin/python -m pytest -q -p no:cacheprovider \
      tests/tools/test_delegate.py tests/tools/test_delegate_summary_budget.py \
      tests/tools/test_delegate_toolset_scope.py tests/tools/test_delegate_composite_toolsets.py \
      tests/tools/test_delegate_kanban_isolation.py tests/tools/test_delegate_subagent_timeout_diagnostic.py \
      tests/tools/test_delegate_apiserver_background.py tests/tools/test_async_delegation.py \
      tests/tools/test_async_delegation_fd_leak.py tests/agent/test_verification_stop.py \
      tests/agent/test_verification_stop_caching.py tests/test_background_review_list_shapes.py \
      tests/test_background_review_session_isolation.py tests/cli/test_cli_steer_busy_path.py \
      tests/cli/test_cli_background_busy_path.py tests/cli/test_cli_async_delegation_delivery.py \
      tests/run_agent/test_review_prompt_class_first.py tests/run_agent/test_background_review.py

## 4. Regenerating the diffs after a hand-port

    git diff -- tools/delegate_tool.py tests/tools/test_delegate.py > 01+02 combined  (then split, or keep combined and drop 02)
    git diff -- cli.py tests/cli/test_cli_async_delegation_delivery.py > 03-busy-parent-steer-drain.diff
    git diff -- agent/background_review.py tests/run_agent/test_review_prompt_class_first.py > 04-curator-60-char-rule.diff
    git diff -- agent/verification_stop.py tests/agent/test_verification_stop.py > 05-verify-on-stop-scope.diff

Live Hermes processes import the tree at start only: patches take effect for
new sessions.
