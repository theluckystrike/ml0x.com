# patches: five diffs against the Hermes Agent source

These patch the vendored Hermes tree at `~/.hermes/hermes-agent`. They are lost on `hermes update`, which is why
`REAPPLY.md` exists: it lists the order, the `git apply --check` step, and what to re-grep when line numbers drift.

| diff | what it fixes |
|---|---|
| `01-exit-reasons.diff` | a child that died on HTTP 402 was labelled `max_iterations`; exit reasons now distinguish `billing_blocked`, `max_iterations`, `timeout` and `completed`, so the parent (and the hook) can act on the real cause |
| `02-child-deliverable-contract.diff` | the child prompt carries the deliverable contract and its iteration budget instead of relying on the parent to paste it |
| `03-busy-parent-steer-drain.diff` | delegation results were delivered 5 to 38 minutes late while the parent sleep-polled; the steer queue is drained on every turn boundary, not only on idle |
| `04-curator-60-char-rule.diff` | the background review (skill curator) prompt now states the 60-character skill-description limit and the skill_view-before-patch rule, one write per review, so a review fork stops burning iterations on refused `skill_manage` writes (34 such errors in one day) |
| `05-verify-on-stop-scope.diff` | `verify_on_stop` ignores data, markup and config edits (.json, .yaml, .html, ...) so a one-line data change no longer triggers a 243-second `npm test` |

Apply from the source root: `git apply --check ../path/01-exit-reasons.diff && git apply ../path/01-exit-reasons.diff`,
one at a time, in order. Written against Hermes Agent as of git HEAD f5be9236 (2026-08-04).
